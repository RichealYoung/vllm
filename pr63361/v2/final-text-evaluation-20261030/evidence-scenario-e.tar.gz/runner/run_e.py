"""Scenario E / E-no-history driver: replay the frozen coding-agent workload.

  python run_e.py run --root R --attempt A --run-id ID --version {N,F}
                      --tree {plain,probe} --mode {hist,nohist} [--kv-monitor]
                      [--batches 0,1,2,3]

One fresh server (same settings and warmup as scenario A), prefix-cache reset,
then the frozen batches in order. In each batch 4 agents start at their frozen
offsets; each agent sends step k (messages before the k-th assistant message,
with tools, tool_choice "none"), waits for the complete response, sleeps its
frozen think time, then sends step k+1. hist: one session per trajectory;
nohist: a new session per request. --kv-monitor samples /metrics every 2 s
(KV-pressure test only; never in formal performance runs).
"""

import argparse
import asyncio
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, "/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030/runner")
import run_a  # noqa: E402  shared server settings, warmup and helpers

A_ROOT = Path("/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030/exp")
WORKLOAD_SHA = "0ae91e99c428597f18364bb293931c40f153fd39fa3553f4d61db11fae86709b"
WINDOW_TIMEOUT_S = 90 * 60


async def request(client, bench_id, messages, tools, session_id, max_tokens):
    body = dict(run_a.SAMPLING)
    body.update(model=run_a.MODEL_NAME, messages=messages, tools=tools, tool_choice="none",
                max_tokens=max_tokens, stream=True, stream_options={"include_usage": True},
                request_id=bench_id, session_id=session_id)
    start = time.perf_counter_ns()
    first = usage = finish = None
    done, status, error, n_chunks = False, "ok", None, 0
    try:
        async with asyncio.timeout(run_a.REQUEST_TIMEOUT_S):
            async with client.stream("POST", "/v1/chat/completions", json=body) as resp:
                if resp.status_code != 200:
                    text = (await resp.aread()).decode(errors="replace")[:500]
                    raise RuntimeError(f"HTTP {resp.status_code}: {text}")
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    value = line[5:].strip()
                    if value == "[DONE]":
                        done = True
                        continue
                    if not value:
                        continue
                    event = json.loads(value)
                    if "error" in event:
                        raise RuntimeError(f"SSE error: {event['error']}")
                    if event.get("usage"):
                        usage = event["usage"]
                    for choice in event.get("choices", []):
                        delta = choice.get("delta", {})
                        if delta.get("content") or delta.get("tool_calls"):
                            n_chunks += 1
                            if first is None:
                                first = time.perf_counter_ns()
                        if choice.get("finish_reason") is not None:
                            finish = choice["finish_reason"]
        if not done or first is None or finish != "length":
            raise RuntimeError(f"missing output/terminal event/fixed-length finish ({finish})")
        if not usage or usage.get("completion_tokens") != max_tokens:
            raise RuntimeError("completion_tokens differs from max_tokens")
        details = usage.get("prompt_tokens_details")
        if not isinstance(details, dict) or type(details.get("cached_tokens")) is not int:
            raise RuntimeError("cached_tokens missing")
    except Exception as exc:
        status, error = "error", repr(exc)
    end = time.perf_counter_ns()
    return {"bench_id": bench_id, "start_ns": start, "first_chunk_ns": first, "end_ns": end,
            "ttft_s": (first - start) / 1e9 if first is not None else None,
            "e2e_s": (end - start) / 1e9, "usage": usage, "finish_reason": finish,
            "status": status, "error": error}


async def agent(client, prefix, mode, traj, t0, out_path, failures):
    await asyncio.sleep(max(0.0, traj["start_offset_s"] - (time.monotonic() - t0)))
    tid = traj["trajectory_id"]
    for step in traj["steps"]:
        if failures:
            return
        session = f"{prefix}:{tid}" if mode == "hist" else f"{prefix}:{tid}:{step['step']}"
        rid = f"m.{prefix}.{traj['batch']}.{traj['slot']}.{step['step']:03d}"
        result = await request(client, rid, traj["messages"][: step["end"]], traj["tools"],
                               session, step["max_tokens"])
        result.update(trajectory_id=tid, batch=traj["batch"], slot=traj["slot"],
                      step=step["step"], max_tokens=step["max_tokens"],
                      prompt_tokens_preview=step["prompt_tokens_preview"])
        s0 = time.perf_counter_ns()
        with out_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(result) + "\n")
        if result["status"] != "ok":
            failures.append(result["error"])
            return
        await asyncio.sleep(step["think_after_s"])
        with out_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"think": rid, "planned_s": step["think_after_s"],
                                "actual_s": (time.perf_counter_ns() - s0) / 1e9}) + "\n")


async def kv_monitor(client, path, stop):
    while not stop.is_set():
        try:
            sample = await run_a.metrics_sample(client)
            sample["t_ns"] = time.perf_counter_ns()
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(sample) + "\n")
        except Exception as exc:
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"error": repr(exc)}) + "\n")
        try:
            await asyncio.wait_for(stop.wait(), 2.0)
        except asyncio.TimeoutError:
            pass


async def replay(args, run_dir, proc):
    import httpx

    workload = json.loads((Path(args.root) / "workload-e.json").read_text(encoding="utf-8"))
    batches = [int(b) for b in args.batches.split(",")]
    warm = run_a.read_json(A_ROOT / "warmup-messages.json")["requests"]
    reuse = run_a.read_json(A_ROOT / "reuse-warmup-messages.json")["requests"]
    prefix = f"{args.attempt}.{args.run_id}"
    async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{args.port}", timeout=run_a.REQUEST_TIMEOUT_S,
                                 trust_env=False, limits=httpx.Limits(max_connections=8)) as client:
        await run_a.wait_ready(client, proc)
        log_text = (run_dir / "server.log").read_text(errors="replace")
        if re.findall(r"Session (?:token|hash) cache disabled[^\n]*", log_text):
            raise RuntimeError("reuse disabled")
        previous = os.sched_getaffinity(0)
        os.sched_setaffinity(0, run_a.CLIENT_CPUS)
        stop = asyncio.Event()
        monitor = None
        try:
            # Same warmup as scenario A (16-token outputs).
            warm_results = []
            for w in warm:
                warm_results.append(await run_a.one_request(client, f"w.{prefix}.{w['id']}", w["messages"], None, 16))
            for r in reuse:
                warm_results.append(await run_a.one_request(client, f"w.{prefix}.{r['id']}", r["messages"],
                                                            f"{prefix}:{r['session']}", 16, cache_salt=run_a.WARM_SALT))
            run_a.write_json(run_dir / "warmup.json", warm_results)
            if any(r["status"] != "ok" for r in warm_results):
                raise RuntimeError("warmup failed")
            reset = await client.post("/reset_prefix_cache")
            reset.raise_for_status()
            before = await run_a.metrics_sample(client)
            cpu0 = run_a.process_cpu_seconds(proc.pid)
            run_a.write_json(run_dir / "reset-receipt.json", {"reset": reset.json(), "metrics": before})
            if args.kv_monitor:
                monitor = asyncio.create_task(kv_monitor(client, run_dir / "kv-monitor.jsonl", stop))
            out_path = run_dir / "client-requests.jsonl"
            out_path.touch()
            failures = []
            windows = []
            async with asyncio.timeout(WINDOW_TIMEOUT_S):
                for b in batches:
                    trajs = [t for t in workload["trajectories"] if t["batch"] == b]
                    t0 = time.monotonic()
                    w0 = time.perf_counter_ns()
                    await asyncio.gather(*(agent(client, prefix, args.mode, t, t0, out_path, failures) for t in trajs))
                    windows.append({"batch": b, "start_ns": w0, "end_ns": time.perf_counter_ns()})
                    if failures:
                        raise RuntimeError(f"request failed: {failures[0]}")
            cpu1 = run_a.process_cpu_seconds(proc.pid)
            after = await run_a.metrics_sample(client)
            run_a.write_json(run_dir / "window.json", {"batches": windows, "server_cpu_s": cpu1["total"] - cpu0["total"],
                                                       "metrics_before": before, "metrics_after": after,
                                                       "workload_sha256": WORKLOAD_SHA, "mode": args.mode})
        finally:
            stop.set()
            if monitor:
                await monitor
            os.sched_setaffinity(0, previous)


def run(args):
    root = Path(args.root)
    text = (root / "workload-e.json").read_bytes()
    if hashlib.sha256(text).hexdigest() != WORKLOAD_SHA:
        raise SystemExit("workload SHA mismatch")
    run_dir = root / "attempts" / args.attempt / args.run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    if args.tree == "probe-tl":  # diagnostic trees with the request timeline
        tree = str(root.parent / "trees" / f"{args.version}-probe-tl")
    else:
        tree = run_a.read_json(A_ROOT / "trees.json")[args.version][args.tree]
    probe_dir = run_dir / "probe" if args.tree.startswith("probe") else None
    env = run_a.server_env(tree, str(A_ROOT / "runtime-cache"), probe_dir)
    if probe_dir is not None:
        env["COST_PROBE_CAPACITY"] = "400000"
    argv = run_a.server_argv(run_a.read_json(A_ROOT / "config.json")["model"]["path"], args.port,
                             args.version, "probe" if args.tree.startswith("probe") else "plain")
    run_a.write_json(run_dir / "command.json", {"argv": argv, "environment": env, "tree": tree,
                                                "version": args.version, "tree_kind": args.tree,
                                                "mode": args.mode, "batches": args.batches,
                                                "kv_monitor": args.kv_monitor})
    run_a.write_json(run_dir / "cpu-before.json", run_a.cpu_snapshot())
    log = (run_dir / "server.log").open("w", encoding="utf-8")
    proc = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    # Client and server perf_counter_ns are comparable only in one time namespace.
    try:
        run_a.write_json(run_dir / "clock-domain.json", {
            "client_time_ns": os.readlink("/proc/self/ns/time"),
            "server_time_ns": os.readlink(f"/proc/{proc.pid}/ns/time"),
            "clock": "perf_counter_ns = CLOCK_MONOTONIC (system-wide on Linux)"})
    except OSError as exc:
        run_a.write_json(run_dir / "clock-domain.json", {"error": repr(exc)})
    error = None
    try:
        asyncio.run(replay(args, run_dir, proc))
    except BaseException as exc:
        error = repr(exc)
    finally:
        run_a.write_json(run_dir / "cpu-after.json", run_a.cpu_snapshot())
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGINT)
            try:
                proc.wait(timeout=120)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=60)
        log.close()
        leftovers = subprocess.run(["pgrep", "-g", str(proc.pid)], capture_output=True, text=True).stdout.split()
        run_a.write_json(run_dir / "server-exit.json", {"returncode": proc.returncode,
                                                        "leftover_pids": leftovers, "error": error})
    if error or leftovers:
        raise SystemExit(f"run failed: {error} leftovers={leftovers}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--root", required=True)
    r.add_argument("--attempt", required=True)
    r.add_argument("--run-id", required=True)
    r.add_argument("--version", choices=("N", "F"), required=True)
    r.add_argument("--tree", choices=("plain", "probe", "probe-tl"), required=True)
    r.add_argument("--mode", choices=("hist", "nohist"), required=True)
    r.add_argument("--batches", default="0,1,2,3")
    r.add_argument("--kv-monitor", action="store_true")
    r.add_argument("--port", type=int, default=18491)
    run(ap.parse_args())


if __name__ == "__main__":
    main()
