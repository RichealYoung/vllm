#!/bin/bash
# KV-pressure test: N and F plain, all 4 batches, hist mode, with /metrics sampling.
set -uo pipefail
X=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-e-20261030
P=/root/autodl-tmp/codex-projects/vllm-main-cu13
for v in N F; do
  run=kvtest-$v
  $P/.venv/bin/python /root/autodl-tmp/shared/tools/run_job.py --project codex-pr63361 \
    --id "claude-final-e-attempt-001-kvtest-${v,,}" --resource benchmark \
    --purpose "Scenario E KV-pressure test ($v plain, 4 batches)" --expected-seconds 2400 --wait-seconds 3600 \
    --actor Claude --role support --workspace $X --cwd $X -- \
    $P/.venv/bin/python $X/runner/run_e.py run --root $X/exp --attempt attempt-001 --run-id $run \
      --version $v --tree plain --mode hist --kv-monitor >> $X/exp/kvtest.log 2>&1 < /dev/null
  echo "$run rc=$?" | tee -a $X/exp/kvtest.log
done
$P/.venv/bin/python $X/runner/kv_check.py $X/exp/attempts/attempt-001/kvtest-N $X/exp/attempts/attempt-001/kvtest-F
