"""KV-pressure check for a scenario E run.

A later step of a session should find its previous prompt in the native prefix
cache: cached_tokens >= floor((prev_prompt_tokens - SLACK) / 16) * 16, where
SLACK covers the generation prompt that the next render replaces. A request
below that is counted as a prefix-cache loss (eviction or other miss).

  python kv_check.py RUN_DIR [RUN_DIR ...]
"""
import json
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

SLACK = 32
BLOCK = 16


def main():
    for d in map(Path, sys.argv[1:]):
        rows = [json.loads(l) for l in (d / "client-requests.jsonl").read_text().splitlines() if l]
        reqs = [r for r in rows if "bench_id" in r]
        thinks = [r for r in rows if "think" in r]
        by = defaultdict(list)
        for r in reqs:
            by[r["trajectory_id"]].append(r)
        losses, later, lost_tokens = [], 0, []
        for tid, rs in by.items():
            rs.sort(key=lambda r: r["step"])
            for prev, cur in zip(rs, rs[1:]):
                later += 1
                expect = (prev["usage"]["prompt_tokens"] - SLACK) // BLOCK * BLOCK
                cached = cur["usage"]["prompt_tokens_details"]["cached_tokens"]
                if cached < expect:
                    losses.append({"trajectory": tid, "step": cur["step"], "batch": cur["batch"],
                                   "expected_min": expect, "cached": cached,
                                   "prompt": cur["usage"]["prompt_tokens"]})
                    lost_tokens.append(expect - cached)
        mon = [json.loads(l) for l in (d / "kv-monitor.jsonl").read_text().splitlines() if l] \
            if (d / "kv-monitor.jsonl").exists() else []
        mon = [m for m in mon if "error" not in m]
        kv = [m["kv_usage"] for m in mon if m.get("kv_usage") is not None]
        pre = [m["preemptions"] for m in mon if m.get("preemptions") is not None]
        ttft = [r["ttft_s"] * 1e3 for r in reqs if r["step"] > 0]
        prompt_mismatch = sum(1 for r in reqs if r["usage"]["prompt_tokens"] != r["prompt_tokens_preview"])
        drift = [t["actual_s"] - t["planned_s"] for t in thinks]
        out = {"run": d.name, "requests": len(reqs), "errors": sum(r["status"] != "ok" for r in reqs),
               "later_requests": later, "prefix_cache_losses": len(losses),
               "loss_rate": len(losses) / later if later else None,
               "lost_tokens_median": st.median(lost_tokens) if lost_tokens else 0,
               "losses_by_batch": {b: sum(1 for x in losses if x["batch"] == b) for b in range(4)},
               "kv_usage_max": max(kv) if kv else None,
               "kv_usage_p90": sorted(kv)[int(0.9 * (len(kv) - 1))] if kv else None,
               "kv_samples_ge_0.9": sum(1 for x in kv if x >= 0.9),
               "kv_samples": len(kv),
               "preemptions_delta": (pre[-1] - pre[0]) if len(pre) > 1 else None,
               "later_ttft_ms_mean": st.fmean(ttft) if ttft else None,
               "later_ttft_ms_p50": st.median(ttft) if ttft else None,
               "prompt_tokens_vs_preview_mismatch": prompt_mismatch,
               "think_drift_s_max": max(drift) if drift else None,
               "first_losses": losses[:5]}
        (d / "kv-check.json").write_text(json.dumps(out, indent=2))
        print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
