#!/bin/bash
# Scenario E phases as a sequence of run_job jobs (one fresh server each).
# Stops at the first failure; finished runs are never rerun or overwritten.
#   phase_e.sh <attempt> hist|nohist|diag
set -uo pipefail
X=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-e-20261030
P=/root/autodl-tmp/codex-projects/vllm-main-cu13
attempt=$1; phase=$2
case $phase in
  hist)   runs="e-b1-N:N:plain:hist e-b1-F:F:plain:hist e-b2-F:F:plain:hist e-b2-N:N:plain:hist
                e-b3-N:N:plain:hist e-b3-F:F:plain:hist e-b4-F:F:plain:hist e-b4-N:N:plain:hist" ;;
  nohist) runs="en-b1-N:N:plain:nohist en-b1-F:F:plain:nohist en-b2-F:F:plain:nohist en-b2-N:N:plain:nohist
                en-b3-N:N:plain:nohist en-b3-F:F:plain:nohist en-b4-F:F:plain:nohist en-b4-N:N:plain:nohist" ;;
  diag)   runs="diag-e-N:N:probe-tl:hist diag-e-F:F:probe-tl:hist diag-en-F:F:probe-tl:nohist diag-en-N:N:probe-tl:nohist" ;;
  *) echo "unknown phase"; exit 2 ;;
esac
mkdir -p $X/exp/attempts/$attempt
for spec in $runs; do
  IFS=: read -r run version tree mode <<< "$spec"
  echo "$(date -u +%FT%TZ) start $run" | tee -a $X/exp/attempts/$attempt/phase-$phase.log
  $P/.venv/bin/python /root/autodl-tmp/shared/tools/run_job.py --project codex-pr63361 \
    --id "claude-final-e-$attempt-${run,,}" --resource benchmark \
    --purpose "Scenario E $phase $run ($version/$tree/$mode)" --expected-seconds 1800 --wait-seconds 3600 \
    --actor Claude --role support --workspace $X --cwd $X -- \
    $P/.venv/bin/python $X/runner/run_e.py run --root $X/exp --attempt $attempt --run-id $run \
      --version $version --tree $tree --mode $mode \
    >> $X/exp/attempts/$attempt/phase-$phase.log 2>&1 < /dev/null
  rc=$?
  echo "$(date -u +%FT%TZ) end $run rc=$rc" | tee -a $X/exp/attempts/$attempt/phase-$phase.log
  [ $rc -eq 0 ] || { echo "STOPPED at $run"; exit 1; }
done
echo "PHASE-DONE $phase"
