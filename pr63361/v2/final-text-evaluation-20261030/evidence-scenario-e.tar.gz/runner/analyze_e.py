"""Scenario E analysis (read-only over raw runs; outputs to R/analysis/<attempt>/).

  python analyze_e.py perf --root R --attempt A --mode hist|nohist --blocks NRUN:FRUN ...
  python analyze_e.py diag --root R --attempt A --run RUN [--run RUN ...]
"""
import argparse
import json
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, "/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030/runner")
import analyze_a  # noqa: E402  probe join and per-request fine costs

DELTA_BINS = [(0, 256), (256, 512), (512, 1024), (1024, 2048), (2048, 10**9)]
PROMPT_BINS = [(0, 12000), (12000, 20000), (20000, 28000), (28000, 36000), (36000, 41000)]


def load(root, attempt, run):
    d = Path(root) / "attempts" / attempt / run
    rows = [json.loads(l) for l in (d / "client-requests.jsonl").read_text().splitlines() if l]
    reqs = [r for r in rows if "bench_id" in r]
    return {"dir": d, "run": run, "cmd": json.loads((d / "command.json").read_text()),
            "reqs": reqs, "thinks": [r for r in rows if "think" in r],
            "window": json.loads((d / "window.json").read_text()) if (d / "window.json").exists() else None,
            "exit": json.loads((d / "server-exit.json").read_text())}


def key(r):
    return (r["trajectory_id"], r["step"])


def with_delta(reqs):
    by = defaultdict(dict)
    for r in reqs:
        by[r["trajectory_id"]][r["step"]] = r
    for r in reqs:
        prev = by[r["trajectory_id"]].get(r["step"] - 1)
        r["delta_tokens"] = r["usage"]["prompt_tokens"] - prev["usage"]["prompt_tokens"] if prev else None
    return reqs


def stats(values):
    return {"n": len(values), "mean": st.fmean(values) if values else None,
            "p50": analyze_a.quantile(values, .5), "p95": analyze_a.quantile(values, .95)}


def cmd_perf(args):
    out = Path(args.root) / "analysis" / args.attempt
    out.mkdir(parents=True, exist_ok=True)
    cohort = (lambda r: r["step"] > 0) if args.mode == "hist" else (lambda r: True)
    blocks = []
    for spec in args.blocks:
        nr, fr = spec.split(":")
        n, f = load(args.root, args.attempt, nr), load(args.root, args.attempt, fr)
        assert n["cmd"]["version"] == "N" and f["cmd"]["version"] == "F"
        assert n["cmd"]["mode"] == f["cmd"]["mode"] == args.mode
        problems = []
        for run in (n, f):
            if run["exit"]["error"] or run["exit"]["leftover_pids"] or len(run["reqs"]) != 702 \
                    or any(r["status"] != "ok" for r in run["reqs"]):
                problems.append(f"{run['run']} invalid")
        fn, ff = {key(r): r for r in with_delta(n["reqs"])}, {key(r): r for r in with_delta(f["reqs"])}
        token_diffs = [k for k in fn if fn[k]["usage"]["prompt_tokens"] != ff[k]["usage"]["prompt_tokens"]]
        cached_diffs = sum(1 for k in fn if fn[k]["usage"]["prompt_tokens_details"]["cached_tokens"]
                           != ff[k]["usage"]["prompt_tokens_details"]["cached_tokens"])
        tn = [r["ttft_s"] * 1e3 for r in n["reqs"] if cohort(r)]
        tf = [r["ttft_s"] * 1e3 for r in f["reqs"] if cohort(r)]
        en = [r["e2e_s"] * 1e3 for r in n["reqs"] if cohort(r)]
        ef = [r["e2e_s"] * 1e3 for r in f["reqs"] if cohort(r)]
        b = {"N": nr, "F": fr, "problems": problems, "prompt_token_diffs": len(token_diffs),
             "cached_token_diffs": cached_diffs,
             "ttft": {"N": stats(tn), "F": stats(tf)}, "e2e": {"N": stats(en), "F": stats(ef)}}
        b["saved_ms"] = b["ttft"]["N"]["mean"] - b["ttft"]["F"]["mean"]
        b["saved_pct"] = 100 * b["saved_ms"] / b["ttft"]["N"]["mean"]
        b["e2e_saved_ms"] = b["e2e"]["N"]["mean"] - b["e2e"]["F"]["mean"]
        for side, run in (("N", n), ("F", f)):
            w = run["window"]
            b[side + "_wall_s"] = sum((x["end_ns"] - x["start_ns"]) / 1e9 for x in w["batches"])
            b[side + "_cpu_ms_per_request"] = 1e3 * w["server_cpu_s"] / len(run["reqs"])
        # Matched-request bins (by N's delta / prompt length).
        for name, bins, field in (("by_delta", DELTA_BINS, "delta_tokens"), ("by_prompt", PROMPT_BINS, None)):
            rows = []
            for lo, hi in bins:
                ks = [k for k, r in fn.items() if cohort(r) and (field is None or r[field] is not None)
                      and lo <= (r[field] if field else r["usage"]["prompt_tokens"]) < hi]
                if ks:
                    dn = st.fmean(fn[k]["ttft_s"] * 1e3 for k in ks)
                    df = st.fmean(ff[k]["ttft_s"] * 1e3 for k in ks)
                    rows.append({"bin": [lo, hi], "n": len(ks), "N": dn, "F": df, "saved_ms": dn - df})
            b[name] = rows
        blocks.append(b)
    saved = [b["saved_ms"] for b in blocks]
    pct = [b["saved_pct"] for b in blocks]
    summary = {"mode": args.mode, "blocks": blocks,
               "saved_ms_mean": st.fmean(saved), "saved_ms_range": [min(saved), max(saved)],
               "saved_pct_mean": st.fmean(pct), "saved_pct_range": [min(pct), max(pct)],
               "p95_saved_ms_mean": st.fmean(b["ttft"]["N"]["p95"] - b["ttft"]["F"]["p95"] for b in blocks),
               "e2e_saved_ms_mean": st.fmean(b["e2e_saved_ms"] for b in blocks)}
    (out / f"perf-{args.mode}-summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps({k: v for k, v in summary.items() if k != "blocks"}, indent=1))
    for b in blocks:
        print(b["N"], b["F"], "TTFT N %.1f F %.1f saved %.1f (%.1f%%) p95 %.0f/%.0f e2e %.0f/%.0f wall %.0f/%.0f s problems=%s tokdiff=%d cachediff=%d"
              % (b["ttft"]["N"]["mean"], b["ttft"]["F"]["mean"], b["saved_ms"], b["saved_pct"], b["ttft"]["N"]["p95"],
                 b["ttft"]["F"]["p95"], b["e2e"]["N"]["mean"], b["e2e"]["F"]["mean"], b["N_wall_s"], b["F_wall_s"],
                 b["problems"], b["prompt_token_diffs"], b["cached_token_diffs"]))


def cmd_diag(args):
    out = Path(args.root) / "analysis" / args.attempt
    out.mkdir(parents=True, exist_ok=True)
    report = {}
    for name in args.run:
        run = load(args.root, args.attempt, name)
        probe = {"version": run["cmd"]["version"], "tree": "probe", "events": [], "metas": []}
        for f in (run["dir"] / "probe").glob("probe-*.events.jsonl"):
            probe["events"] += [json.loads(l) for l in f.read_text().splitlines() if l]
        for f in (run["dir"] / "probe").glob("probe-*.meta.json"):
            probe["metas"].append(json.loads(f.read_text()))
        by_rid, api, core = analyze_a.join_probe(probe)
        # Internal (scheduler) IDs -> client request IDs.
        internal = {}
        for rid, st_ in by_rid.items():
            for e in st_.get("id_map", []):
                internal[e["internal"]] = rid
        timeline = defaultdict(dict)
        for e in probe["events"]:
            if e["stage"] in ("first_scheduled", "first_token_core"):
                rid = internal.get(e["rid"])
                if rid:
                    timeline[rid][e["stage"]] = e["start_wall_ns"]
        rows, problems = [], []
        if any(m["overflow"] for m in probe["metas"]):
            problems.append("probe overflow")
        for r in with_delta(run["reqs"]):
            st_ = by_rid.get(r["bench_id"])
            tl = timeline.get(r["bench_id"], {})
            if st_ is None or "F" not in st_ or "C" not in st_ or len(tl) != 2:
                problems.append(f"incomplete {r['bench_id']}")
                continue
            row = analyze_a.request_row(probe, r["bench_id"], st_)
            F, C = st_["F"][0], st_["C"][0]
            seg = {"client_to_frontend": F["start_wall_ns"] - r["start_ns"],
                   "frontend": F["end_wall_ns"] - F["start_wall_ns"],
                   "frontend_to_core": C["start_wall_ns"] - F["end_wall_ns"],
                   "core": C["end_wall_ns"] - C["start_wall_ns"],
                   "core_to_first_scheduled": tl["first_scheduled"] - C["end_wall_ns"],
                   "scheduled_to_first_token": tl["first_token_core"] - tl["first_scheduled"],
                   "first_token_to_client": r["first_chunk_ns"] - tl["first_token_core"]}
            if any(v < -1_000_000 for v in seg.values()):  # >1 ms negative: clock or join error
                problems.append(f"negative segment {r['bench_id']} {seg}")
            row.update({k: v for k, v in seg.items()}, step=r["step"], batch=r["batch"],
                       ttft_ms=r["ttft_s"] * 1e3, delta_tokens=r["delta_tokens"],
                       prompt_tokens=r["usage"]["prompt_tokens"],
                       cached_tokens=r["usage"]["prompt_tokens_details"]["cached_tokens"])
            rows.append(row)
        later = [x for x in rows if x["step"] > 0] if run["cmd"]["mode"] == "hist" else rows
        segs = ["client_to_frontend", "frontend", "frontend_to_core", "core", "core_to_first_scheduled",
                "scheduled_to_first_token", "first_token_to_client"]
        med = lambda k: analyze_a.ms(st.median([x[k] for x in later if x.get(k) is not None])) if later else None
        mean = lambda k: analyze_a.ms(st.fmean([x[k] for x in later if x.get(k) is not None])) if later else None
        fine = ["T_wall", "T-reuse", "T-history", "H_wall", "H-reuse", "H-history", "F_wall", "C_wall", "A_wall",
                "t_lcp", "t_boundary", "t_ids", "t_bound", "t_copy", "t_finish", "t_encode_residual",
                "h_lcp", "h_size_hashes", "h_copy", "H:commit", "h_bound", "h_prefix_residual",
                "h_publish_residual"]
        rep = {"version": run["cmd"]["version"], "mode": run["cmd"]["mode"], "requests": len(run["reqs"]),
               "joined": len(rows), "problems": problems[:20], "n_problems": len(problems),
               "clock": json.loads((run["dir"] / "clock-domain.json").read_text()),
               "timeline_mean_ms": {k: mean(k) for k in segs}, "timeline_median_ms": {k: med(k) for k in segs},
               "ttft_mean_ms": st.fmean(x["ttft_ms"] for x in later) if later else None,
               "fine_median_ms": {k: med(k) for k in fine if any(k in x for x in later)}}
        if run["cmd"]["version"] == "F":
            rep["routes"] = {k: sum(1 for x in rows if x.get("t_route") == k) for k in ("miss", "exact", "partial")}
            rep["t_reuse_fraction"] = sum(x.get("t_reused_tokens") or 0 for x in later) / sum(x["prompt_tokens"] for x in later)
            rep["bytes_used_max_mib"] = {"T": max((x.get("t_bytes_used") or 0) for x in rows) / 2**20,
                                         "H": max((x.get("h_bytes_used") or 0) for x in rows) / 2**20}
            rep["evicted"] = sum(x.get("evicted", 0) for x in rows)
            rep["reserve_failed"] = sum(x.get("reserve_failed", 0) for x in rows)
            # Fine T/H costs by step increment (hist only).
            rep["by_delta_median_ms"] = []
            for lo, hi in DELTA_BINS:
                xs = [x for x in later if x["delta_tokens"] is not None and lo <= x["delta_tokens"] < hi]
                if xs:
                    rep["by_delta_median_ms"].append({"bin": [lo, hi], "n": len(xs), **{
                        k: analyze_a.ms(st.median([x[k] for x in xs])) for k in
                        ("T_wall", "T-reuse", "T-history", "H_wall", "H-reuse", "H-history", "C_wall", "A_wall")}})
        with (out / f"joined-{name}.jsonl").open("w") as f:
            for x in rows:
                f.write(json.dumps(x) + "\n")
        report[name] = rep
    (out / "diag-summary.json").write_text(json.dumps(report, indent=1))
    print(json.dumps(report, indent=1)[:12000])


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("perf")
    p.add_argument("--root", required=True)
    p.add_argument("--attempt", required=True)
    p.add_argument("--mode", choices=("hist", "nohist"), required=True)
    p.add_argument("--blocks", nargs="+", required=True)
    d = sub.add_parser("diag")
    d.add_argument("--root", required=True)
    d.add_argument("--attempt", required=True)
    d.add_argument("--run", action="append", required=True)
    a = ap.parse_args()
    cmd_perf(a) if a.cmd == "perf" else cmd_diag(a)


if __name__ == "__main__":
    main()
