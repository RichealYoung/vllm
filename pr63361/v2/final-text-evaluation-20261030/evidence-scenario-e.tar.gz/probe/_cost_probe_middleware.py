# SPDX-License-Identifier: Apache-2.0
"""ASGI middleware starting the R and A spans for chat completion requests.

Loaded with ``--middleware vllm._cost_probe_middleware.CostProbeMiddleware``.
R ends at the first line of the chat endpoint (``mark_endpoint``); A ends
after the request is encoded for EngineCore (``finish_api_total``).
"""

import time

from vllm import _cost_probe as probe


class CostProbeMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if (not probe.ENABLED or scope.get("type") != "http"
                or scope.get("method") != "POST"
                or not scope.get("path", "").endswith("/v1/chat/completions")):
            await self.app(scope, receive, send)
            return
        holder = {
            "t0": time.perf_counter_ns(),
            "cpu0": time.thread_time_ns(),
            "body_bytes": 0,
            "rid": None,
        }
        probe.CURRENT_HTTP.set(holder)

        async def counting_receive():
            message = await receive()
            if message.get("type") == "http.request":
                holder["body_bytes"] += len(message.get("body", b""))
            return message

        await self.app(scope, counting_receive, send)


def mark_endpoint(rid: str) -> None:
    """First line of the chat endpoint: close R and bind the request ID."""
    if not probe.ENABLED:
        return
    w1 = time.perf_counter_ns()
    c1 = time.thread_time_ns()
    holder = probe.CURRENT_HTTP.get()
    probe.CURRENT_RID.set(rid)
    if holder is None:
        probe.record("R", rid, None, None, None, w1, status="missing_holder")
        return
    holder["rid"] = rid
    probe.record("R", rid, w1 - holder["t0"], c1 - holder["cpu0"],
                 holder["t0"], w1, body_bytes=holder["body_bytes"])


def finish_api_total(rid) -> None:
    """After E: close A for the current HTTP request."""
    if not probe.ENABLED:
        return
    w1 = time.perf_counter_ns()
    holder = probe.CURRENT_HTTP.get()
    if holder is None or holder.get("a_done"):
        return
    holder["a_done"] = True
    probe.record("A", rid if rid is not None else holder.get("rid"),
                 w1 - holder["t0"], None, holder["t0"], w1,
                 http_rid=holder.get("rid"))
