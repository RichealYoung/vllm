"""Edit-position worst-case microbenchmark (CPU, F tree).

For long base requests, the history holds the base prompt; then a variant is
sent in the same session. Variants: next step (normal append), a one-word edit
inside the message at 10/50/90 % of the rendered text, deletion of a middle
assistant tool call with its tool result (compaction), and an edit at the very
start of the system message. Measured per variant, in a fresh process state
per repetition (new caches; base published first, untimed):

  F: T encode (incl. its suffix tokenization) + H prefix + Request construction
     with initial hashes + H publish
  N: native tokenization + Request construction with native hashing

Every F result is checked against native IDs and native hashes.

  python edit_bench.py --workload-e W --workload-a WA --model M --out OUT --repeats 20
"""
import argparse
import copy
import json
import statistics as st
import time
from dataclasses import replace
from pathlib import Path

from oracle_e import to_template


def edit_word(text, pos):
    """Replace the alphabetic character nearest to pos with a different one."""
    for d in range(len(text)):
        for p in (pos + d, pos - d):
            if 0 <= p < len(text) and text[p].isalpha():
                return text[:p] + ("q" if text[p] != "q" else "z") + text[p + 1:]
    return text + " q"


def variants(messages, tools, tok, next_messages):
    def render(m):
        return tok.apply_chat_template(m, tools=tools, tokenize=False, add_generation_prompt=True,
                                       enable_thinking=False)
    base = render(messages)
    out = {}
    if next_messages is not None:
        out["append"] = render(next_messages)
    # Map rendered-text fractions to messages via cumulative rendered lengths.
    bounds = [len(render(messages[: i + 1])) for i in range(len(messages))]
    for frac in (0.1, 0.5, 0.9):
        target = int(frac * len(base))
        i = next(k for k, b in enumerate(bounds) if b >= target)
        m = copy.deepcopy(messages)
        content = m[i].get("content") or ""
        if not content:
            i = next(k for k in range(i, len(m)) if m[k].get("content"))
            content = m[i]["content"]
        m[i]["content"] = edit_word(content, len(content) // 2)
        out[f"edit{int(frac * 100)}"] = render(m)
    tool_idx = [k for k, x in enumerate(messages) if x["role"] == "tool"]
    if len(tool_idx) >= 3:
        k = tool_idx[len(tool_idx) // 2]
        # The tool call (k - 1) and its result (k) disappear together.
        out["drop_middle_tool"] = render(messages[: k - 1] + messages[k + 1:])
    m = copy.deepcopy(messages)
    m[0]["content"] = edit_word(m[0]["content"], 0)
    out["edit_system_start"] = render(m)
    return base, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workload-e", required=True)
    ap.add_argument("--workload-a", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--repeats", type=int, default=20)
    args = ap.parse_args()
    from vllm import SamplingParams
    from vllm.renderers.params import TokenizeParams
    from vllm.renderers.session_prefix import SessionTokenCache
    from vllm.tokenizers import get_tokenizer
    from vllm.utils.hashing import sha256
    from vllm.v1.core.kv_cache_utils import get_request_block_hasher, init_none_hash
    from vllm.v1.core.session_prefix import SessionHashCache
    from vllm.v1.engine import EngineCoreRequest
    from vllm.v1.request import Request

    tok = get_tokenizer(args.model)
    init_none_hash(sha256)
    hasher = get_request_block_hasher(16, sha256)
    params = TokenizeParams(max_total_tokens=40960, add_special_tokens=False)
    kwargs = params.get_encode_kwargs()

    bases = []
    we = json.loads(Path(args.workload_e).read_text(encoding="utf-8"))
    for traj in we["trajectories"][:4]:
        msgs = to_template(traj["messages"])
        steps = traj["steps"]
        j = len(steps) - 2  # long, and the next step exists
        bases.append((f"E:{traj['trajectory_id']}:{j}", msgs[: steps[j]["end"]], traj["tools"],
                      msgs[: steps[j + 1]["end"]]))
    wa = json.loads(Path(args.workload_a).read_text(encoding="utf-8"))["payload"]["workloads"]["coding"]
    for lane in (0, 1):
        bases.append((f"A:lane{lane}:18", wa[lane][18]["messages"], None, wa[lane][19]["messages"]))

    def ereq(rid, ids, session):
        return EngineCoreRequest(request_id=rid, prompt_token_ids=ids, mm_features=None,
                                 sampling_params=SamplingParams(max_tokens=1), pooling_params=None,
                                 arrival_time=0.0, lora_request=None, cache_salt=None,
                                 data_parallel_rank=None, session_id=session)

    results = []
    for name, msgs, tools, nxt in bases:
        base_text, vs = variants(msgs, tools, tok, nxt)
        base_ids = list(tok(base_text, **kwargs)["input_ids"])
        for vname, vtext in vs.items():
            native_ids = list(tok(vtext, **kwargs)["input_ids"])
            native_hashes = Request.from_engine_core_request(ereq("n", list(native_ids), "s"), hasher).block_hashes
            f_ms, n_ms, info = [], [], None
            for r in range(args.repeats):
                tcache = SessionTokenCache(tok, 512 << 20)
                hcache = SessionHashCache(128 << 20, 16)
                ctx = tcache.context("s", None)
                tcache.encode(tok, base_text, replace(params, session_prefix_context=ctx))
                ctx.finish(publish=True)
                breq = ereq("b", list(base_ids), "s")
                hcache.publish(breq, Request.from_engine_core_request(breq, hasher), hcache.store.epoch)
                before = dict(tcache.stats)
                # F path.
                t0 = time.perf_counter_ns()
                ctx = tcache.context("s", None)
                ids = tcache.encode(tok, vtext, replace(params, session_prefix_context=ctx))
                ctx.finish(publish=True)
                req = ereq("v", list(ids), "s")
                prefix = hcache.prefix(req)
                actual = Request.from_engine_core_request(req, hasher, prefix.initial_block_hashes if prefix else None)
                hcache.publish(req, actual, hcache.store.epoch, prefix)
                t1 = time.perf_counter_ns()
                assert list(ids) == native_ids and actual.block_hashes == native_hashes, (name, vname)
                # N path.
                t2 = time.perf_counter_ns()
                n_ids = list(tok(vtext, **kwargs)["input_ids"])
                Request.from_engine_core_request(ereq("n2", n_ids, None), hasher)
                t3 = time.perf_counter_ns()
                f_ms.append((t1 - t0) / 1e6)
                n_ms.append((t3 - t2) / 1e6)
                if info is None:
                    route = next((k for k in ("exact", "partial", "miss") if tcache.stats[k] != before.get(k, 0)),
                                 "declined")
                    info = {"route": route,
                            "t_reused_tokens": tcache.stats["reused_tokens"] - before.get("reused_tokens", 0),
                            "h_reused_blocks": len(prefix.hashes) if prefix else 0}
            row = {"base": name, "variant": vname, "tokens": len(native_ids), **info,
                   "f_ms_median": st.median(f_ms), "n_ms_median": st.median(n_ms),
                   "saved_ms_median": st.median(n - f for n, f in zip(n_ms, f_ms)),
                   "f_ms_range": [min(f_ms), max(f_ms)], "n_ms_range": [min(n_ms), max(n_ms)]}
            results.append(row)
            print(json.dumps(row), flush=True)
    Path(args.out).write_text(json.dumps(results, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
