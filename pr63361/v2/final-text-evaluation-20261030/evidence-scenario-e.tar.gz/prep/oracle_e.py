"""Scenario E correctness oracle (CPU): every frozen request through the real
F-tree SessionTokenCache and SessionHashCache, in trajectory order, compared
with native full tokenization and native full block hashing.

Run with PYTHONPATH=<overlay>:<F tree>, CUDA hidden.
  python oracle_e.py --workload workload-e.json --model M --out oracle.json
"""
import argparse
import json
import time
from collections import Counter
from dataclasses import replace
from pathlib import Path


def to_template(messages):
    """vLLM passes tool_call arguments to HF templates as dicts."""
    out = []
    for m in messages:
        m = dict(m)
        if m.get("tool_calls"):
            m["tool_calls"] = [dict(c, function=dict(c["function"], arguments=json.loads(c["function"]["arguments"])))
                               for c in m["tool_calls"]]
        out.append(m)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workload", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    from vllm import SamplingParams
    from vllm.renderers.params import TokenizeParams
    from vllm.renderers.session_prefix import SessionTokenCache
    from vllm.tokenizers import get_tokenizer
    from vllm.utils.hashing import sha256
    from vllm.v1.core.kv_cache_utils import get_request_block_hasher, init_none_hash
    from vllm.v1.core.session_prefix import SessionHashCache
    from vllm.v1.engine import EngineCoreRequest
    from vllm.v1.request import Request

    tok = get_tokenizer(args.model)
    tcache = SessionTokenCache(tok, 512 << 20)
    assert tcache.enabled, "token cache disabled for the audited tokenizer"
    init_none_hash(sha256)
    hasher = get_request_block_hasher(16, sha256)
    hcache = SessionHashCache(128 << 20, 16)
    base = TokenizeParams(max_total_tokens=40960, add_special_tokens=False)
    workload = json.loads(Path(args.workload).read_text(encoding="utf-8"))
    routes, mismatches, rows = Counter(), [], []
    t0 = time.time()
    for traj in workload["trajectories"]:
        session = "oracle:" + traj["trajectory_id"]
        msgs = to_template(traj["messages"])
        for step in traj["steps"]:
            text = tok.apply_chat_template(msgs[: step["end"]], tools=traj["tools"], tokenize=False,
                                           add_generation_prompt=True, enable_thinking=False)
            native = list(tok(text, **base.get_encode_kwargs())["input_ids"])
            before = dict(tcache.stats)
            ctx = tcache.context(session, None)
            ids = tcache.encode(tok, text, replace(base, session_prefix_context=ctx))
            ctx.finish(publish=True)
            route = next((k for k in ("exact", "partial", "miss") if tcache.stats[k] != before.get(k, 0)), "none")
            routes[route] += 1
            ok_t = ids is not None and list(ids) == native
            incoming = EngineCoreRequest(request_id=f"{session}:{step['step']}", prompt_token_ids=list(native),
                                         mm_features=None, sampling_params=SamplingParams(max_tokens=1),
                                         pooling_params=None, arrival_time=0.0, lora_request=None,
                                         cache_salt=None, data_parallel_rank=None, session_id=session)
            prefix = hcache.prefix(incoming)
            actual = Request.from_engine_core_request(incoming, hasher,
                                                      prefix.initial_block_hashes if prefix else None)
            expected = Request.from_engine_core_request(incoming, hasher).block_hashes
            ok_h = actual.block_hashes == expected
            hcache.publish(incoming, actual, hcache.store.epoch, prefix)
            row = {"trajectory_id": traj["trajectory_id"], "step": step["step"], "route": route,
                   "prompt_tokens": len(native), "preview": step["prompt_tokens_preview"],
                   "reused_tokens": tcache.stats["reused_tokens"] - before.get("reused_tokens", 0),
                   "reused_blocks": len(prefix.hashes) if prefix else 0, "ok_t": ok_t, "ok_h": ok_h}
            rows.append(row)
            if not (ok_t and ok_h and len(native) == step["prompt_tokens_preview"]):
                mismatches.append(row)
    later = [r for r in rows if r["step"] > 0]
    summary = {"requests": len(rows), "routes": dict(routes), "mismatches": len(mismatches),
               "first_mismatches": mismatches[:5],
               "t_reuse_fraction_later": sum(r["reused_tokens"] for r in later) / sum(r["prompt_tokens"] for r in later),
               "h_reuse_fraction_later": sum(r["reused_blocks"] * 16 for r in later)
               / sum(r["prompt_tokens"] // 16 * 16 for r in later),
               "later_not_partial": sum(1 for r in later if r["route"] != "partial"),
               "seconds": time.time() - t0, "stats_t": dict(tcache.stats), "stats_h": dict(hcache.stats)}
    Path(args.out).write_text(json.dumps({"summary": summary, "rows": rows}, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    if mismatches:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
