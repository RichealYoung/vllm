"""Freeze the scenario E workload and schedule from the previewed candidates.

Selection (frozen rule, DECISIONS item 8/9): candidates with exit_status ==
"submit", >= 30 steps and first request <= 10k tokens; 16 drawn with a fixed
seed; 4 batches of 4. Requests are prefixes of the trajectory before each
assistant message, truncated at the first step whose prompt + output would
exceed 40960. max_tokens = recorded assistant length clamped to [16, 1024].
Think time per step: lognormal(median 2 s, sigma 1.0) capped at 10 s; batch
start offsets uniform in [0, 60) s. All draws use fixed seeds here; runs only
read the frozen file.

Messages keep the OpenAI request format (tool_calls arguments as JSON strings,
tool messages without the non-standard name field).

  python freeze_e.py --raw DIR --stats stats.json --out workload-e.json
"""
import argparse
import ast
import hashlib
import json
import math
import random
from pathlib import Path

SEED = 20261030
N_TRAJ, BATCHES = 16, 4
FIRST_MAX = 10_000
MAX_MODEL_LEN, OUT_MIN, OUT_MAX = 40960, 16, 1024
THINK_MEDIAN, THINK_SIGMA, THINK_CAP = 2.0, 1.0, 10.0
START_WINDOW = 60.0


def api_messages(trajectory):
    out = []
    for m in trajectory:
        msg = {"role": m["role"], "content": m.get("content") or ""}
        tc = m.get("tool_calls")
        if tc not in (None, "None", ""):
            calls = ast.literal_eval(tc) if isinstance(tc, str) else tc
            msg["tool_calls"] = [{"id": c["id"], "type": "function",
                                  "function": {"name": c["function"]["name"],
                                               "arguments": c["function"]["arguments"]
                                               if isinstance(c["function"]["arguments"], str)
                                               else json.dumps(c["function"]["arguments"])}}
                                 for c in calls]
        if m["role"] == "tool":
            msg["tool_call_id"] = m.get("tool_call_id")
        out.append(msg)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    manifest = json.loads(Path(args.raw, "manifest.json").read_text(encoding="utf-8"))
    rows = {}
    for page in manifest["pages"]:
        data = Path(args.raw, page["file"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == page["sha256"], page["file"]
        for r in json.loads(data.decode("utf-8"))["rows"]:
            rows[r["row"]["trajectory_id"]] = r["row"]
    stats = {t["trajectory_id"]: t for t in json.loads(Path(args.stats).read_text(encoding="utf-8"))["trajectories"]}
    eligible = sorted(t for t, s in stats.items()
                      if s["exit_status"] == "submit" and s["steps"] >= 30 and "kept_steps" in s
                      and s["first_tokens"] is not None and s["first_tokens"] <= FIRST_MAX)
    rng = random.Random(SEED)
    chosen = rng.sample(eligible, N_TRAJ)
    rng.shuffle(chosen)
    think_rng = random.Random(SEED + 1)
    start_rng = random.Random(SEED + 2)
    trajectories = []
    for k, tid in enumerate(chosen):
        row, st = rows[tid], stats[tid]
        msgs = api_messages(row["trajectory"])
        ends = [i for i, m in enumerate(msgs) if m["role"] == "assistant"][: st["kept_steps"]]
        steps = []
        for j, end in enumerate(ends):
            out = st["output_tokens"][j]
            max_tokens = min(OUT_MAX, max(OUT_MIN, out if out is not None else OUT_MIN))
            assert st["prompt_tokens"][j] + max_tokens <= MAX_MODEL_LEN
            think = min(THINK_CAP, math.exp(math.log(THINK_MEDIAN) + THINK_SIGMA * think_rng.gauss(0, 1)))
            steps.append({"step": j, "end": end, "max_tokens": max_tokens,
                          "prompt_tokens_preview": st["prompt_tokens"][j],
                          "think_after_s": round(think, 3)})
        trajectories.append({"trajectory_id": tid, "batch": k // (N_TRAJ // BATCHES),
                             "slot": k % (N_TRAJ // BATCHES),
                             "start_offset_s": round(start_rng.uniform(0, START_WINDOW), 3),
                             "repo": row["repo"], "instance_id": row["instance_id"],
                             "messages": msgs[: ends[-1]], "tools": row["tools"], "steps": steps})
    body = {"source": {"dataset": manifest["dataset"], "revision": manifest["revision"],
                       "raw_manifest_sha256": hashlib.sha256(Path(args.raw, "manifest.json").read_bytes()).hexdigest(),
                       "stats_sha256": hashlib.sha256(Path(args.stats).read_bytes()).hexdigest(),
                       "license": "CC-BY-4.0"},
            "rule": {"seed": SEED, "n_trajectories": N_TRAJ, "batches": BATCHES,
                     "first_request_max_tokens": FIRST_MAX, "max_model_len": MAX_MODEL_LEN,
                     "output_clamp": [OUT_MIN, OUT_MAX],
                     "think_time": {"distribution": "lognormal", "median_s": THINK_MEDIAN,
                                    "sigma": THINK_SIGMA, "cap_s": THINK_CAP, "seed": SEED + 1},
                     "start_offsets": {"uniform_s": [0, START_WINDOW], "seed": SEED + 2},
                     "eligible_candidates": len(eligible)},
            "trajectories": trajectories}
    text = json.dumps(body, ensure_ascii=False, sort_keys=True)
    Path(args.out).write_text(text, encoding="utf-8")
    print(json.dumps({"sha256": hashlib.sha256(text.encode()).hexdigest(), "eligible": len(eligible),
                      "requests": sum(len(t["steps"]) for t in trajectories),
                      "per_batch_steps": [[len(t["steps"]) for t in trajectories if t["batch"] == b]
                                          for b in range(BATCHES)]}, indent=1))


if __name__ == "__main__":
    main()
