"""Scenario E data preview: convert OpenHands trajectories to chat requests and
report per-trajectory statistics with the real Qwen3 template and tokenizer.

Untrusted input: rows JSON from the datasets-server rows API. Parsed only with
json and ast.literal_eval (no code execution). Run with python -I.

  python -I stats_e.py --raw DIR --model M --out OUT.json
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path

MAX_MODEL_LEN = 40960
OUTPUT_CAP = 1024
OUTPUT_FLOOR = 16


def convert(trajectory):
    """OpenHands messages -> OpenAI chat messages with structured tool calls."""
    out = []
    for m in trajectory:
        msg = {"role": m["role"], "content": m.get("content") or ""}
        tc = m.get("tool_calls")
        if tc not in (None, "None", ""):
            calls = ast.literal_eval(tc) if isinstance(tc, str) else tc
            for c in calls:
                args = c["function"]["arguments"]
                if isinstance(args, str):
                    c["function"]["arguments"] = json.loads(args)
            msg["tool_calls"] = calls
        if m["role"] == "tool":
            msg["tool_call_id"] = m.get("tool_call_id")
            msg["name"] = m.get("name")
        out.append(msg)
    return out


def render(tok, messages, tools, gen):
    return tok.apply_chat_template(messages, tools=tools, tokenize=False,
                                   add_generation_prompt=gen, enable_thinking=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    manifest = json.loads(Path(args.raw, "manifest.json").read_text(encoding="utf-8"))
    rows = []
    for page in manifest["pages"]:
        data = Path(args.raw, page["file"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == page["sha256"], page["file"]
        rows += [r["row"] | {"_row_idx": r.get("row_idx")}
                 for r in json.loads(data.decode("utf-8"))["rows"]]
    stats = []
    for r in rows:
        entry = {"trajectory_id": r["trajectory_id"], "row_idx": r["_row_idx"],
                 "exit_status": r["exit_status"], "resolved": r["resolved"],
                 "messages": len(r["trajectory"]),
                 "steps": sum(1 for m in r["trajectory"] if m["role"] == "assistant")}
        # Token statistics only for trajectories that can pass the selection rule.
        if r["exit_status"] != "submit" or entry["steps"] < 30:
            stats.append(entry)
            continue
        try:
            msgs = convert(r["trajectory"])
            tools = r["tools"]
            idx = [i for i, m in enumerate(msgs) if m["role"] == "assistant"]
            entry["steps"] = len(idx)
            prompts, outputs, deltas = [], [], []
            prev = None
            for i in idx:
                text = render(tok, msgs[:i], tools, True)
                n = len(tok.encode(text, add_special_tokens=False))
                full = render(tok, msgs[:i + 1], tools, False)
                if not full.startswith(text):
                    entry["non_prefix_render"] = entry.get("non_prefix_render", 0) + 1
                out = len(tok.encode(full[len(text):], add_special_tokens=False)) if full.startswith(text) else None
                o = min(OUTPUT_CAP, max(OUTPUT_FLOOR, out or OUTPUT_FLOOR))
                if n + o > MAX_MODEL_LEN:
                    entry["truncated_at_step"] = len(prompts)
                    break
                if prev is not None and not text.startswith(prev):
                    entry["non_append_steps"] = entry.get("non_append_steps", 0) + 1
                prompts.append(n)
                outputs.append(out)
                deltas.append(n - (stats_prev := (prompts[-2] if len(prompts) > 1 else 0)))
                prev = text
            entry.update(kept_steps=len(prompts), first_tokens=prompts[0] if prompts else None,
                         last_tokens=prompts[-1] if prompts else None, prompt_tokens=prompts,
                         output_tokens=outputs, delta_tokens=deltas[1:])
        except Exception as exc:  # recorded, never raised
            entry["error"] = repr(exc)[:300]
        stats.append(entry)
        print(entry["trajectory_id"], entry.get("steps"), entry.get("kept_steps"),
              entry.get("first_tokens"), entry.get("last_tokens"), entry.get("error", ""), flush=True)
    Path(args.out).write_text(json.dumps({"manifest": manifest, "trajectories": stats}), encoding="utf-8")


if __name__ == "__main__":
    main()
