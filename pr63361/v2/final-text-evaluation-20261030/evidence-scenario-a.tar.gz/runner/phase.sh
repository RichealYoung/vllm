#!/bin/bash
# Run one phase of scenario A as a sequence of run_job jobs (one fresh server each).
# Stops at the first failed run; finished runs are never rerun or overwritten.
#   phase.sh <attempt> smoke|perturb|cost|perf
set -uo pipefail
X=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030
P=/root/autodl-tmp/codex-projects/vllm-main-cu13
attempt=$1; phase=$2
case $phase in
  smoke)   runs="smoke-F-probe:F:probe:smoke smoke-N-probe:N:probe:smoke" ;;
  # Three independent plain/probe pairs per version, order alternating.
  perturb) runs="pt1-N-plain:N:plain:perturb pt1-N-probe:N:probe:perturb pt1-F-probe:F:probe:perturb pt1-F-plain:F:plain:perturb
                 pt2-N-probe:N:probe:perturb pt2-N-plain:N:plain:perturb pt2-F-plain:F:plain:perturb pt2-F-probe:F:probe:perturb
                 pt3-N-plain:N:plain:perturb pt3-N-probe:N:probe:perturb pt3-F-probe:F:probe:perturb pt3-F-plain:F:plain:perturb" ;;
  cost)    runs="cost-b1-N:N:probe:cost cost-b1-F:F:probe:cost cost-b2-F:F:probe:cost cost-b2-N:N:probe:cost
                 cost-b3-N:N:probe:cost cost-b3-F:F:probe:cost cost-b4-F:F:probe:cost cost-b4-N:N:probe:cost" ;;
  perf)    runs="perf-b1-N:N:plain:perf perf-b1-F:F:plain:perf perf-b2-F:F:plain:perf perf-b2-N:N:plain:perf
                 perf-b3-N:N:plain:perf perf-b3-F:F:plain:perf perf-b4-F:F:plain:perf perf-b4-N:N:plain:perf" ;;
  *) echo "unknown phase"; exit 2 ;;
esac
mkdir -p $X/exp/attempts/$attempt
for spec in $runs; do
  IFS=: read -r run version tree part <<< "$spec"
  case $part in perf) est=1800 ;; *) est=900 ;; esac
  echo "$(date -u +%FT%TZ) start $run" | tee -a $X/exp/attempts/$attempt/phase-$phase.log
  $P/.venv/bin/python /root/autodl-tmp/shared/tools/run_job.py --project codex-pr63361 \
    --id "claude-final-a-$attempt-${run,,}" --resource benchmark \
    --purpose "Scenario A $phase $run ($version/$tree)" --expected-seconds $est --wait-seconds 3600 \
    --actor Claude --role support --workspace $X --cwd $X -- \
    $P/.venv/bin/python $X/runner/run_a.py run --root $X/exp --attempt $attempt --run-id $run \
      --version $version --tree $tree --part $part \
    >> $X/exp/attempts/$attempt/phase-$phase.log 2>&1 < /dev/null
  rc=$?
  echo "$(date -u +%FT%TZ) end $run rc=$rc" | tee -a $X/exp/attempts/$attempt/phase-$phase.log
  [ $rc -eq 0 ] || { echo "STOPPED at $run"; exit 1; }
done
echo "PHASE-DONE $phase"
