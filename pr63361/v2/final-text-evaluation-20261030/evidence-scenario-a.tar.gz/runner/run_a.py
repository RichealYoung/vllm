"""Final T+H text experiment, scenario A (serial) and Part I cost: driver.

Subcommands
  prepare  --root R --workload W --model M --baseline-warmup B
           Validate the frozen workload, write the serial schedule, copy the
           frozen 8-request warmup set of the baseline profile (SHA-checked) and
           generate 2 two-turn reuse-warmup conversations (structure-matched,
           content-independent), then write config.json. CPU only.
  run      --root R --attempt A --run-id ID --version {N,F} --tree {probe,plain}
           --part {cost,perf,perturb,smoke}
           One fresh server: warmup (8 without hint + 4 reuse-warmup requests
           with a separate salt), prefix-cache reset, serial replay, shutdown.

Every server uses identical native settings; F only adds the T/H budgets.
The server is pinned to SERVER_CPUS and this client to CLIENT_CPUS.
"""

import argparse
import asyncio
import hashlib
import json
import os
import random
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

SERVER_CPUS = list(range(12))
CLIENT_CPUS = [12, 13]
MODEL_NAME = "session-prefix-bench"
SAMPLING = {"temperature": 0, "top_p": 1, "seed": 42, "ignore_eos": True,
            "stop": [], "chat_template_kwargs": {"enable_thinking": False}}
OUTPUT_TOKENS = {"cost": 16, "perf": 448, "perturb": 16, "smoke": 16}
REQUEST_TIMEOUT_S = 180
WINDOW_TIMEOUT_S = {"cost": 15 * 60, "perf": 40 * 60, "perturb": 15 * 60, "smoke": 15 * 60}
STARTUP_TIMEOUT_S = 5 * 60
F_BUDGETS_MIB = {"session_token_cache_mb": 512, "session_hash_cache_mb": 128}
WARM_SALT = "final-text-a-warmup-reuse"
PROJECT = "/root/autodl-tmp/codex-projects/vllm-main-cu13"
PY = f"{PROJECT}/.venv/bin/python"
OVERLAY = (f"{PROJECT}/experiments/session-prefix-version-range-20261024-001/"
           "overlays/tf5.20.2-tok0.23.2")
WORKLOAD_SHA = "935e387020d27548aba5da24c997c9381a03bd4fc8735e3d1ef5e3c2dd44f833"
BASELINE_WARMUP_SHA = "b7efef86"  # prefix recorded in the baseline profile README
SHORT_TMPDIR = "/root/autodl-tmp/claude-projects/reviews/pr63361/bic-tmp"
# Perturbation/smoke subset: per session the first turn, the first partial
# turn, a middle turn and the longest turn (serial order is kept).
SUBSET_INDEXES = (0, 1, 10, 19)


# ---------------------------------------------------------------- utilities

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def write_json(path, value, exclusive=True):
    with Path(path).open("x" if exclusive else "w", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_workload(path):
    if sha256_file(path) != WORKLOAD_SHA:
        raise SystemExit("workload SHA256 mismatch")
    obj = read_json(path)
    if canonical_digest(obj["payload"]) != obj["sha256"]:
        raise SystemExit("workload payload digest mismatch")
    data = obj["payload"]
    if canonical_digest(data["contract"]) != data["contract_sha256"]:
        raise SystemExit("workload contract digest mismatch")
    lanes = data["workloads"]["coding"]
    if len(lanes) != 4 or any(len(lane) != 20 for lane in lanes):
        raise SystemExit("expected 4 coding lanes x 20 turns")
    return data


def server_env(tree_dir, cache_root, probe_dir=None):
    env = {
        "PATH": f"{PROJECT}/.venv/bin:{PROJECT}/toolchains/cuda-sdk-013/bin:/bin:/usr/bin",
        "PYTHONPATH": f"{OVERLAY}:{tree_dir}",
        "LD_LIBRARY_PATH": f"{PROJECT}/toolchains/gcc-13/lib:{PROJECT}/toolchains/cuda-sdk-013/lib64:",
        "LD_PRELOAD": (f"{PROJECT}/toolchains/gcc-13/lib/gcc/x86_64-conda-linux-gnu/13.4.0/libstdc++.so.6:"
                       f"{PROJECT}/toolchains/gcc-13/lib/gcc/x86_64-conda-linux-gnu/13.4.0/libgcc_s.so.1"),
        "CUDA_HOME": f"{PROJECT}/toolchains/cuda-sdk-013",
        "VIRTUAL_ENV": f"{PROJECT}/.venv",
        # Private caches/tmp; TMPDIR stays short (ZMQ IPC paths <= 107 chars).
        "TMPDIR": SHORT_TMPDIR,
        "XDG_CACHE_HOME": f"{cache_root}/cache",
        "TRITON_CACHE_DIR": f"{cache_root}/cache/triton",
        "TORCHINDUCTOR_CACHE_DIR": f"{cache_root}/cache/torchinductor",
        "TORCH_EXTENSIONS_DIR": f"{cache_root}/cache/torch-extensions",
        "CUDA_CACHE_PATH": f"{cache_root}/cache/cuda",
        "VLLM_CACHE_ROOT": f"{cache_root}/cache/vllm",
        "FLASHINFER_WORKSPACE_BASE": f"{cache_root}",
        "HF_HOME": f"{cache_root}/cache/huggingface",
        "HF_HUB_CACHE": "/root/autodl-tmp/shared/cache/huggingface/hub",
        "TORCH_CUDA_ARCH_LIST": "8.6",
        "HOME": "/root",
        "LANG": "C.UTF-8",
        "TOKENIZERS_PARALLELISM": "false",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "VLLM_LOGGING_LEVEL": "INFO",
        "VLLM_NO_USAGE_STATS": "1",
        "DO_NOT_TRACK": "1",
        "VLLM_SERVER_DEV_MODE": "1",
        "HF_HUB_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    for key in ("TMPDIR", "XDG_CACHE_HOME"):
        Path(env[key]).mkdir(parents=True, exist_ok=True)
    if probe_dir is not None:
        env["COST_PROBE_DIR"] = str(probe_dir)
    return env


def server_argv(model, port, version, tree):
    argv = ["taskset", "-c", ",".join(map(str, SERVER_CPUS)), PY, "-m",
            "vllm.entrypoints.cli.main", "serve", model,
            "--served-model-name", MODEL_NAME, "--host", "127.0.0.1",
            "--port", str(port), "--dtype", "float16", "--max-model-len", "40960",
            "--max-num-seqs", "4", "--max-num-batched-tokens", "4096",
            "--kv-cache-memory-bytes", str(18 * 1024**3),
            "--enable-prefix-caching", "--enable-chunked-prefill",
            "--async-scheduling", "--disable-log-requests",
            "--disable-uvicorn-access-log", "--seed", "42",
            "--shutdown-timeout", "30", "--enable-prompt-tokens-details"]
    if version == "F":
        argv += ["--session-token-cache-mb", str(F_BUDGETS_MIB["session_token_cache_mb"]),
                 "--session-hash-cache-mb", str(F_BUDGETS_MIB["session_hash_cache_mb"])]
    if tree == "probe":
        argv += ["--middleware", "vllm._cost_probe_middleware.CostProbeMiddleware"]
    return argv


def cpu_snapshot():
    out = {"time_ns": time.time_ns(), "cpus": {}}
    for cpu in SERVER_CPUS + CLIENT_CPUS:
        base = Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq")
        entry = {}
        for name in ("scaling_governor", "scaling_cur_freq", "scaling_min_freq",
                     "scaling_max_freq"):
            try:
                entry[name] = (base / name).read_text().strip()
            except OSError:
                entry[name] = None
        out["cpus"][cpu] = entry
    temps = {}
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            temps[zone.name] = int((zone / "temp").read_text())
        except (OSError, ValueError):
            pass
    out["thermal_millicelsius"] = temps
    try:
        out["loadavg"] = Path("/proc/loadavg").read_text().strip()
    except OSError:
        out["loadavg"] = None
    return out


def process_cpu_seconds(pid):
    """utime+stime of a process tree (server and its children), in seconds."""
    ticks = os.sysconf("SC_CLK_TCK")
    total = 0.0
    pids = [pid]
    try:
        out = subprocess.run(["pgrep", "-g", str(pid)], capture_output=True, text=True).stdout
        pids = sorted({pid, *map(int, out.split())})
    except OSError:
        pass
    per = {}
    for p in pids:
        try:
            fields = Path(f"/proc/{p}/stat").read_text().rsplit(")", 1)[1].split()
            value = (int(fields[11]) + int(fields[12])) / ticks
            per[p] = value
            total += value
        except (OSError, IndexError, ValueError):
            pass
    return {"total": total, "per_pid": per}


# ---------------------------------------------------------------- prepare

REUSE_WARM_SEED = 20261030


def synthetic_vocab(rng, size=400):
    letters, vowels = "bcdfghjklmnpqrstvwxz", "aeiouy"
    words = set()
    while len(words) < size:
        n = rng.randint(2, 4)
        words.add("".join(rng.choice(letters) + rng.choice(vowels) for _ in range(n)))
    return sorted(words)


def synthetic_text(rng, vocab, tokenizer, target_tokens):
    parts, count = [], 0
    while count < target_tokens:
        sentence = " ".join(rng.choice(vocab) for _ in range(12)).capitalize() + ". "
        parts.append(sentence)
        count += len(tokenizer.encode(sentence, add_special_tokens=False))
    return "".join(parts).strip()


def prompt_tokens(tokenizer, messages):
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                         enable_thinking=False)
    return len(tokenizer.encode(text, add_special_tokens=False))


def shared_window(warm_texts, measured_texts, window=100):
    corpus = "\x00".join(measured_texts)
    for text in warm_texts:
        for start in range(0, max(1, len(text) - window + 1), window):
            if text[start:start + window] in corpus:
                return True
    return False


def prepare(args):
    from transformers import AutoTokenizer

    root = Path(args.root)
    root.mkdir(parents=True, exist_ok=True)
    data = load_workload(args.workload)
    lanes = data["workloads"]["coding"]
    schedule = [{"order": i * 4 + lane, "id": lanes[lane][i]["id"], "lane": lane,
                 "index": i, "session_id": lanes[lane][i]["session_id"],
                 "input_tokens_frozen": lanes[lane][i]["input_tokens"]}
                for i in range(20) for lane in range(4)]
    write_json(root / "schedule.json", {
        "execution_mode": "serial_round_robin", "max_inflight_requests": 1,
        "order_rule": "index ascending, then lane ascending",
        "subset_indexes": SUBSET_INDEXES, "workload_sha256": WORKLOAD_SHA,
        "requests": schedule})
    baseline = Path(args.baseline_warmup)
    if not sha256_file(baseline).startswith(BASELINE_WARMUP_SHA):
        raise SystemExit("baseline warmup SHA mismatch")
    shutil.copy2(baseline, root / "warmup-messages.json")

    # Two reuse-warmup conversations: turn 1 = system + user, turn 2 appends an
    # assistant reply and a new user message. Content independent of the
    # measured messages; sent with a separate salt so it can never match them.
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    rng = random.Random(REUSE_WARM_SEED)
    vocab = synthetic_vocab(rng)
    reuse = []
    for k, (sys_t, user_t, reply_t, delta_t) in enumerate(((2048, 6000, 448, 512),
                                                           (2048, 12000, 448, 512))):
        first = [{"role": "system", "content": synthetic_text(rng, vocab, tokenizer, sys_t)},
                 {"role": "user", "content": synthetic_text(rng, vocab, tokenizer, user_t)}]
        second = first + [{"role": "assistant", "content": synthetic_text(rng, vocab, tokenizer, reply_t)},
                          {"role": "user", "content": synthetic_text(rng, vocab, tokenizer, delta_t)}]
        for turn, messages in enumerate((first, second)):
            reuse.append({"id": f"warm-reuse-{k}-t{turn}", "session": f"warm-reuse-{k}",
                          "messages": messages, "input_tokens": prompt_tokens(tokenizer, messages)})
    measured = sorted({m["content"] for lane in lanes for row in lane for m in row["messages"]})
    if shared_window([m["content"] for r in reuse for m in r["messages"]], measured):
        raise SystemExit("reuse warmup shares a >=200-char substring with measured messages")
    write_json(root / "reuse-warmup-messages.json", {
        "seed": REUSE_WARM_SEED, "salt": WARM_SALT,
        "overlap_check": {"window_chars": 100, "result": "no_overlap"}, "requests": reuse})
    config = {
        "workload": {"path": str(Path(args.workload).resolve()), "sha256": WORKLOAD_SHA},
        "model": {"path": args.model, "revision": "c1899de289a04d12100db370d81485cdf75e47ca"},
        "warmup": {"path": str(root / "warmup-messages.json"),
                   "sha256": sha256_file(root / "warmup-messages.json"),
                   "source": str(baseline)},
        "reuse_warmup": {"path": str(root / "reuse-warmup-messages.json"),
                         "sha256": sha256_file(root / "reuse-warmup-messages.json"),
                         "input_tokens": [r["input_tokens"] for r in reuse], "salt": WARM_SALT},
        "output_tokens": OUTPUT_TOKENS, "sampling": SAMPLING,
        "server_cpus": SERVER_CPUS, "client_cpus": CLIENT_CPUS,
        "request_timeout_s": REQUEST_TIMEOUT_S, "window_timeout_s": WINDOW_TIMEOUT_S,
        "startup_timeout_s": STARTUP_TIMEOUT_S, "f_budgets_mib": F_BUDGETS_MIB,
        "formal_cache_salt": None,
        "session_naming": "<attempt>.<run-id>:<frozen session_id>",
    }
    write_json(root / "config.json", config)
    print(json.dumps({k: config[k] for k in ("warmup", "reuse_warmup")}, indent=2))


# ---------------------------------------------------------------- run

async def wait_ready(client, proc, timeout_s=STARTUP_TIMEOUT_S):
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(f"server exited early: {proc.returncode}")
        try:
            r = await client.get("/health")
            if r.status_code == 200:
                return
        except Exception:
            pass
        await asyncio.sleep(2)
    raise RuntimeError("server not ready")


async def metrics_sample(client):
    text = (await client.get("/metrics")).text
    out = {"running": None, "waiting": None, "kv_usage": None, "preemptions": None,
           "prefix_cache_queries": None, "prefix_cache_hits": None}
    for line in text.splitlines():
        if line.startswith("#"):
            continue
        name = line.split("{", 1)[0].split(" ", 1)[0]
        try:
            value = float(line.rsplit(" ", 1)[1])
        except (IndexError, ValueError):
            continue
        if name == "vllm:num_requests_running":
            out["running"] = value
        elif name == "vllm:num_requests_waiting":
            out["waiting"] = value
        elif name in ("vllm:kv_cache_usage_perc", "vllm:gpu_cache_usage_perc"):
            out["kv_usage"] = value
        elif name == "vllm:num_preemptions_total":
            out["preemptions"] = value
        elif name == "vllm:prefix_cache_queries_total":
            out["prefix_cache_queries"] = value
        elif name == "vllm:prefix_cache_hits_total":
            out["prefix_cache_hits"] = value
    return out


async def one_request(client, bench_id, messages, session_id, output_tokens, cache_salt=None):
    body = dict(SAMPLING)
    body.update(model=MODEL_NAME, messages=messages, max_tokens=output_tokens,
                stream=True, stream_options={"include_usage": True}, request_id=bench_id)
    if session_id is not None:
        body["session_id"] = session_id
    if cache_salt is not None:
        body["cache_salt"] = cache_salt
    start = time.perf_counter_ns()
    sent = first = None
    usage = finish = None
    done = False
    status, error = "ok", None
    pieces = []
    try:
        async with asyncio.timeout(REQUEST_TIMEOUT_S):
            sent = time.perf_counter_ns()
            async with client.stream("POST", "/v1/chat/completions", json=body) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    value = line[5:].strip()
                    if value == "[DONE]":
                        done = True
                        continue
                    if not value:
                        continue
                    event = json.loads(value)
                    if "error" in event:
                        raise RuntimeError(f"SSE error: {event['error']}")
                    if event.get("usage"):
                        usage = event["usage"]
                    for choice in event.get("choices", []):
                        content = choice.get("delta", {}).get("content")
                        if content:
                            pieces.append(content)
                            if first is None:
                                first = time.perf_counter_ns()
                        if choice.get("finish_reason") is not None:
                            finish = choice["finish_reason"]
        if not done or first is None or finish != "length":
            raise RuntimeError("missing output, terminal event or fixed-length finish")
        if not usage or usage.get("completion_tokens") != output_tokens:
            raise RuntimeError("completion_tokens differs from fixed output length")
        details = usage.get("prompt_tokens_details")
        if not isinstance(details, dict) or type(details.get("cached_tokens")) is not int:
            raise RuntimeError("cached_tokens missing")
    except Exception as exc:  # recorded; the caller stops the run
        status, error = "error", repr(exc)
    end = time.perf_counter_ns()
    return {"bench_id": bench_id, "start_ns": start, "sent_ns": sent, "first_chunk_ns": first,
            "end_ns": end, "ttft_s": (first - start) / 1e9 if first is not None else None,
            "e2e_s": (end - start) / 1e9, "usage": usage, "finish_reason": finish,
            "output_sha256": hashlib.sha256("".join(pieces).encode()).hexdigest(),
            "output_text": "".join(pieces), "status": status, "error": error}


async def replay(args, run_dir, proc, port):
    import httpx

    root = Path(args.root)
    config = read_json(root / "config.json")
    data = load_workload(config["workload"]["path"])
    lanes = data["workloads"]["coding"]
    schedule = read_json(root / "schedule.json")["requests"]
    if args.part in ("perturb", "smoke"):
        schedule = [r for r in schedule if r["index"] in SUBSET_INDEXES]
    warm = read_json(root / "warmup-messages.json")["requests"]
    reuse = read_json(root / "reuse-warmup-messages.json")["requests"]
    output_tokens = OUTPUT_TOKENS[args.part]
    prefix = f"{args.attempt}.{args.run_id}"
    async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}", timeout=REQUEST_TIMEOUT_S,
                                 trust_env=False, limits=httpx.Limits(max_connections=1)) as client:
        await wait_ready(client, proc)
        log_text = (run_dir / "server.log").read_text(errors="replace")
        disabled = re.findall(r"Session (?:token|hash) cache disabled[^\n]*", log_text)
        if disabled:
            raise RuntimeError(f"reuse disabled: {disabled}")
        previous = os.sched_getaffinity(0)
        os.sched_setaffinity(0, CLIENT_CPUS)
        try:
            warm_results = []
            for w in warm:  # serial, no session hint
                warm_results.append(await one_request(
                    client, f"w.{prefix}.{w['id']}", w["messages"], None, output_tokens))
            for r in reuse:  # serial, session hint and a separate salt
                warm_results.append(await one_request(
                    client, f"w.{prefix}.{r['id']}", r["messages"], f"{prefix}:{r['session']}",
                    output_tokens, cache_salt=WARM_SALT))
            write_json(run_dir / "warmup.json", warm_results)
            if any(r["status"] != "ok" for r in warm_results):
                raise RuntimeError("warmup failed")
            reset = await client.post("/reset_prefix_cache")
            reset.raise_for_status()
            if reset.json().get("success") is not True:
                raise RuntimeError("prefix cache reset refused")
            before = None
            for _ in range(30):
                before = await metrics_sample(client)
                if before["running"] == 0 and before["waiting"] == 0 and before["kv_usage"] == 0:
                    break
                await asyncio.sleep(0.5)
            else:
                raise RuntimeError("not idle or KV not empty after reset")
            cpu0 = process_cpu_seconds(proc.pid)
            write_json(run_dir / "reset-receipt.json", {"reset": reset.json(), "metrics": before,
                                                        "server_cpu_s": cpu0})
            (run_dir / "client-requests.jsonl").touch()
            window_start = time.perf_counter_ns()
            async with asyncio.timeout(WINDOW_TIMEOUT_S[args.part]):
                for row in schedule:
                    frozen = lanes[row["lane"]][row["index"]]
                    result = await one_request(client, f"m.{prefix}.{row['id']}", frozen["messages"],
                                               f"{prefix}:{frozen['session_id']}", output_tokens)
                    result.update(order=row["order"], id=row["id"], lane=row["lane"],
                                  index=row["index"], session_id=row["session_id"],
                                  input_tokens_frozen=row["input_tokens_frozen"])
                    with (run_dir / "client-requests.jsonl").open("a", encoding="utf-8") as f:
                        f.write(json.dumps(result) + "\n")
                    if result["status"] != "ok":
                        raise RuntimeError(f"request failed: {result['error']}")
            window_end = time.perf_counter_ns()
            cpu1 = process_cpu_seconds(proc.pid)
            after = await metrics_sample(client)
            write_json(run_dir / "window.json", {
                "start_ns": window_start, "end_ns": window_end,
                "batch_s": (window_end - window_start) / 1e9, "requests": len(schedule),
                "server_cpu_s": cpu1["total"] - cpu0["total"], "metrics_before": before,
                "metrics_after": after})
            if before["preemptions"] is not None and after["preemptions"] != before["preemptions"]:
                raise RuntimeError("preemption during measured window")
        finally:
            os.sched_setaffinity(0, previous)


def run(args):
    root = Path(args.root)
    run_dir = root / "attempts" / args.attempt / args.run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    trees = read_json(root / "trees.json")
    tree = trees[args.version][args.tree]
    probe_dir = run_dir / "probe" if args.tree == "probe" else None
    env = server_env(tree, str(root / "runtime-cache"), probe_dir)
    argv = server_argv(read_json(root / "config.json")["model"]["path"], args.port,
                       args.version, args.tree)
    write_json(run_dir / "command.json", {"argv": argv, "environment": env, "tree": tree,
                                          "version": args.version, "tree_kind": args.tree,
                                          "part": args.part})
    write_json(run_dir / "cpu-before.json", cpu_snapshot())
    log = (run_dir / "server.log").open("w", encoding="utf-8")
    proc = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT,
                            start_new_session=True)
    write_json(run_dir / "server-process.json", {"pid": proc.pid, "started_ns": time.time_ns()})
    error = None
    try:
        asyncio.run(replay(args, run_dir, proc, args.port))
    except BaseException as exc:
        error = repr(exc)
    finally:
        write_json(run_dir / "cpu-after.json", cpu_snapshot())
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGINT)
            try:
                proc.wait(timeout=120)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=60)
        log.close()
        leftovers = subprocess.run(["pgrep", "-g", str(proc.pid)], capture_output=True,
                                   text=True).stdout.split()
        write_json(run_dir / "server-exit.json", {"returncode": proc.returncode,
                                                  "leftover_pids": leftovers, "error": error})
    if error or leftovers:
        raise SystemExit(f"run failed: {error} leftovers={leftovers}")


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--root", required=True)
    p.add_argument("--workload", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--baseline-warmup", required=True)
    r = sub.add_parser("run")
    r.add_argument("--root", required=True)
    r.add_argument("--attempt", required=True)
    r.add_argument("--run-id", required=True)
    r.add_argument("--version", choices=("N", "F"), required=True)
    r.add_argument("--tree", choices=("probe", "plain"), required=True)
    r.add_argument("--part", choices=tuple(OUTPUT_TOKENS), required=True)
    r.add_argument("--port", type=int, default=18481)
    args = parser.parse_args()
    prepare(args) if args.cmd == "prepare" else run(args)


if __name__ == "__main__":
    main()
