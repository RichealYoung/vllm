#!/bin/bash
# Build the four experiment trees (N/F x plain/probe) and trees.json; CPU and disk only.
set -euo pipefail
X=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030
P=/root/autodl-tmp/codex-projects/vllm-main-cu13
N_SRC=$P/experiments/pr63361-main-conflict-20261026-001/attempt-r2/baseline
F_SRC=$X/validation/sources/final
mkdir -p $X/exp/trees
cd $X/exp/trees
test ! -e N-plain && test ! -e F-plain
cp -a $N_SRC N-plain
cp -a $F_SRC F-plain
$P/.venv/bin/python $X/probe/apply_probe.py N $X/exp/trees/N-plain $X/exp/trees/N-probe $X/probe > /dev/null
$P/.venv/bin/python $X/probe/apply_probe.py F $X/exp/trees/F-plain $X/exp/trees/F-probe $X/probe > /dev/null
cat > $X/exp/trees.json <<EOF
{"N": {"plain": "$X/exp/trees/N-plain", "probe": "$X/exp/trees/N-probe"},
 "F": {"plain": "$X/exp/trees/F-plain", "probe": "$X/exp/trees/F-probe"},
 "sources": {"N": "$N_SRC (85e199e60, Codex accepted baseline tree)",
             "F": "$F_SRC (797e19367, accepted in validation/)"}}
EOF
# Identity: the plain trees must equal their sources byte for byte.
diff -rq --no-dereference $N_SRC N-plain && diff -rq --no-dereference $F_SRC F-plain && echo plain-identical
ls -la N-plain/vllm/_session_prefix* 2>/dev/null || echo "N has no session-prefix helper (expected)"
ls -la F-plain/vllm/_session_prefix.abi3.so
cat $X/exp/trees/probe-edits-N.json | head -3; echo TREES-OK
