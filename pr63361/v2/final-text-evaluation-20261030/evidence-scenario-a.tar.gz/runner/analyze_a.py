"""Validate and summarize scenario A runs (read-only over raw run directories).

  python analyze_a.py runs   --root R --attempt A --run RUN [--run RUN ...]
      Per-run validation and per-request joined rows (probe runs: spans).
  python analyze_a.py perturb --root R --attempt A --pairs NP:NF ...
  python analyze_a.py cost   --root R --attempt A --blocks Nrun:Frun ...
  python analyze_a.py perf   --root R --attempt A --blocks Nrun:Frun ...

Outputs go to R/analysis/<attempt>/ (never into run directories).
Group definitions are in METRIC_MAP and are identical for every run.
"""

import argparse
import glob
import json
import statistics
from collections import defaultdict
from pathlib import Path

# Fine sections and the group each exclusive cost belongs to. Shared store
# sections are attributed by process: API process -> T, EngineCore -> H.
METRIC_MAP = {
    "groups": {
        "T-reuse": ["t_context", "t_eligible", "t_compare", "t_lcp", "t_boundary", "t_ids",
                    "t_encode_residual"],
        "T-history": ["T:borrow_enter", "T:borrow_exit", "t_bound", "t_size", "T:reserve",
                      "t_copy", "t_stage", "t_finish"],
        "H-reuse": ["h_eligible", "h_lcp", "h_slice", "h_prefix_residual"],
        "H-history": ["H:borrow_enter", "H:borrow_exit", "h_pub_check", "h_bound", "h_size_ids",
                      "h_size_hashes", "H:reserve", "h_copy", "H:commit", "H:cancel",
                      "h_publish_residual"],
    },
    "notes": {
        "t_encode_residual": "t_encode minus its timed children (eligibility, borrow, compare, "
                             "lcp, boundary, T, ids, bound, size, reserve, copy, stage); "
                             "covers stats counting, length check and glue",
        "t_finish": "includes the nested T commit/cancel",
        "h_prefix_residual": "h_prefix minus h_eligible, H borrow, h_lcp, h_slice",
        "h_publish_residual": "h_publish minus its timed children; includes key/size arithmetic",
        "request_other": "h_request minus H (native initial hashing): Request construction; "
                         "on F also the initial-hash check/copy. Reported for N and F, not in a group",
    },
    "outer": {
        "api_uncovered": "A - (R + F + I + E)",
        "frontend_other": "F - (P + M + tokenization), tokenization = T (N) or "
                          "t_context + t_encode + t_finish (+ native T when no hint)",
        "core_other": "C - (h_prefix + h_request + h_publish) (F) or C - h_request (N)",
    },
}
BINS = [(16000, 20000), (20000, 24000), (24000, 28000), (28000, 32000), (32000, 36000)]


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    p = Path(path)
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line] if p.exists() else []


def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n")


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * q
    lo = int(pos)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (pos - lo)


def mean(values):
    return statistics.fmean(values) if values else None


def median(values):
    return statistics.median(values) if values else None


def ms(ns):
    return ns / 1e6 if ns is not None else None


# ---------------------------------------------------------------- one run

def load_run(root, attempt, run):
    d = Path(root) / "attempts" / attempt / run
    cmd = read_json(d / "command.json")
    out = {"dir": str(d), "run": run, "version": cmd["version"], "tree": cmd["tree_kind"],
           "part": cmd["part"], "client": read_jsonl(d / "client-requests.jsonl"),
           "exit": read_json(d / "server-exit.json"),
           "window": read_json(d / "window.json") if (d / "window.json").exists() else None,
           "warmup": read_json(d / "warmup.json") if (d / "warmup.json").exists() else None}
    events, metas = [], []
    for f in glob.glob(str(d / "probe" / "probe-*.events.jsonl")):
        events += read_jsonl(f)
    for f in glob.glob(str(d / "probe" / "probe-*.meta.json")):
        metas.append(read_json(f))
    out["events"], out["metas"] = events, metas
    return out


def join_probe(run):
    """Per measured request: stage -> list of events, with process role."""
    events = run["events"]
    api_pids = {e["pid"] for e in events if e["stage"] == "R"}
    core_pids = {e["pid"] for e in events if e["stage"] == "C"}
    by_rid = defaultdict(lambda: defaultdict(list))
    for e in events:
        rid = e.get("rid")
        if rid is None:
            continue
        # The engine-side ID is the client request ID with a "chatcmpl-" prefix.
        rid = rid.removeprefix("chatcmpl-")
        stage = e["stage"]
        if stage in ("borrow_enter", "borrow_exit", "reserve", "commit", "cancel", "store_state"):
            side = "T" if e["pid"] in api_pids else "H" if e["pid"] in core_pids else "?"
            stage = f"{side}:{stage}"
        by_rid[rid][stage].append(e)
    return by_rid, api_pids, core_pids


def wall(evs):
    return sum(e["wall_ns"] for e in evs if e.get("wall_ns") is not None) if evs else 0


def cpu(evs):
    vals = [e["thread_cpu_ns"] for e in evs if e.get("thread_cpu_ns") is not None]
    return sum(vals) if vals else None


def request_row(run, rid, st):
    """Exclusive fine costs and outer segments for one request (ns)."""
    w = {k: wall(v) for k, v in st.items()}
    row = {"rid": rid}
    for k in ("R", "P", "M", "F", "I", "E", "A", "D", "C", "H", "h_request"):
        row[k + "_wall"] = w.get(k, 0) if k in st else None
    for k in ("R", "P", "M", "I", "E", "D", "C", "H"):
        row[k + "_cpu"] = cpu(st.get(k, []))
    t_all = st.get("T", [])
    row["T_wall"] = wall(t_all) if t_all else 0
    row["T_cpu"] = cpu(t_all)
    row["T_calls"] = len(t_all)
    row["T_kind"] = ",".join(sorted({e.get("kind", "") for e in t_all}))
    row["request_other_wall"] = (w.get("h_request", 0) - w.get("H", 0)) if "h_request" in st else None
    if run["version"] == "F":
        enc_children = ["t_eligible", "T:borrow_enter", "T:borrow_exit", "t_compare", "t_lcp",
                        "t_boundary", "T", "t_ids", "t_bound", "t_size", "T:reserve", "t_copy",
                        "t_stage"]
        row["t_encode_residual"] = w.get("t_encode", 0) - sum(w.get(k, 0) for k in enc_children)
        pre_children = ["h_eligible", "H:borrow_enter", "H:borrow_exit", "h_lcp", "h_slice"]
        row["h_prefix_residual"] = w.get("h_prefix", 0) - sum(w.get(k, 0) for k in pre_children)
        pub_children = ["h_pub_check", "h_bound", "h_size_ids", "h_size_hashes", "H:reserve",
                        "h_copy", "H:commit", "H:cancel"]
        row["h_publish_residual"] = w.get("h_publish", 0) - sum(w.get(k, 0) for k in pub_children)
        for name in {n for g in METRIC_MAP["groups"].values() for n in g}:
            row.setdefault(name, w.get(name, 0))
        for g, names in METRIC_MAP["groups"].items():
            row[g] = sum(row[n] for n in names)
        tok = w.get("t_context", 0) + w.get("t_encode", 0) + w.get("t_finish", 0)
        native_t = wall([e for e in t_all if e.get("kind") == "native"])
        row["frontend_other"] = w.get("F", 0) - w.get("P", 0) - w.get("M", 0) - tok - native_t
        row["core_other"] = w.get("C", 0) - w.get("h_prefix", 0) - w.get("h_request", 0) - w.get("h_publish", 0)
        route = (st.get("t_route") or [{}])[0]
        hinfo = (st.get("h_prefix_info") or [{}])[0]
        pinfo = (st.get("h_publish_info") or [{}])[0]
        row.update(t_route=route.get("route"), t_reused_tokens=route.get("reused_tokens"),
                   t_bound_scanned=route.get("bound_scanned_ids"),
                   h_lcp_tokens=hinfo.get("lcp_tokens"), h_reused_blocks=hinfo.get("reused_blocks"),
                   h_bound_fast=pinfo.get("bound_fast"), h_scanned_ids=pinfo.get("scanned_ids"),
                   h_new_hashes=(st.get("H") or [{}])[0].get("new_hashes"))
        states = sorted(st.get("T:store_state", []) + st.get("H:store_state", []), key=lambda e: e["seq"])
        row["t_bytes_used"] = max((e["bytes_used"] for e in st.get("T:store_state", [])), default=None)
        row["h_bytes_used"] = max((e["bytes_used"] for e in st.get("H:store_state", [])), default=None)
        row["evicted"] = sum(e.get("evicted", 0) for e in states)
        row["reserve_failed"] = sum(1 for e in states if e.get("after") == "reserve" and not e.get("ok"))
    else:
        row["frontend_other"] = w.get("F", 0) - w.get("P", 0) - w.get("M", 0) - w.get("T", 0)
        row["core_other"] = w.get("C", 0) - w.get("h_request", 0)
    if all(k in st for k in ("A", "R", "F", "I", "E")):
        row["api_uncovered"] = w["A"] - (w["R"] + w["F"] + w["I"] + w["E"])
    row["gc_wall"] = None
    return row


def validate_run(run):
    problems = []
    if run["exit"]["error"] or run["exit"]["leftover_pids"]:
        problems.append(f"exit: {run['exit']}")
    client = run["client"]
    if not client or any(r["status"] != "ok" for r in client):
        problems.append("client failures or empty")
    rows = []
    if run["tree"] == "probe":
        if any(m["overflow"] for m in run["metas"]):
            problems.append("probe overflow")
        by_rid, api, core = join_probe(run)
        if len(api) != 1 or len(core) != 1:
            problems.append(f"process roles api={api} core={core}")
        required = ["R", "P", "M", "F", "I", "E", "A", "D", "C", "H", "h_request"]
        if run["version"] == "F":
            required += ["t_context", "t_encode", "t_eligible", "T:borrow_enter", "T:borrow_exit",
                         "t_size", "T:reserve", "t_copy", "t_stage", "t_finish", "t_route",
                         "h_prefix", "h_eligible", "H:borrow_enter", "h_publish", "h_pub_check",
                         "h_bound", "h_size_ids", "h_size_hashes", "H:reserve", "h_copy",
                         "H:commit", "h_publish_info"]
        for r in client:
            st = by_rid.get(r["bench_id"])
            if st is None:
                problems.append(f"no events {r['bench_id']}")
                continue
            missing = [k for k in required if k not in st]
            dup = [k for k in ("R", "F", "A", "C", "E", "D", "h_request", "t_encode", "h_prefix",
                               "h_publish") if len(st.get(k, [])) > 1]
            if missing or dup:
                problems.append(f"{r['bench_id']} missing={missing} dup={dup}")
            if any(e["status"] != "ok" for evs in st.values() for e in evs if "status" in e):
                problems.append(f"{r['bench_id']} span error")
            row = request_row(run, r["bench_id"], st)
            if run["version"] == "F":
                for k in ("t_encode_residual", "h_prefix_residual", "h_publish_residual",
                          "frontend_other", "core_other"):
                    if row[k] is not None and row[k] < -50_000:  # >50 us negative: overlap
                        problems.append(f"{r['bench_id']} negative {k}={row[k]}")
            row.update({k: r[k] for k in ("id", "lane", "index", "order", "ttft_s", "e2e_s")})
            row["prompt_tokens"] = r["usage"]["prompt_tokens"]
            row["cached_tokens"] = r["usage"]["prompt_tokens_details"]["cached_tokens"]
            rows.append(row)
    return problems, rows


def cmd_runs(args):
    out = Path(args.root) / "analysis" / args.attempt
    report = {}
    for name in args.run:
        run = load_run(args.root, args.attempt, name)
        problems, rows = validate_run(run)
        report[name] = {"version": run["version"], "tree": run["tree"], "part": run["part"],
                        "requests": len(run["client"]), "problems": problems,
                        "events": len(run["events"])}
        with (out / f"joined-{name}.jsonl").open("w", encoding="utf-8") if rows else open("/dev/null", "w") as f:
            for row in rows:
                f.write(json.dumps(row) + "\n")
        if rows and run["version"] == "F":
            later = [r for r in rows if r["index"] >= 1]
            fields = ["T_wall", "T-reuse", "T-history", "H_wall", "H-reuse", "H-history",
                      "request_other_wall", "F_wall", "C_wall", "A_wall", "t_encode_residual",
                      "h_prefix_residual", "h_publish_residual", "t_lcp", "t_boundary", "t_bound",
                      "t_size", "t_copy", "t_stage", "t_finish", "h_lcp", "h_size_ids",
                      "h_size_hashes", "h_copy", "H:commit", "T:reserve", "H:reserve"]
            report[name]["later_median_ms"] = {k: ms(median([r[k] for r in later if r.get(k) is not None]))
                                               for k in fields}
            report[name]["routes"] = {k: sum(1 for r in rows if r["t_route"] == k)
                                      for k in ("miss", "exact", "partial")}
            report[name]["h_reused_requests"] = sum(1 for r in rows if (r["h_reused_blocks"] or 0) > 0)
            report[name]["bytes_used_max"] = {"T": max((r["t_bytes_used"] or 0) for r in rows),
                                              "H": max((r["h_bytes_used"] or 0) for r in rows)}
        elif rows:
            later = [r for r in rows if r["index"] >= 1]
            report[name]["later_median_ms"] = {k: ms(median([r[k] for r in later if r.get(k) is not None]))
                                               for k in ("T_wall", "H_wall", "request_other_wall",
                                                         "F_wall", "C_wall", "A_wall")}
    write_json(out / "runs-validation.json", report)
    print(json.dumps(report, indent=1)[:6000])


def per_run_stats(run, cohort):
    rows = [r for r in run["client"] if cohort(r)]
    t = [r["ttft_s"] * 1e3 for r in rows]
    e = [r["e2e_s"] * 1e3 for r in rows]
    return {"n": len(rows), "ttft_mean": mean(t), "ttft_p50": quantile(t, .5), "ttft_p95": quantile(t, .95),
            "e2e_mean": mean(e), "e2e_p50": quantile(e, .5)}


COHORTS = {"later": lambda r: r["index"] >= 1, "first": lambda r: r["index"] == 0,
           "all": lambda r: True}


def compare_outputs(n, f):
    a = {r["id"]: r for r in n["client"]}
    b = {r["id"]: r for r in f["client"]}
    diffs = []
    for k in a:
        x, y = a[k], b.get(k)
        if y is None:
            diffs.append((k, "missing"))
            continue
        if x["output_sha256"] != y["output_sha256"]:
            diffs.append((k, "output"))
        if x["usage"]["prompt_tokens"] != y["usage"]["prompt_tokens"]:
            diffs.append((k, "prompt_tokens"))
        if x["usage"]["prompt_tokens_details"]["cached_tokens"] != y["usage"]["prompt_tokens_details"]["cached_tokens"]:
            diffs.append((k, "cached_tokens"))
    return diffs


def cmd_pairs(args, kind):
    out = Path(args.root) / "analysis" / args.attempt
    result = {"blocks": []}
    for spec in args.blocks:
        nr, fr = spec.split(":")
        n, f = load_run(args.root, args.attempt, nr), load_run(args.root, args.attempt, fr)
        assert n["version"] == "N" and f["version"] == "F"
        block = {"N": nr, "F": fr, "output_diffs": compare_outputs(n, f)}
        for name, coh in COHORTS.items():
            sn, sf = per_run_stats(n, coh), per_run_stats(f, coh)
            block[name] = {"N": sn, "F": sf,
                           "saved_ms": sn["ttft_mean"] - sf["ttft_mean"],
                           "saved_pct": 100 * (sn["ttft_mean"] - sf["ttft_mean"]) / sn["ttft_mean"],
                           "e2e_saved_ms": sn["e2e_mean"] - sf["e2e_mean"]}
        for side, run in (("N", n), ("F", f)):
            if run["window"]:
                block[side + "_window"] = {"batch_s": run["window"]["batch_s"],
                                           "server_cpu_ms_per_request": 1e3 * run["window"]["server_cpu_s"] / run["window"]["requests"]}
        # Length bins over later turns (matched logical IDs).
        bins = []
        nf = {r["id"]: r for r in f["client"]}
        for lo, hi in BINS:
            ids = [r for r in n["client"] if r["index"] >= 1 and lo <= r["usage"]["prompt_tokens"] < hi]
            if ids:
                dn = [r["ttft_s"] * 1e3 for r in ids]
                df = [nf[r["id"]]["ttft_s"] * 1e3 for r in ids]
                bins.append({"bin": [lo, hi], "n": len(ids), "N": mean(dn), "F": mean(df),
                             "saved_ms": mean(dn) - mean(df)})
        block["later_by_length"] = bins
        result["blocks"].append(block)
    for name in COHORTS:
        saved = [b[name]["saved_ms"] for b in result["blocks"]]
        pct = [b[name]["saved_pct"] for b in result["blocks"]]
        result[name] = {"saved_ms_mean": mean(saved), "saved_ms_range": [min(saved), max(saved)],
                        "saved_pct_mean": mean(pct), "saved_pct_range": [min(pct), max(pct)]}
    write_json(out / f"{kind}-summary.json", result)
    print(json.dumps({k: result[k] for k in COHORTS}, indent=1))
    print("output diffs per block:", [len(b["output_diffs"]) for b in result["blocks"]])


def cmd_perturb(args):
    out = Path(args.root) / "analysis" / args.attempt
    pairs = []
    for spec in args.pairs:
        plain, probe = spec.split(":")
        a, b = load_run(args.root, args.attempt, plain), load_run(args.root, args.attempt, probe)
        assert a["tree"] == "plain" and b["tree"] == "probe" and a["version"] == b["version"]
        ta = median([r["ttft_s"] for r in a["client"]])
        tb = median([r["ttft_s"] for r in b["client"]])
        ea = median([r["e2e_s"] for r in a["client"]])
        eb = median([r["e2e_s"] for r in b["client"]])
        diffs = [r["id"] for r, s in zip(sorted(a["client"], key=lambda r: r["id"]),
                                          sorted(b["client"], key=lambda r: r["id"]))
                 if r["output_sha256"] != s["output_sha256"]
                 or r["usage"]["prompt_tokens"] != s["usage"]["prompt_tokens"]]
        pairs.append({"version": a["version"], "plain": plain, "probe": probe,
                      "ttft_ratio": tb / ta, "e2e_ratio": eb / ea, "result_diffs": diffs})
    summary = {}
    for v in ("N", "F"):
        p = [x for x in pairs if x["version"] == v]
        if p:
            summary[v] = {"ttft_ratio_median": median([x["ttft_ratio"] for x in p]),
                          "e2e_ratio_median": median([x["e2e_ratio"] for x in p]),
                          "pairs": len(p)}
    gate = all(s["ttft_ratio_median"] <= 1.05 and s["e2e_ratio_median"] <= 1.05 for s in summary.values()) \
        and not any(x["result_diffs"] for x in pairs)
    write_json(out / "perturbation.json", {"pairs": pairs, "summary": summary, "threshold": 1.05,
                                           "passed": gate})
    print(json.dumps({"summary": summary, "passed": gate}, indent=1))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("runs")
    r.add_argument("--root", required=True)
    r.add_argument("--attempt", required=True)
    r.add_argument("--run", action="append", required=True)
    for name in ("cost", "perf"):
        p = sub.add_parser(name)
        p.add_argument("--root", required=True)
        p.add_argument("--attempt", required=True)
        p.add_argument("--blocks", nargs="+", required=True)
    q = sub.add_parser("perturb")
    q.add_argument("--root", required=True)
    q.add_argument("--attempt", required=True)
    q.add_argument("--pairs", nargs="+", required=True)
    a = ap.parse_args()
    if a.cmd == "runs":
        Path(a.root, "analysis", a.attempt).mkdir(parents=True, exist_ok=True)
        cmd_runs(a)
    elif a.cmd == "perturb":
        cmd_perturb(a)
    else:
        cmd_pairs(a, a.cmd)
    write_json(Path(a.root) / "analysis" / "metric-map.json", METRIC_MAP)


if __name__ == "__main__":
    main()
