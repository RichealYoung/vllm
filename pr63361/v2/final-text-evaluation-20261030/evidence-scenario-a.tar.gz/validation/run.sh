#!/bin/bash
# Final T+H candidate correctness: CPU (helper audit, hooks, suite), then GPU serving.
set -uo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030/validation
source "$project/activate.sh"
source "$project/vendor/source-env.sh"
job() {  # phase resource seconds script
  "$project/.venv/bin/python" /root/autodl-tmp/shared/tools/run_job.py \
    --project codex-pr63361 --id "claude-final-cand-$1-20261030-001" --resource "$2" \
    --actor Claude --role support --workspace "$root" --cwd "$root" \
    --purpose "Final T+H candidate 797e19367 correctness ($1), no performance" \
    --expected-seconds "$3" --wait-seconds 3600 -- "$project/.venv/bin/python" "$root/inputs/$4" \
    > "$root/launcher-$1.log" 2>&1 < /dev/null
}
job cpu functional 2400 cpu_final.py; echo cpu-exit=$?
[ -f "$root/CPU_COMPLETE.json" ] || exit 1
job gpu functional 2400 gpu_final.py; echo gpu-exit=$?
[ -f "$root/GPU_COMPLETE.json" ] && echo ALLDONE
