"""CPU acceptance of the final T+H candidate (797e19367), reusing Codex's pipeline.

The source is Codex's accepted hash-stage tree (same main, natives, token_lcp
helper and installation) with every file changed by 85e199e60..797e19367
replaced from the committed tree. Then: helper import audit, applicable hooks,
and the hash-stage CPU suite.
"""
import os
import shutil
import subprocess
import sys
import tarfile

from common import INPUTS, PROJECT, ROOT, environment, junit, progress, read, run, sha, verify, write

CODEX = PROJECT / "experiments/pr63361-followups-current-text-validation-20261026-001"
STAGE = "final"


def main():
    identities = read(INPUTS / "final-identities.json")
    target = ROOT / "sources" / STAGE
    progress("assembling")
    shutil.copytree(CODEX / "sources/hash", target, symlinks=True)
    archive = INPUTS / "final-feature.tar.gz"
    assert sha(archive) == identities["feature_archive_sha256"]
    with tarfile.open(archive) as tar:
        tar.extractall(target, filter="data")
    manifest = read(CODEX / "inputs/hash-manifest.json")
    changed = []
    for name, digest in identities["files"].items():
        if manifest.get(name) != digest:
            changed.append(name)
        manifest[name] = digest
    write(INPUTS / "final-manifest.json", manifest)
    write(ROOT / "final-changed-vs-codex-hash.json", sorted(changed))
    verify(STAGE)
    # csrc unchanged: the Codex helper build is reused.
    helper = read(CODEX / "helper-identity.json")
    assert sha(target / "csrc/session_prefix.cpp") == helper["source_sha256"]
    assert sha(target / "vllm/_session_prefix.abi3.so") == helper["sha256"]
    audit = "from vllm import _session_prefix as h; assert {n for n in dir(h) if not n.startswith('_')} == {'token_lcp'}"
    run("final-helper-import", [sys.executable, "-c", audit], cwd=target, env=environment(STAGE)).check_returncode()
    progress("hooks")
    scratch = ROOT / "final-hook-scratch"
    shutil.copytree(target, scratch, symlinks=True)
    subprocess.run(["git", "init", "-q"], cwd=scratch, check=True)
    subprocess.run(["git", "add", "-A"], cwd=scratch, check=True)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="", PRE_COMMIT_HOME=str(PROJECT / "bench-lab/.cache/pre-commit"))
    env.pop("PYTHONPATH", None)
    runner = PROJECT / "experiments/session-prefix-admission-integration-20261025-002/inputs/run_applicable_hooks.py"
    hooks = run("final-hooks", [PROJECT / "bench-lab/.venv-lint/bin/python", runner, ROOT / "final-hook-selection",
                                *read(INPUTS / "final-files.json")], cwd=scratch, env=env)
    changes = [n for n, d in manifest.items() if sha(scratch / n) != d]
    write(ROOT / "final-hooks-result.json", {"exit_code": hooks.returncode, "scratch_changes": changes})
    run("final-hook-diff", ["git", "diff", "--binary"], cwd=scratch)
    hooks.check_returncode()
    assert not changes, changes
    progress("cpu_tests")
    files = ["tests/utils_/test_session_prefix.py", "tests/renderers/test_session_prefix.py", "tests/v1/test_request.py",
             "tests/config/test_config_utils.py", "tests/v1/core/test_kv_cache_utils.py",
             "tests/v1/core/test_prefix_caching.py", "tests/multimodal/test_hasher.py",
             "tests/renderers/test_session_prefix_media_fallback.py"]
    label = "final-cpu"
    argv = [sys.executable, INPUTS / "cpu_pytest.py", ROOT, label, "-v", "-p", "no:cacheprovider", *files,
            "--basetemp=" + str(ROOT / (label + "-tmp")), "--junitxml=" + str(ROOT / (label + ".xml"))]
    result = run(label, argv, cwd=target, env=environment(STAGE))
    report = junit(ROOT / (label + ".xml")) if (ROOT / (label + ".xml")).exists() else {}
    report["exit_code"] = result.returncode
    write(ROOT / (label + "-result.json"), report)
    result.check_returncode()
    assert report["tests"] > 0 and report["failures"] == report["errors"] == report["skipped"] == 0, report
    assert not read(ROOT / (label + "-environment.json"))["cuda_initialized"]
    verify(STAGE)
    write(ROOT / "CPU_COMPLETE.json", {"status": "passed", "report": report, "identities": identities,
                                       "helper": helper, "performance": False})
    progress("cpu_complete", report=report)


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        write(ROOT / "CPU_FAILURE.json", {"error": f"{type(exc).__name__}: {exc}"})
        progress("failed", failed_step="cpu", error=f"{type(exc).__name__}: {exc}")
        raise
