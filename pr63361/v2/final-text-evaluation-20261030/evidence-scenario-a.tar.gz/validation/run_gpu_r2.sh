#!/bin/bash
set -uo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root=/root/autodl-tmp/claude-projects/reviews/pr63361/final-text-a-20261030/validation
source "$project/activate.sh"
source "$project/vendor/source-env.sh"
"$project/.venv/bin/python" /root/autodl-tmp/shared/tools/run_job.py \
  --project codex-pr63361 --id "claude-final-cand-gpu-20261030-002" --resource functional \
  --actor Claude --role support --workspace "$root" --cwd "$root" \
  --purpose "Final T+H candidate 797e19367 GPU correctness r2 (warm compile cache), no performance" \
  --expected-seconds 2400 --wait-seconds 3600 -- "$project/.venv/bin/python" "$root/inputs/gpu_final_r2.py" \
  > "$root/launcher-gpu-r2.log" 2>&1 < /dev/null
echo gpu-r2-exit=$?
[ -f "$root/GPU_COMPLETE-r2.json" ] && echo ALLDONE
