"""Create an instrumented N or F tree for the final T+H text experiment.

Usage: python apply_probe.py {N,F} <frozen_src_dir> <dest_dir> <probe_src_dir>

Copies the source (dest must not exist), adds the probe modules and applies
anchored text edits. Every anchor must match exactly once; F-only edits are
instrumented copies of the exact committed function bodies (same statements,
only timing added; one size sum is split into named terms with equal value).
Writes dest/../probe-edits-<version>.json with original/instrumented SHA256.
The baseline cost profile edits (R,P,M,T,F,I,E,A,D,H,C) are reused unchanged
except that C now also binds the EngineCore request ID for fine sections and
the initial Request construction is timed as h_request on both versions.
"""

import hashlib
import json
import shutil
import sys
from pathlib import Path

COMMON = [
    ("vllm/utils/async_utils.py",
     "        p_func = partial(func, *args, **kwargs)\n"
     "        return loop.run_in_executor(executor=executor, func=p_func)\n",
     "        p_func = partial(func, *args, **kwargs)\n"
     "        from vllm import _cost_probe\n"
     "        if _cost_probe.ENABLED:\n"
     "            import contextvars\n"
     "            p_func = partial(contextvars.copy_context().run, p_func)\n"
     "        return loop.run_in_executor(executor=executor, func=p_func)\n"),
    ("vllm/entrypoints/openai/chat_completion/api_router.py",
     "async def create_chat_completion(request: ChatCompletionRequest, raw_request: Request):\n",
     "async def create_chat_completion(request: ChatCompletionRequest, raw_request: Request):\n"
     "    from vllm._cost_probe_middleware import mark_endpoint\n"
     "    mark_endpoint(request.request_id)\n"),
    ("vllm/renderers/online_renderer.py",
     "    async def preprocess_chat(\n        self,\n",
     "    async def preprocess_chat(self, *args, **kwargs):\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"F\", cpu=False):\n"
     "            return await self._preprocess_chat_unprobed(*args, **kwargs)\n"
     "\n"
     "    async def _preprocess_chat_unprobed(\n        self,\n"),
    ("vllm/renderers/hf.py",
     "        conversation, mm_data, mm_uuids = await parse_chat_messages_async(\n"
     "            messages,\n"
     "            model_config,\n",
     "        from vllm import _cost_probe\n"
     "        _p_ctx = _cost_probe.span(\"P\")\n"
     "        _p_ctx.__enter__()\n"
     "        try:\n"
     "            _p_result = await parse_chat_messages_async(\n"
     "            messages,\n"
     "            model_config,\n"),
    ("vllm/renderers/hf.py",
     "        self._apply_chat_template_async = make_async(\n"
     "            safe_apply_chat_template, executor=self._executor\n"
     "        )\n",
     "        from vllm import _cost_probe\n"
     "        self._apply_chat_template_async = make_async(\n"
     "            _cost_probe.wrap_sync(safe_apply_chat_template, \"M\"),\n"
     "            executor=self._executor,\n"
     "        )\n"),
    # T on the normal path (N always; F for requests without a session hint).
    ("vllm/renderers/base.py",
     "        encoding = tokenizer(prompt[\"prompt\"], **kwargs)\n"
     "        return self._build_tokens_prompt(\n",
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"T\", kind=\"native\"):\n"
     "            encoding = tokenizer(prompt[\"prompt\"], **kwargs)\n"
     "        if _cost_probe.DUMP_PAYLOADS:\n"
     "            _cost_probe.add_payload(\"rendered_prompt\", _cost_probe.CURRENT_RID.get(), prompt[\"prompt\"])\n"
     "            _cost_probe.add_payload(\"token_ids\", _cost_probe.CURRENT_RID.get(), list(encoding[\"input_ids\"]))\n"
     "        return self._build_tokens_prompt(\n"),
    ("vllm/v1/engine/async_llm.py",
     "                # Rendered EngineInput; no blocking preprocessing needed.\n"
     "                request = self.input_processor.process_inputs(\n",
     "                # Rendered EngineInput; no blocking preprocessing needed.\n"
     "                from vllm import _cost_probe\n"
     "                _i_ctx = _cost_probe.span(\"I\", rid=request_id)\n"
     "                _i_ctx.__enter__()\n"
     "                request = self.input_processor.process_inputs(\n"),
    ("vllm/v1/engine/core_client.py",
     "        message = (request_type.value, *self.encoder.encode(request))\n"
     "        return self._send_input_message(message, engine)\n",
     "        if request_type == EngineCoreRequestType.ADD:\n"
     "            from vllm import _cost_probe\n"
     "            from vllm._cost_probe_middleware import finish_api_total\n"
     "            _rid = getattr(request, \"external_req_id\", None)\n"
     "            with _cost_probe.span(\"E\", rid=_rid):\n"
     "                message = (request_type.value, *self.encoder.encode(request))\n"
     "            finish_api_total(_rid)\n"
     "        else:\n"
     "            message = (request_type.value, *self.encoder.encode(request))\n"
     "        return self._send_input_message(message, engine)\n"),
    ("vllm/v1/engine/core.py",
     "                        req: EngineCoreRequest = add_request_decoder.decode(data_frames)\n",
     "                        from vllm import _cost_probe\n"
     "                        _d_w0 = _cost_probe.time.perf_counter_ns()\n"
     "                        _d_c0 = _cost_probe.time.thread_time_ns()\n"
     "                        req: EngineCoreRequest = add_request_decoder.decode(data_frames)\n"
     "                        _d_c1 = _cost_probe.time.thread_time_ns()\n"
     "                        _d_w1 = _cost_probe.time.perf_counter_ns()\n"
     "                        _cost_probe.record(\"D\", getattr(req, \"external_req_id\", None), _d_w1 - _d_w0, _d_c1 - _d_c0, _d_w0, _d_w1)\n"),
    ("vllm/v1/engine/core.py",
     "            self.request_block_hasher = get_request_block_hasher(\n"
     "                hash_block_size, caching_hash_fn\n"
     "            )\n",
     "            self.request_block_hasher = get_request_block_hasher(\n"
     "                hash_block_size, caching_hash_fn\n"
     "            )\n"
     "            from vllm import _cost_probe\n"
     "            self.request_block_hasher = _cost_probe.wrap_block_hasher(\n"
     "                self.request_block_hasher\n"
     "            )\n"
     "            _cost_probe.record(\"hash_config\", None, None, None, None, None,\n"
     "                               hash_block_size=hash_block_size,\n"
     "                               hash_algo=str(vllm_config.cache_config.prefix_caching_hash_algo))\n"),
    ("vllm/v1/engine/core.py",
     "    def preprocess_add_request(self, request: EngineCoreRequest) -> tuple[Request, int]:\n",
     "    def preprocess_add_request(self, request: EngineCoreRequest) -> tuple[Request, int]:\n"
     "        from vllm import _cost_probe\n"
     "        _rid = getattr(request, \"external_req_id\", None)\n"
     "        with _cost_probe.span(\"C\", rid=_rid):\n"
     "            _cost_probe.set_initial_hash_rid(_rid)\n"
     "            _cost_probe.set_core_rid(_rid)\n"
     "            try:\n"
     "                return self._preprocess_add_request_unprobed(request)\n"
     "            finally:\n"
     "                _cost_probe.clear_initial_hash_rid()\n"
     "                _cost_probe.clear_core_rid()\n"
     "\n"
     "    def _preprocess_add_request_unprobed(self, request: EngineCoreRequest) -> tuple[Request, int]:\n"
     "        from vllm import _cost_probe\n"),
    ("vllm/v1/engine/core.py",
     "        finally:\n"
     "            signal.signal(signal.SIGTERM, signal.SIG_DFL)\n"
     "            signal.signal(signal.SIGINT, signal.SIG_DFL)\n",
     "        finally:\n"
     "            from vllm import _cost_probe\n"
     "            _cost_probe.flush(\"engine_core_exit\")\n"
     "            signal.signal(signal.SIGTERM, signal.SIG_DFL)\n"
     "            signal.signal(signal.SIGINT, signal.SIG_DFL)\n"),
    # Closers of split statements (P, I).
    ("vllm/renderers/hf.py",
     "            media_io_kwargs=params.media_io_kwargs,\n"
     "            mm_processor_kwargs=params.mm_processor_kwargs,\n"
     "        )\n"
     "\n"
     "        prompt_embeds_tensors: list[torch.Tensor] | None = None\n",
     "            media_io_kwargs=params.media_io_kwargs,\n"
     "            mm_processor_kwargs=params.mm_processor_kwargs,\n"
     "            )\n"
     "        except BaseException:\n"
     "            _p_ctx.__exit__(*__import__(\"sys\").exc_info())\n"
     "            raise\n"
     "        _p_ctx.__exit__(None, None, None)\n"
     "        conversation, mm_data, mm_uuids = _p_result\n"
     "\n"
     "        prompt_embeds_tensors: list[torch.Tensor] | None = None\n"),
    ("vllm/v1/engine/async_llm.py",
     "                    session_id=session_id,\n"
     "                    kv_hints=kv_hints,\n"
     "                )\n"
     "            else:\n"
     "                # Raw prompts require tokenization",
     "                    session_id=session_id,\n"
     "                    kv_hints=kv_hints,\n"
     "                )\n"
     "                _i_ctx.__exit__(None, None, None)\n"
     "            else:\n"
     "                # Raw prompts require tokenization"),
]

N_ONLY = [
    ("vllm/v1/engine/core.py",
     "        req = Request.from_engine_core_request(request, self.request_block_hasher)\n"
     "        if req.use_structured_output:\n",
     "        with _cost_probe.span(\"h_request\", cpu=False):\n"
     "            req = Request.from_engine_core_request(request, self.request_block_hasher)\n"
     "        _cost_probe.clear_initial_hash_rid()\n"
     "        if req.use_structured_output:\n"),
]

F_ONLY = [
    # ---- EngineCore: H entry points.
    ("vllm/v1/engine/core.py",
     "        prefix = cache.prefix(request) if cache is not None else None\n"
     "        req = Request.from_engine_core_request(\n"
     "            request,\n"
     "            self.request_block_hasher,\n"
     "            initial_block_hashes=prefix.initial_block_hashes if prefix else None,\n"
     "        )\n",
     "        with _cost_probe.span(\"h_prefix\", cpu=False):\n"
     "            prefix = cache.prefix(request) if cache is not None else None\n"
     "        with _cost_probe.span(\"h_request\", cpu=False):\n"
     "            req = Request.from_engine_core_request(\n"
     "                request,\n"
     "                self.request_block_hasher,\n"
     "                initial_block_hashes=prefix.initial_block_hashes if prefix else None,\n"
     "            )\n"
     "        _cost_probe.clear_initial_hash_rid()\n"),
    ("vllm/v1/engine/core.py",
     "        if cache is not None:\n"
     "            cache.publish(request, req, epoch, prefix)\n",
     "        if cache is not None:\n"
     "            with _cost_probe.span(\"h_publish\", cpu=False):\n"
     "                cache.publish(request, req, epoch, prefix)\n"),
    # ---- H module: prefix() and publish().
    ("vllm/v1/core/session_prefix.py",
     "    def prefix(self, request: EngineCoreRequest) -> HashPrefix | None:\n"
     "        if not self.eligible(request) or self.none_hash != kv_cache_utils.NONE_HASH:\n"
     "            return None\n"
     "        key = (request.cache_salt, request.session_id)\n"
     "        with self.store.borrow(key) as old:\n"
     "            if old is None:\n"
     "                return None\n"
     "            ids = request.prompt_token_ids\n"
     "            assert ids is not None\n"
     "            limit = min(len(old.hashes), len(ids) // self.block_size) * self.block_size\n"
     "            try:\n"
     "                tokens = self.helper.token_lcp(ids, old.ids, limit)\n"
     "            except (OverflowError, ValueError):\n"
     "                return None\n"
     "            count = tokens // self.block_size\n"
     "            with self._stats_lock:\n"
     "                self.stats[\"reused_blocks\"] += count\n"
     "            logger.debug(\"Session hash reuse: reused_blocks=%d\", count)\n"
     "            if not count:\n"
     "                return None\n"
     "            return HashPrefix(\n"
     "                self.block_size, old.hashes[:count], ids, tokens, old.bound\n"
     "            )\n",
     "    def prefix(self, request: EngineCoreRequest) -> HashPrefix | None:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"h_eligible\", cpu=False):\n"
     "            _eligible = not (not self.eligible(request) or self.none_hash != kv_cache_utils.NONE_HASH)\n"
     "        if not _eligible:\n"
     "            return None\n"
     "        key = (request.cache_salt, request.session_id)\n"
     "        with self.store.borrow(key) as old:\n"
     "            if old is None:\n"
     "                _cost_probe.note(\"h_prefix_info\", found=False)\n"
     "                return None\n"
     "            ids = request.prompt_token_ids\n"
     "            assert ids is not None\n"
     "            try:\n"
     "                with _cost_probe.span(\"h_lcp\", cpu=False):\n"
     "                    limit = min(len(old.hashes), len(ids) // self.block_size) * self.block_size\n"
     "                    tokens = self.helper.token_lcp(ids, old.ids, limit)\n"
     "            except (OverflowError, ValueError):\n"
     "                _cost_probe.note(\"h_prefix_info\", found=True, lcp_error=True)\n"
     "                return None\n"
     "            with _cost_probe.span(\"h_slice\", cpu=False):\n"
     "                count = tokens // self.block_size\n"
     "                with self._stats_lock:\n"
     "                    self.stats[\"reused_blocks\"] += count\n"
     "                logger.debug(\"Session hash reuse: reused_blocks=%d\", count)\n"
     "                _result = None\n"
     "                if count:\n"
     "                    _result = HashPrefix(\n"
     "                        self.block_size, old.hashes[:count], ids, tokens, old.bound\n"
     "                    )\n"
     "            _cost_probe.note(\"h_prefix_info\", found=True, limit=limit, lcp_tokens=tokens,\n"
     "                             reused_blocks=count, block_size=self.block_size, prompt_tokens=len(ids))\n"
     "            return _result\n"),
    ("vllm/v1/core/session_prefix.py",
     "        ):\n"
     "            return\n"
     "        ids = request.prompt_token_ids\n"
     "        assert ids is not None\n"
     "        if prefix is not None and prefix.ids is ids and prefix.bound is not None:\n"
     "            # token_lcp matched the leading IDs against a snapshot validated when\n"
     "            # it was stored, so only the remaining IDs need scanning.\n"
     "            suffix = token_bound(ids[prefix.tokens :])\n"
     "            bound = None if suffix is None else max(prefix.bound, suffix)\n"
     "        else:\n"
     "            bound = token_bound(ids)\n"
     "        hashes = result.block_hashes\n"
     "        key = (request.cache_salt, request.session_id)\n"
     "        size = (\n"
     "            1024\n"
     "            + sum(map(sys.getsizeof, key))\n"
     "            + token_bytes(ids, bound)\n"
     "            + sys.getsizeof([])\n"
     "            + len(hashes) * struct.calcsize(\"P\")\n"
     "            + sum(map(sys.getsizeof, hashes))\n"
     "        )\n"
     "        reservation = self.store.reserve(key, size)\n"
     "        if reservation is not None:\n"
     "            try:\n"
     "                snapshot = HashSnapshot(ids.copy(), hashes.copy(), bound)\n"
     "                if reservation.epoch == epoch:\n"
     "                    reservation.commit(snapshot, size)\n"
     "            finally:\n"
     "                reservation.cancel()\n",
     "        ):\n"
     "            return\n"
     "        from vllm import _cost_probe\n"
     "        ids = request.prompt_token_ids\n"
     "        assert ids is not None\n"
     "        _fast = prefix is not None and prefix.ids is ids and prefix.bound is not None\n"
     "        with _cost_probe.span(\"h_bound\", cpu=False):\n"
     "            if prefix is not None and prefix.ids is ids and prefix.bound is not None:\n"
     "                # token_lcp matched the leading IDs against a snapshot validated when\n"
     "                # it was stored, so only the remaining IDs need scanning.\n"
     "                suffix = token_bound(ids[prefix.tokens :])\n"
     "                bound = None if suffix is None else max(prefix.bound, suffix)\n"
     "            else:\n"
     "                bound = token_bound(ids)\n"
     "        hashes = result.block_hashes\n"
     "        key = (request.cache_salt, request.session_id)\n"
     "        with _cost_probe.span(\"h_size_ids\", cpu=False):\n"
     "            _ids_bytes = token_bytes(ids, bound)\n"
     "        with _cost_probe.span(\"h_size_hashes\", cpu=False):\n"
     "            _hash_bytes = sum(map(sys.getsizeof, hashes))\n"
     "        size = (\n"
     "            1024\n"
     "            + sum(map(sys.getsizeof, key))\n"
     "            + _ids_bytes\n"
     "            + sys.getsizeof([])\n"
     "            + len(hashes) * struct.calcsize(\"P\")\n"
     "            + _hash_bytes\n"
     "        )\n"
     "        _cost_probe.note(\"h_publish_info\", bound_fast=_fast,\n"
     "                         scanned_ids=(len(ids) - prefix.tokens) if _fast else len(ids),\n"
     "                         prompt_tokens=len(ids), hashes=len(hashes), size=size,\n"
     "                         bound_known=bound is not None)\n"
     "        reservation = self.store.reserve(key, size)\n"
     "        if reservation is not None:\n"
     "            try:\n"
     "                with _cost_probe.span(\"h_copy\", cpu=False):\n"
     "                    snapshot = HashSnapshot(ids.copy(), hashes.copy(), bound)\n"
     "                if reservation.epoch == epoch:\n"
     "                    reservation.commit(snapshot, size)\n"
     "            finally:\n"
     "                reservation.cancel()\n"),
    ("vllm/v1/core/session_prefix.py",
     "        if (\n"
     "            not self.eligible(request)\n"
     "            or epoch != self.store.epoch\n"
     "            or self.none_hash != kv_cache_utils.NONE_HASH\n"
     "        ):\n"
     "            return\n"
     "        from vllm import _cost_probe\n",
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"h_pub_check\", cpu=False):\n"
     "            _skip = (\n"
     "                not self.eligible(request)\n"
     "                or epoch != self.store.epoch\n"
     "                or self.none_hash != kv_cache_utils.NONE_HASH\n"
     "            )\n"
     "        if _skip:\n"
     "            return\n"),
    # ---- Shared store (T in the API process, H in EngineCore; pid tells them apart).
    ("vllm/utils/session_prefix.py",
     "    def commit(self, value: _T, size: int) -> bool:\n"
     "        if not 0 <= size <= self.size:\n"
     "            raise ValueError(\"snapshot exceeds its reservation\")\n",
     "    def commit(self, value: _T, size: int) -> bool:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"commit\", cpu=False):\n"
     "            _ok = self._commit_unprobed(value, size)\n"
     "        _cost_probe.note(\"store_state\", after=\"commit\", ok=_ok,\n"
     "                         bytes_used=self.store.bytes_used, entries=len(self.store._entries))\n"
     "        return _ok\n"
     "\n"
     "    def _commit_unprobed(self, value: _T, size: int) -> bool:\n"
     "        if not 0 <= size <= self.size:\n"
     "            raise ValueError(\"snapshot exceeds its reservation\")\n"),
    ("vllm/utils/session_prefix.py",
     "    def cancel(self) -> None:\n"
     "        with self.store._lock:\n"
     "            if self.active:\n"
     "                self.active = False\n"
     "                self.store.bytes_used -= self.size\n",
     "    def cancel(self) -> None:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"cancel\", cpu=False, was_active=self.active):\n"
     "            with self.store._lock:\n"
     "                if self.active:\n"
     "                    self.active = False\n"
     "                    self.store.bytes_used -= self.size\n"),
    ("vllm/utils/session_prefix.py",
     "    @contextmanager\n"
     "    def borrow(self, key: Hashable) -> Iterator[_T | None]:\n"
     "        with self._lock:\n"
     "            entry = self._entries.get(key)\n"
     "            if entry is not None:\n"
     "                entry.readers += 1\n"
     "                self._entries.move_to_end(key)\n"
     "        try:\n"
     "            yield entry.value if entry is not None else None\n"
     "        finally:\n"
     "            if entry is not None:\n"
     "                with self._lock:\n"
     "                    entry.readers -= 1\n"
     "                    if not entry.resident and not entry.readers:\n"
     "                        self.bytes_used -= entry.size\n",
     "    @contextmanager\n"
     "    def borrow(self, key: Hashable) -> Iterator[_T | None]:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"borrow_enter\", cpu=False):\n"
     "            with self._lock:\n"
     "                entry = self._entries.get(key)\n"
     "                if entry is not None:\n"
     "                    entry.readers += 1\n"
     "                    self._entries.move_to_end(key)\n"
     "        try:\n"
     "            yield entry.value if entry is not None else None\n"
     "        finally:\n"
     "            with _cost_probe.span(\"borrow_exit\", cpu=False, found=entry is not None):\n"
     "                if entry is not None:\n"
     "                    with self._lock:\n"
     "                        entry.readers -= 1\n"
     "                        if not entry.resident and not entry.readers:\n"
     "                            self.bytes_used -= entry.size\n"),
    ("vllm/utils/session_prefix.py",
     "    def reserve(self, key: Hashable, size: int) -> Reservation[_T] | None:\n"
     "        retired = []\n",
     "    def reserve(self, key: Hashable, size: int) -> Reservation[_T] | None:\n"
     "        from vllm import _cost_probe\n"
     "        _before = len(self._entries)\n"
     "        with _cost_probe.span(\"reserve\", cpu=False):\n"
     "            _result = self._reserve_unprobed(key, size)\n"
     "        _cost_probe.note(\"store_state\", after=\"reserve\", ok=_result is not None, size=size,\n"
     "                         evicted=max(0, _before - len(self._entries)),\n"
     "                         bytes_used=self.bytes_used, entries=len(self._entries),\n"
     "                         capacity=self.capacity)\n"
     "        return _result\n"
     "\n"
     "    def _reserve_unprobed(self, key: Hashable, size: int) -> Reservation[_T] | None:\n"
     "        retired = []\n"),
    ("vllm/utils/session_prefix.py",
     "    def stage(self, reservation: Reservation, value: object, size: int) -> None:\n"
     "        with self._lock:\n",
     "    def stage(self, reservation: Reservation, value: object, size: int) -> None:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"t_stage\", cpu=False):\n"
     "            self._stage_unprobed(reservation, value, size)\n"
     "\n"
     "    def _stage_unprobed(self, reservation: Reservation, value: object, size: int) -> None:\n"
     "        with self._lock:\n"),
    ("vllm/utils/session_prefix.py",
     "    def finish(self, *, publish: bool) -> None:\n"
     "        with self._lock:\n",
     "    def finish(self, *, publish: bool) -> None:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"t_finish\", cpu=False, publish=publish, pending=self.pending is not None):\n"
     "            self._finish_unprobed(publish=publish)\n"
     "\n"
     "    def _finish_unprobed(self, *, publish: bool) -> None:\n"
     "        with self._lock:\n"),
    # ---- API side: context creation.
    ("vllm/renderers/online_renderer.py",
     "        context = renderer.session_prefix_context(\n"
     "            session_id, getattr(request, \"cache_salt\", None)\n"
     "        )\n"
     "        if context is not None:\n"
     "            tok_params = replace(tok_params, session_prefix_context=context)\n",
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"t_context\", cpu=False):\n"
     "            context = renderer.session_prefix_context(\n"
     "                session_id, getattr(request, \"cache_salt\", None)\n"
     "            )\n"
     "            if context is not None:\n"
     "                tok_params = replace(tok_params, session_prefix_context=context)\n"),
    # ---- T: SessionTokenCache.encode (instrumented copy).
    ("vllm/renderers/session_prefix.py",
     "    def encode(\n"
     "        self, tokenizer: \"TokenizerLike\", text: str, params: \"TokenizeParams\"\n"
     "    ) -> list[int] | None:\n"
     "        context = params.session_prefix_context\n",
     "    def encode(\n"
     "        self, tokenizer: \"TokenizerLike\", text: str, params: \"TokenizeParams\"\n"
     "    ) -> list[int] | None:\n"
     "        from vllm import _cost_probe\n"
     "        with _cost_probe.span(\"t_encode\", cpu=False):\n"
     "            return self._encode_unprobed(tokenizer, text, params)\n"
     "\n"
     "    def _encode_unprobed(\n"
     "        self, tokenizer: \"TokenizerLike\", text: str, params: \"TokenizeParams\"\n"
     "    ) -> list[int] | None:\n"
     "        from vllm import _cost_probe\n"
     "        _elig = _cost_probe.span(\"t_eligible\", cpu=False)\n"
     "        _elig.__enter__()\n"
     "        context = params.session_prefix_context\n"),
    ("vllm/renderers/session_prefix.py",
     "            or params.return_token_offsets\n"
     "        ):\n"
     "            return None\n"
     "        with self.store.borrow(context.key) as old:\n"
     "            route = \"miss\"\n"
     "            boundary = tokens = 0\n"
     "            if old is not None:\n"
     "                if text == old.text:\n"
     "                    route = \"exact\"\n"
     "                else:\n"
     "                    try:\n"
     "                        found = self._boundary(old, text, lcp(text, old.text))\n"
     "                    except ValueError:\n"
     "                        found = None\n"
     "                        self._count(\"index_declined\")\n"
     "                    if found is not None:\n"
     "                        boundary, tokens = found\n"
     "                        route = \"partial\"\n"
     "            if route == \"exact\":\n"
     "                assert old is not None\n"
     "                ids = old.ids.copy()\n"
     "                bound = old.bound\n"
     "            elif route == \"partial\":\n"
     "                assert old is not None\n"
     "                suffix = tokenizer(text[boundary:], **params.get_encode_kwargs())[\n"
     "                    \"input_ids\"\n"
     "                ]\n"
     "                ids = old.ids[:tokens] + suffix\n"
     "                # The reused prefix was validated when its snapshot was stored,\n"
     "                # so only the new suffix needs scanning for accounting.\n"
     "                bound = None\n"
     "                if old.bound is not None:\n"
     "                    suffix_bound = token_bound(suffix)\n"
     "                    if suffix_bound is not None:\n"
     "                        bound = max(old.bound, suffix_bound)\n"
     "            else:\n"
     "                ids = tokenizer(text, **params.get_encode_kwargs())[\"input_ids\"]\n"
     "                bound = token_bound(ids)\n"
     "            maximum = params.max_input_tokens\n"
     "            if maximum is not None and len(ids) > maximum:\n"
     "                # Native encoding caps the reported length at maximum + 1.\n"
     "                # Reuse its validation error without re-encoding or publishing.\n"
     "                return params._token_len_check(tokenizer, ids[: maximum + 1])\n"
     "            self._count(route, len(ids) if route == \"exact\" else tokens)\n"
     "            # Reserve the snapshot size before the cache-only ID copy.\n"
     "            size = (\n"
     "                1024\n"
     "                + sum(sys.getsizeof(part) for part in context.key)\n"
     "                + sys.getsizeof(text)\n"
     "                + token_bytes(ids, bound)\n"
     "            )\n"
     "            reservation = self.store.reserve(context.key, size)\n"
     "            if reservation is None:\n"
     "                self._count(\"capacity_declined\")\n"
     "                return ids\n"
     "            try:\n"
     "                context.stage(reservation, TokenSnapshot(text, ids.copy(), bound), size)\n"
     "            except BaseException:\n"
     "                reservation.cancel()\n"
     "                raise\n"
     "            return ids\n",
     "            or params.return_token_offsets\n"
     "        ):\n"
     "            _elig.__exit__(None, None, None)\n"
     "            return None\n"
     "        _elig.__exit__(None, None, None)\n"
     "        with self.store.borrow(context.key) as old:\n"
     "            route = \"miss\"\n"
     "            boundary = tokens = 0\n"
     "            _common = None\n"
     "            if old is not None:\n"
     "                with _cost_probe.span(\"t_compare\", cpu=False):\n"
     "                    _same = text == old.text\n"
     "                if _same:\n"
     "                    route = \"exact\"\n"
     "                else:\n"
     "                    try:\n"
     "                        with _cost_probe.span(\"t_lcp\", cpu=False):\n"
     "                            _common = lcp(text, old.text)\n"
     "                        with _cost_probe.span(\"t_boundary\", cpu=False):\n"
     "                            found = self._boundary(old, text, _common)\n"
     "                    except ValueError:\n"
     "                        found = None\n"
     "                        self._count(\"index_declined\")\n"
     "                    if found is not None:\n"
     "                        boundary, tokens = found\n"
     "                        route = \"partial\"\n"
     "            if route == \"exact\":\n"
     "                assert old is not None\n"
     "                with _cost_probe.span(\"t_ids\", cpu=False):\n"
     "                    ids = old.ids.copy()\n"
     "                bound = old.bound\n"
     "                _scanned = 0\n"
     "            elif route == \"partial\":\n"
     "                assert old is not None\n"
     "                with _cost_probe.span(\"T\", kind=\"suffix\", chars=len(text) - boundary):\n"
     "                    suffix = tokenizer(text[boundary:], **params.get_encode_kwargs())[\n"
     "                        \"input_ids\"\n"
     "                    ]\n"
     "                with _cost_probe.span(\"t_ids\", cpu=False):\n"
     "                    ids = old.ids[:tokens] + suffix\n"
     "                # The reused prefix was validated when its snapshot was stored,\n"
     "                # so only the new suffix needs scanning for accounting.\n"
     "                with _cost_probe.span(\"t_bound\", cpu=False):\n"
     "                    bound = None\n"
     "                    if old.bound is not None:\n"
     "                        suffix_bound = token_bound(suffix)\n"
     "                        if suffix_bound is not None:\n"
     "                            bound = max(old.bound, suffix_bound)\n"
     "                _scanned = len(suffix) if old.bound is not None else 0\n"
     "            else:\n"
     "                with _cost_probe.span(\"T\", kind=\"full\", chars=len(text)):\n"
     "                    ids = tokenizer(text, **params.get_encode_kwargs())[\"input_ids\"]\n"
     "                with _cost_probe.span(\"t_bound\", cpu=False):\n"
     "                    bound = token_bound(ids)\n"
     "                _scanned = len(ids)\n"
     "            _cost_probe.note(\"t_route\", route=route, prompt_tokens=len(ids), reused_tokens=tokens,\n"
     "                             boundary_chars=boundary, common_chars=_common, text_chars=len(text),\n"
     "                             bound_known=bound is not None, bound_scanned_ids=_scanned)\n"
     "            maximum = params.max_input_tokens\n"
     "            if maximum is not None and len(ids) > maximum:\n"
     "                # Native encoding caps the reported length at maximum + 1.\n"
     "                # Reuse its validation error without re-encoding or publishing.\n"
     "                return params._token_len_check(tokenizer, ids[: maximum + 1])\n"
     "            self._count(route, len(ids) if route == \"exact\" else tokens)\n"
     "            # Reserve the snapshot size before the cache-only ID copy.\n"
     "            with _cost_probe.span(\"t_size\", cpu=False):\n"
     "                size = (\n"
     "                    1024\n"
     "                    + sum(sys.getsizeof(part) for part in context.key)\n"
     "                    + sys.getsizeof(text)\n"
     "                    + token_bytes(ids, bound)\n"
     "                )\n"
     "            reservation = self.store.reserve(context.key, size)\n"
     "            if reservation is None:\n"
     "                self._count(\"capacity_declined\")\n"
     "                return ids\n"
     "            try:\n"
     "                with _cost_probe.span(\"t_copy\", cpu=False):\n"
     "                    _snapshot = TokenSnapshot(text, ids.copy(), bound)\n"
     "                context.stage(reservation, _snapshot, size)\n"
     "            except BaseException:\n"
     "                reservation.cancel()\n"
     "                raise\n"
     "            return ids\n"),
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    version, src, dest, probe_src = sys.argv[1], *map(Path, sys.argv[2:5])
    edits = COMMON + (N_ONLY if version == "N" else F_ONLY if version == "F" else None)
    if dest.exists():
        raise SystemExit(f"destination exists: {dest}")
    shutil.copytree(src, dest, symlinks=True, ignore=shutil.ignore_patterns("__pycache__"))
    for name in ("_cost_probe.py", "_cost_probe_middleware.py"):
        shutil.copy2(probe_src / name, dest / "vllm" / name)
    edited = {}
    # F edits are ordered: the publish check edit matches text produced by the
    # preceding publish-body edit, so apply strictly in sequence.
    for rel, old, new in edits:
        path = dest / rel
        with path.open(encoding="utf-8", newline="") as f:
            text = f.read()
        if "\r\n" in text:
            old, new = old.replace("\n", "\r\n"), new.replace("\n", "\r\n")
        count = text.count(old)
        if count != 1:
            raise SystemExit(f"anchor matched {count} times in {rel}: {old[:80]!r}")
        with path.open("w", encoding="utf-8", newline="") as f:
            f.write(text.replace(old, new))
        edited[rel] = None
    for rel in list(edited) + ["vllm/_cost_probe.py", "vllm/_cost_probe_middleware.py"]:
        edited[rel] = {"original": sha(src / rel) if (src / rel).exists() else None,
                       "instrumented": sha(dest / rel)}
    out = dest.parent / f"probe-edits-{version}.json"
    out.write_text(json.dumps(edited, indent=2), encoding="utf-8")
    print(json.dumps(edited, indent=2))


if __name__ == "__main__":
    main()
