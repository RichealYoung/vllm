# SPDX-License-Identifier: Apache-2.0
"""Diagnostic input-side cost probe (final T+H text experiment; extends the
baseline cost profile probe with fine-grained T/H sections).

Inactive unless COST_PROBE_DIR is set. Records per-request spans into a
bounded in-memory buffer and writes them as JSONL at process shutdown.
Never changes arguments, return values or execution order of probed code.
"""

import atexit
import contextvars
import gc
import json
import os
import threading
import time
from contextlib import contextmanager

_DIR = os.environ.get("COST_PROBE_DIR")
ENABLED = bool(_DIR)
_PHASE_FILE = os.environ.get("COST_PROBE_PHASE_FILE")
_CAPACITY = int(os.environ.get("COST_PROBE_CAPACITY", "20000"))
# Preflight only: also dump rendered prompt text, token IDs and hashes.
DUMP_PAYLOADS = os.environ.get("COST_PROBE_DUMP_PAYLOADS") == "1"

# Request identity propagated through asyncio tasks and (via the patched
# make_async) executor threads.
CURRENT_RID: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "cost_probe_rid", default=None
)
# Holder for the R/A spans of the current HTTP request (API process).
CURRENT_HTTP: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "cost_probe_http", default=None
)

_lock = threading.Lock()
_events: list[dict] = []
_payloads: list[dict] = []
_overflow = 0
_seq = 0
_flushed = False
_local = threading.local()


def _phase() -> str:
    if not _PHASE_FILE:
        return "unknown"
    try:
        with open(_PHASE_FILE, encoding="utf-8") as f:
            return f.read().strip() or "unknown"
    except OSError:
        return "unknown"


# Phase is read once per HTTP request at middleware entry (not inside spans).
CURRENT_PHASE: contextvars.ContextVar[str] = contextvars.ContextVar(
    "cost_probe_phase", default="unknown"
)


def record(stage: str, rid, wall_ns: int, cpu_ns, start_ns: int, end_ns: int,
           status: str = "ok", **extra) -> None:
    global _overflow, _seq
    if not ENABLED:
        return
    event = {
        "stage": stage,
        "rid": rid,
        "phase": CURRENT_PHASE.get(),
        "pid": os.getpid(),
        "native_tid": threading.get_native_id(),
        "start_wall_ns": start_ns,
        "end_wall_ns": end_ns,
        "wall_ns": wall_ns,
        "thread_cpu_ns": cpu_ns,
        "status": status,
    }
    if extra:
        event.update(extra)
    with _lock:
        if len(_events) >= _CAPACITY:
            _overflow += 1
            return
        event["seq"] = _seq
        _seq += 1
        _events.append(event)


def current_rid():
    """Request ID: API-side context variable, else the EngineCore thread's."""
    rid = CURRENT_RID.get()
    if rid is None:
        rid = getattr(_local, "core_rid", None)
    return rid


def set_core_rid(rid) -> None:
    _local.core_rid = rid


def clear_core_rid() -> None:
    _local.core_rid = None


def note(stage: str, **extra) -> None:
    """Zero-length event carrying values known only after a section ran."""
    if not ENABLED:
        return
    now = time.perf_counter_ns()
    record(stage, current_rid(), 0, None, now, now, **extra)


@contextmanager
def span(stage: str, rid=None, cpu: bool = True, **extra):
    """Time a synchronous section on the current thread.

    Fine-grained T/H sections use cpu=False: thread_time_ns is a system call
    and would dominate sub-microsecond sections.
    """
    if not ENABLED:
        yield
        return
    if rid is None:
        rid = current_rid()
    status = "ok"
    w0 = time.perf_counter_ns()
    c0 = time.thread_time_ns() if cpu else None
    try:
        yield
    except BaseException:
        status = "error"
        raise
    finally:
        c1 = time.thread_time_ns() if cpu else None
        w1 = time.perf_counter_ns()
        record(stage, rid, w1 - w0, (c1 - c0) if cpu else None, w0, w1,
               status, **extra)


def wrap_sync(func, stage: str):
    """Wrap a blocking function so each call is timed in its executing thread."""
    if not ENABLED:
        return func

    def _probed(*args, **kwargs):
        with span(stage):
            return func(*args, **kwargs)

    _probed.__wrapped__ = func  # type: ignore[attr-defined]
    return _probed


def add_payload(kind: str, rid, value) -> None:
    if not (ENABLED and DUMP_PAYLOADS):
        return
    with _lock:
        _payloads.append({"kind": kind, "rid": rid, "pid": os.getpid(),
                          "value": value})


# ---- EngineCore: initial block hashing only ---------------------------------

def set_initial_hash_rid(rid) -> None:
    _local.initial_rid = rid


def clear_initial_hash_rid() -> None:
    _local.initial_rid = None


def wrap_block_hasher(hasher):
    """Time only hasher calls made during initial Request construction."""
    if not ENABLED:
        return hasher

    def _probed(request):
        rid = getattr(_local, "initial_rid", None)
        if rid is None:
            # Decode-time hash updates: not part of H.
            return hasher(request)
        w0 = time.perf_counter_ns()
        c0 = time.thread_time_ns()
        status = "ok"
        result = None
        try:
            result = hasher(request)
            return result
        except BaseException:
            status = "error"
            raise
        finally:
            c1 = time.thread_time_ns()
            w1 = time.perf_counter_ns()
            record("H", rid, w1 - w0, c1 - c0, w0, w1, status,
                   new_hashes=len(result) if result is not None else None,
                   num_tokens=getattr(request, "num_tokens", None))
            if DUMP_PAYLOADS and result is not None:
                add_payload("initial_hashes", rid,
                            [bytes(h).hex() for h in result])

    return _probed


# ---- GC events ----------------------------------------------------------------

_gc_start: dict[int, int] = {}


def _gc_callback(phase, info):
    tid = threading.get_native_id()
    now = time.perf_counter_ns()
    if phase == "start":
        _gc_start[tid] = now
    else:
        start = _gc_start.pop(tid, None)
        if start is not None:
            record("gc", None, now - start, None, start, now,
                   generation=info.get("generation"),
                   collected=info.get("collected"))


# ---- Output -----------------------------------------------------------------

def flush(reason: str = "atexit") -> None:
    global _flushed
    if not ENABLED:
        return
    with _lock:
        if _flushed:
            return
        _flushed = True
        events = list(_events)
        payloads = list(_payloads)
        overflow = _overflow
    pid = os.getpid()
    os.makedirs(_DIR, exist_ok=True)
    base = os.path.join(_DIR, f"probe-{pid}")
    with open(base + ".events.jsonl", "w", encoding="utf-8") as f:
        for e in events:
            f.write(json.dumps(e, separators=(",", ":")) + "\n")
    if payloads:
        with open(base + ".payloads.jsonl", "w", encoding="utf-8") as f:
            for p in payloads:
                f.write(json.dumps(p, separators=(",", ":")) + "\n")
    with open(base + ".meta.json", "w", encoding="utf-8") as f:
        json.dump({"pid": pid, "events": len(events), "payloads": len(payloads),
                   "overflow": overflow, "capacity": _CAPACITY,
                   "flush_reason": reason}, f)


if ENABLED:
    gc.callbacks.append(_gc_callback)
    atexit.register(flush)
