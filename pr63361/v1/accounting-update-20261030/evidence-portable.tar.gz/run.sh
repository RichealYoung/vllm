#!/bin/bash
# CPU acceptance, then (only if it passed) Codex's unchanged 36-request GPU check.
set -uo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root=/root/autodl-tmp/claude-projects/reviews/pr63361/t-accounting-validation-20261030-r2
source "$project/activate.sh"
source "$project/vendor/source-env.sh"
job() {  # phase resource seconds script
  "$project/.venv/bin/python" /root/autodl-tmp/shared/tools/run_job.py \
    --project codex-pr63361 --id "claude-t-accounting-$1-20261030-002" --resource "$2" \
    --actor Claude --role support --workspace "$root" --cwd "$root" \
    --purpose "PR63361 head 04d5f00e8 correctness acceptance ($1), no performance" \
    --expected-seconds "$3" --wait-seconds 3600 -- "$project/.venv/bin/python" "$root/inputs/$4" \
    > "$root/launcher-$1.log" 2>&1 < /dev/null
}
job cpu functional 1800 claude_cpu.py; echo cpu-exit=$?
[ -f "$root/cpu-complete.json" ] || exit 1
job gpu functional 900 gpu.py; echo gpu-exit=$?
[ -f "$root/gpu-complete-r2.json" ] && echo ALLDONE
