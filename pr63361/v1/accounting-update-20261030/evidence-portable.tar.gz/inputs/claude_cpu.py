"""CPU acceptance for PR head 04d5f00e8, reusing Codex's 045e9051b r2 pipeline.

The candidate is Codex's accepted r2 candidate tree (same main, natives and
installation) with the four files changed by 04d5f00e8 replaced. Steps mirror
prepare_cpu.py: applicable hooks on a scratch copy, upstream reasoning/CLI
contract, red mapping control, then the same 8 CPU test files.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

from common import INPUTS, PROJECT, ROOT, read, run, sha, write
from prepare_cpu import pytest_run

CODEX = PROJECT / "experiments/pr63361-main-conflict-20261026-001/attempt-r2"
CHANGED = ["tests/renderers/test_session_prefix.py", "tests/utils_/test_session_prefix.py",
           "vllm/renderers/session_prefix.py", "vllm/utils/session_prefix.py"]


def main():
    identities = read(INPUTS / "claude-identities.json")
    candidate = ROOT / "candidate"
    shutil.copytree(CODEX / "candidate", candidate, symlinks=True)
    archive = INPUTS / "t-accounting-files.tar.gz"
    assert sha(archive) == identities["files_archive_sha256"]
    with tarfile.open(archive) as tar:
        tar.extractall(candidate, filter="data")
    manifest = read(CODEX / "inputs/candidate-manifest.json")
    for name in CHANGED:
        before = manifest[name]
        manifest[name] = sha(candidate / name)
        assert manifest[name] == identities["files"][name] and manifest[name] != before, name
    write(ROOT / "inputs/candidate-manifest.json", manifest)
    for name, digest in manifest.items():
        assert sha(candidate / name) == digest, name
    # Hooks execute on a disposable scratch copy; any source edits must return local.
    scratch = ROOT / "hook-scratch"
    shutil.copytree(candidate, scratch, symlinks=True)
    subprocess.run(["git", "init", "-q"], cwd=scratch, check=True)
    subprocess.run(["git", "add", "-A"], cwd=scratch, check=True)
    files = read(CODEX / "inputs/feature-files.json")
    runner = PROJECT / "experiments/session-prefix-admission-integration-20261025-002/inputs/run_applicable_hooks.py"
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="", PRE_COMMIT_HOME=str(PROJECT / "bench-lab/.cache/pre-commit"))
    env.pop("PYTHONPATH", None)
    hooks = run("hooks", [PROJECT / "bench-lab/.venv-lint/bin/python", runner, ROOT / "hook-selection", *files],
                cwd=scratch, env=env)
    changes = [name for name, digest in manifest.items() if sha(scratch / name) != digest]
    write(ROOT / "hooks-result.json", {"exit_code": hooks.returncode, "scratch_changes": changes})
    run("hook-diff", ["git", "diff", "--binary"], cwd=scratch)
    hooks.check_returncode()
    assert not changes, changes
    pytest_run("candidate-upstream", "candidate", ["tests/entrypoints/openai/test_render_parity.py",
               "tests/entrypoints/common/test_cli_args.py", "-k", "reasoning or effort"])
    red = ROOT / "red-mapping"
    shutil.copytree(candidate, red, symlinks=True)
    shutil.copy2(CODEX / "inputs/red-online_renderer.py", red / "vllm/renderers/online_renderer.py")
    pytest_run("red-mapping", "red-mapping",
               ["tests/renderers/test_session_prefix.py::test_reasoning_effort_mapping_survives_session_reuse"],
               expected=1)
    files = ["tests/utils_/test_session_prefix.py", "tests/renderers/test_session_prefix.py", "tests/v1/test_request.py",
             "tests/config/test_config_utils.py", "tests/v1/core/test_kv_cache_utils.py",
             "tests/v1/core/test_prefix_caching.py", "tests/multimodal/test_hasher.py",
             "tests/renderers/test_session_prefix_media_fallback.py"]
    report = pytest_run("candidate-cpu", "candidate", files)
    for name, digest in manifest.items():
        assert sha(candidate / name) == digest, name
    write(ROOT / "cpu-complete.json", {"status": "passed", "cpu": report, "performance": False,
                                       "identities": identities})


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        write(ROOT / "cpu-failure.json", {"error": f"{type(exc).__name__}: {exc}"})
        raise
