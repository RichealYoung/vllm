#!/usr/bin/env bash
set -euo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root="$project/experiments/pr63361-main-conflict-20261026-001"
source "$project/activate.sh"
source "$project/vendor/source-env.sh"
phase="${1:?cpu or gpu}"
case "$phase" in
 cpu) resource=build; script=prepare_cpu.py; estimate=1800 ;;
 gpu) resource=functional; script=gpu.py; estimate=900 ;;
 *) exit 2 ;;
esac
nohup "$project/.venv/bin/python" /root/autodl-tmp/shared/tools/run_job.py \
 --project codex-pr63361 --id "codex-pr63361-main-conflict-$phase-20261026-r1" --resource "$resource" \
 --actor Codex --role primary --cwd "$root" --purpose 'Approved main conflict adaptation; CPU and 36 real serving correctness requests, no performance' \
 --expected-seconds "$estimate" -- "$project/.venv/bin/python" "$root/inputs/$script" \
 > "$root/launcher-$phase.log" 2>&1 < /dev/null &
printf '%s\n' "$!" | tee "$root/launcher-$phase.pid"
