import subprocess
import sys
import time
from pathlib import Path
from common import ROOT,INPUTS,PROJECT,read,write

try:
    for phase in ['cpu','gpu']:
        if phase=='gpu':
            assert read(ROOT/'cpu-complete.json')['status']=='passed'
            subprocess.run(['bash',str(INPUTS/'launch.sh'),'gpu'],check=True)
        job=Path('/root/autodl-tmp/shared/jobs')/f'codex-pr63361-main-conflict-{phase}-20261026-r1.json'
        while True:
            state=read(job)
            if state['status'] in {'failed','finished','interrupted','blocked','busy'}: break
            time.sleep(5)
        assert state['status']=='finished' and state['exit_code']==0 and not state.get('remaining_pids'),state
    assert read(ROOT/'gpu-complete-r1.json')['status']=='passed'
    write(ROOT/'FINAL_ACCEPTANCE.json',{'status':'passed','identities':read(INPUTS/'identities.json'),
        'cpu':read(ROOT/'cpu-complete.json'),'gpu':read(ROOT/'gpu-complete-r1.json'),
        'scope':'correctness only; no new performance result'})
except BaseException as exc:
    write(ROOT/'gate-failure.json',{'error':f'{type(exc).__name__}: {exc}'})
    raise
finally:
    subprocess.run([sys.executable,str(INPUTS/'collect.py')],check=True)
