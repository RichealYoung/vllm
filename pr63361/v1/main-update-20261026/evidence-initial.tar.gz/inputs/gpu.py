REV = 'r1'
"""Approved 36 text correctness requests on the actual no-C V1 snapshot."""
import os
from pathlib import Path
import subprocess
import sys
from common import PROJECT, ROOT, INPUTS, read, write, sha, verify, environment, junit


def main():
    assert read(ROOT/"cpu-complete.json")["status"] == "passed"
    candidate = verify("candidate")
    output = ROOT / f"gpu-{REV}"
    output.mkdir()
    qwen = Path("/root/autodl-tmp/shared/models/qwen3-0.6b")
    q_manifest = read(qwen/"manifest.json")
    assert q_manifest["revision"] == "c1899de289a04d12100db370d81485cdf75e47ca"
    for entry in q_manifest["files"]:
        assert sha(qwen/entry["file"]) == entry["sha256"]
    llama = PROJECT / "experiments/session-prefix-admission-integration-20261025-002/llama-model"
    l_manifest = read(PROJECT / "experiments/session-prefix-admission-integration-20261025-002/weights.json")
    assert l_manifest["revision"] == "5a8abab4a5d6f164389b1079fb721cfab8d7126c"
    assert sha(llama/"model.safetensors") == l_manifest["sha256"]
    write(output/"models-verified.json", {"qwen": q_manifest, "llama": l_manifest})
    binary = output/"bin"
    binary.mkdir()
    cli = binary/"vllm"
    cli.write_text(f'#!/bin/sh\nexec "{sys.executable}" -m vllm.entrypoints.cli.main "$@"\n')
    cli.chmod(0o755)
    env = environment("candidate", gpu=True)
    env.update(PATH=str(binary)+":"+env["PATH"], VLLM_TEST_LLAMA32_MODEL=str(llama))
    argv = [sys.executable, str(INPUTS/"gpu_pytest.py"), str(output), "text", "-v", "-p", "no:cacheprovider",
            "tests/entrypoints/openai/chat_completion/test_serving_chat.py", "-k", "test_session_prefix_text_requests_preserve_native_ids_and_outputs",
            "--basetemp="+str(output/"text-tmp"), "--junitxml="+str(output/"text.xml")]
    with (output/"text.log").open("x") as stream:
        result = subprocess.run(argv, cwd=candidate, env=env, stdout=stream, stderr=subprocess.STDOUT)
    report = {"argv": argv, "exit_code": result.returncode, "common_C": False,
              "source_manifest_sha256": sha(INPUTS/"candidate-manifest.json")}
    if (output/"text.xml").exists():
        report.update(junit(output/"text.xml"))
    responses = list((output/"text-tmp").rglob("responses.jsonl"))
    report["requests"] = sum(len(path.read_text().splitlines()) for path in responses)
    logs = [path.parent/"server.log" for path in responses]
    report["server_logs"] = [str(path) for path in logs]
    report["shutdown_logs"] = [{"path": str(path),
        "fixture_reported_terminated": "terminated gracefully" in path.read_text(),
        "engine_dead_mentions": path.read_text().count("EngineDeadError"),
        "error_lines": [line for line in path.read_text().splitlines() if "ERROR" in line or "Task exception was never retrieved" in line]}
        for path in logs]
    report["shutdown_scope"] = "Real fixture SIGTERM/cleanup and raw logs retained; this test is not C's dedicated waiter-cancellation contract"
    write(output/"result.json", report)
    result.check_returncode()
    assert report["tests"] == 4 and report["requests"] == 36
    assert report["failures"] == report["errors"] == report["skipped"] == 0
    runtime = read(output/"text-environment.json")
    assert runtime["vllm_source"] == str(candidate/"vllm/__init__.py")
    assert runtime["native_paths"]["_session_prefix"] is None
    assert len(runtime["fixture_servers"]) == 4 and not runtime["remaining_pids"] and not runtime["cleanup_required"]
    verify("candidate")
    write(ROOT/f"gpu-complete-{REV}.json", {"status": "passed", "text": report, "common_C": False,
        "V2_V3_GPU_rerun": False, "performance_rerun": False})
    print("NO-C V1 GPU COMPLETE", report, flush=True)


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        write(ROOT/f"gpu-failure-{REV}.json", {"status": "failed", "error": f"{type(exc).__name__}: {exc}"})
        raise
