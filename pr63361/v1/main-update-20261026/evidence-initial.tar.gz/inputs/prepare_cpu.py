import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from common import PROJECT,ROOT,INPUTS,OLD,read,write,sha,run,verify,environment,junit

def pytest_run(label,source,selection,expected=0):
    argv=[sys.executable,str(INPUTS/'cpu_pytest.py'),str(ROOT),label,'-v','-p','no:cacheprovider',*selection,
        '--basetemp='+str(ROOT/(label+'-tmp')),'--junitxml='+str(ROOT/(label+'.xml'))]
    result=run(label,argv,cwd=ROOT/source,env=environment(source))
    report=junit(ROOT/(label+'.xml')) if (ROOT/(label+'.xml')).exists() else {}
    report['exit_code']=result.returncode
    write(ROOT/(label+'-result.json'),report)
    assert result.returncode==expected, report
    if expected==0:
        assert report['tests']>0 and report['failures']==report['errors']==report['skipped']==0,report
    else:
        assert report['tests']==1 and report['failures']==1 and report['errors']==0,report
        xml=(ROOT/(label+'.xml')).read_text()
        assert 'expected_ids' in xml and 'AssertionError' in xml,xml
    return report

def main():
    identities=read(INPUTS/'identities.json')
    for label in ['baseline','candidate']:
        archive=INPUTS/(label+'.tar.gz')
        assert sha(archive)==identities[label]['archive_sha256']
        (ROOT/label).mkdir()
        with tarfile.open(archive) as tar: tar.extractall(ROOT/label,filter='data')
        verify(label)
    candidate=ROOT/'candidate'
    build=ROOT/'native-build'
    cmake=PROJECT/'.venv/bin/cmake'
    args=[cmake,'-S',candidate,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DVLLM_TARGET_DEVICE=cuda',
        '-DVLLM_PYTHON_EXECUTABLE='+sys.executable,'-DCMAKE_CUDA_COMPILER='+os.environ['CUDACXX'],
        '-DCMAKE_CXX_COMPILER='+os.environ['CXX'],'-DCMAKE_CUDA_HOST_COMPILER='+os.environ['CXX'],
        '-DCMAKE_CUDA_ARCHITECTURES=86','-DNVCC_THREADS=1','-DCMAKE_INSTALL_PREFIX='+str(candidate)]
    run('configure',args,env=environment('candidate')).check_returncode()
    run('native-build',[cmake,'--build',build,'--target','_C_stable_libtorch','fs_io_C','-j','4'],env=environment('candidate')).check_returncode()
    installation=read(OLD/'runtime-installation.json')['N']
    installs={}
    for label in ['baseline','candidate']:
        target=ROOT/label
        natives={}
        for name,entry in installation['native'].items():
            if name.startswith('_session_prefix'): continue
            rebuilt=name.startswith(('_C_stable_libtorch','fs_io_C'))
            source=build/Path(name).name if rebuilt else Path(entry['source'])
            if not rebuilt: assert sha(source)==entry['sha256']
            dst=target/'vllm'/name
            dst.parent.mkdir(parents=True,exist_ok=True)
            dst.symlink_to(source)
            natives[name]={'path':str(source),'sha256':sha(source),'rebuilt':rebuilt}
        for name,entry in installation['generated']['files'].items():
            original=OLD/'N'/name
            assert sha(original)==entry['sha256']
            dst=target/name
            if dst.exists(): assert sha(dst)==entry['sha256']
            else:
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(original,dst)
        shutil.copy2(OLD/'N/vllm/_version.py',target/'vllm/_version.py')
        shutil.copytree(OLD/'N/vllm.egg-info',target/'vllm.egg-info')
        installs[label]={'native':natives,'distribution_metadata':'reused label; actual source identity is identities.json',
            'coverage':'dense Qwen/Llama only; MoE binary reused and MoE not tested'}
        verify(label)
    write(ROOT/'installation.json',installs)
    # Hooks execute on a disposable scratch copy; any source edits must return local.
    scratch=ROOT/'hook-scratch'
    shutil.copytree(candidate,scratch,symlinks=True)
    subprocess.run(['git','init','-q'],cwd=scratch,check=True)
    subprocess.run(['git','add','-A'],cwd=scratch,check=True)
    files=read(INPUTS/'feature-files.json')
    runner=PROJECT/'experiments/session-prefix-admission-integration-20261025-002/inputs/run_applicable_hooks.py'
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PRE_COMMIT_HOME=str(PROJECT/'bench-lab/.cache/pre-commit'))
    env.pop('PYTHONPATH',None)
    hook_result=run('hooks',[PROJECT/'bench-lab/.venv-lint/bin/python',runner,ROOT/'hook-selection',*files],cwd=scratch,env=env)
    changes=[name for name,digest in read(INPUTS/'candidate-manifest.json').items() if sha(scratch/name)!=digest]
    write(ROOT/'hooks-result.json',{'exit_code':hook_result.returncode,'scratch_changes':changes})
    run('hook-diff',['git','diff','--binary'],cwd=scratch)
    hook_result.check_returncode()
    assert not changes,changes
    # Upstream tests share the changed request-building entry points.
    upstream=['tests/entrypoints/openai/test_render_parity.py', 'tests/entrypoints/common/test_cli_args.py','-k','reasoning or effort']
    for source in ['baseline','candidate']: pytest_run(source+'-upstream',source,upstream)
    # A local, deliberately broken source copy proves the mapping regression detects loss.
    red=ROOT/'red-mapping'
    shutil.copytree(candidate,red,symlinks=True)
    bad=INPUTS/'red-online_renderer.py'
    assert sha(bad)==identities['red_mapping_sha256']
    shutil.copy2(bad,red/'vllm/renderers/online_renderer.py')
    pytest_run('red-mapping','red-mapping',['tests/renderers/test_session_prefix.py::test_reasoning_effort_mapping_survives_session_reuse'],expected=1)
    files=['tests/utils_/test_session_prefix.py','tests/renderers/test_session_prefix.py','tests/v1/test_request.py',
        'tests/config/test_config_utils.py','tests/v1/core/test_kv_cache_utils.py','tests/v1/core/test_prefix_caching.py',
        'tests/multimodal/test_hasher.py','tests/renderers/test_session_prefix_media_fallback.py']
    report=pytest_run('candidate-cpu','candidate',files)
    for label in ['baseline','candidate']: verify(label)
    write(ROOT/'cpu-complete.json',{'status':'passed','cpu':report,'performance':False,'identities':identities})

if __name__=='__main__':
    try: main()
    except BaseException as exc:
        write(ROOT/'cpu-failure.json',{'error':f'{type(exc).__name__}: {exc}'})
        raise
