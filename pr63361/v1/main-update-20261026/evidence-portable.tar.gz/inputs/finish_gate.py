"""Resume monitoring an already-running GPU job; never restart a test."""
import os
import subprocess
import sys
import time
from pathlib import Path
from common import ROOT,INPUTS,read,write

for phase in ['cpu','gpu']:
    job=Path('/root/autodl-tmp/shared/jobs')/f'codex-pr63361-main-conflict-{phase}-20261026-r2.json'
    while not job.exists(): time.sleep(1)
    while True:
        state=read(job)
        if state['status'] in {'failed','finished','interrupted','blocked','busy'}: break
        time.sleep(5)
    write(ROOT/(phase+'-job.json'),state)
    assert state['status']=='finished' and state['exit_code']==0 and not state.get('remaining_pids'),state
assert read(ROOT/'cpu-complete.json')['status']=='passed'
assert read(ROOT/'gpu-complete-r2.json')['status']=='passed'
write(ROOT/'FINAL_ACCEPTANCE.json',{'status':'passed','identities':read(INPUTS/'identities.json'),
    'cpu':read(ROOT/'cpu-complete.json'),'gpu':read(ROOT/'gpu-complete-r2.json'),
    'scope':'correctness only; no new performance result',
    'controller_recovery':'original gate read GPU job before asynchronous receipt creation; no tests restarted'})
subprocess.run([sys.executable,str(INPUTS/'collect_final.py')],check=True)
