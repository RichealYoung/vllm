import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

PROJECT = Path('/root/autodl-tmp/codex-projects/vllm-main-cu13')
ROOT = Path(__file__).resolve().parents[1]
INPUTS = Path(__file__).resolve().parent
OLD = PROJECT / 'experiments/pr63361-three-stage-build-20261025-001'
OVERLAY = PROJECT / 'experiments/session-prefix-version-range-20261024-001/overlays/tf5.20.2-tok0.23.2'

def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            result.update(block)
    return result.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def run(label, argv, cwd=None, env=None):
    with (ROOT / (label+'.log')).open('x') as stream:
        result = subprocess.run(list(map(str,argv)), cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
    write(ROOT/(label+'-command.json'), {'argv':list(map(str,argv)), 'cwd':str(cwd), 'exit_code':result.returncode})
    print(label, result.returncode, flush=True)
    return result

def verify(label):
    source = ROOT/label
    for name, digest in read(INPUTS/(label+'-manifest.json')).items():
        assert sha(source/name) == digest, (label,name)
    return source

def environment(label, gpu=False):
    source = ROOT/label
    assets = PROJECT/'experiments/session-prefix-tokenizer-expansion-20261024-001/assets'
    env=dict(os.environ,PYTHONPATH=f'{INPUTS}:{OVERLAY}:{source}',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',
        OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
        VLLM_TEST_QWEN3_MODEL='/root/autodl-tmp/shared/models/qwen3-0.6b',
        VLLM_TEST_QWEN25_VL_MODEL=str(PROJECT/'experiments/session-prefix-multimodal-e0a-20261025-002/model-assets'),
        VLLM_MODEL_REDIRECT_PATH=str(PROJECT/'experiments/session-prefix-multimodal-review-20261025-002/model-redirect.json'))
    for variable,family in [('QWEN25','qwen'),('LLAMA32','llama'),('GLM45','glm'),('DEEPSEEK31','deepseek')]:
        env['VLLM_TEST_'+variable+'_TOKENIZER']=str(assets/family)
    if gpu: env.pop('CUDA_VISIBLE_DEVICES',None)
    else: env['CUDA_VISIBLE_DEVICES']=''
    for key in ['TRITON_CACHE_DIR','TORCHINDUCTOR_CACHE_DIR','TORCH_EXTENSIONS_DIR','CUDA_CACHE_PATH','VLLM_CACHE_ROOT']:
        env[key]=str(ROOT/'caches'/key.lower())
    env['FLASHINFER_WORKSPACE_BASE']=str(ROOT/'caches')
    return env

def junit(path):
    cases = ET.parse(path).getroot().findall('.//testcase')
    return {'tests':len(cases), 'failures':sum(c.find('failure') is not None for c in cases),
        'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
