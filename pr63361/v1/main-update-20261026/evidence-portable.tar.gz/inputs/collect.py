import tarfile
from common import ROOT,INPUTS,sha,write,read

def main():
    excluded={'baseline','candidate','red-mapping','hook-scratch','native-build','caches'}
    files=[]
    for path in ROOT.rglob('*'):
        rel=path.relative_to(ROOT)
        if not path.is_file() or rel.parts[0] in excluded: continue
        if path.suffix in {'.json','.jsonl','.xml','.log','.py','.sh','.txt'} and path.name!='evidence-sha256.json':
            files.append(path)
    cache=ROOT/'native-build/CMakeCache.txt'
    if cache.exists(): files.append(cache)
    write(ROOT/'evidence-sha256.json',{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)})
    archive=ROOT/'evidence-r2.tar.gz'
    with tarfile.open(archive,'x:gz') as tar:
        for path in sorted(files): tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
        tar.add(ROOT/'evidence-sha256.json',arcname='evidence-sha256.json')
    print('EVIDENCE',sha(archive),len(files),flush=True)

if __name__=='__main__': main()
