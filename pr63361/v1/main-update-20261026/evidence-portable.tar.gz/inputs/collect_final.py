import tarfile
from common import ROOT,sha,write

excluded={'baseline','candidate','red-mapping','hook-scratch','native-build','caches'}
files=[]
for path in ROOT.rglob('*'):
    rel=path.relative_to(ROOT)
    if not path.is_file() or rel.parts[0] in excluded: continue
    if path.suffix in {'.json','.jsonl','.xml','.log','.py','.sh','.txt'} and not path.name.startswith('evidence-sha256'):
        # This controller's stdout is still open while archiving.
        if path.name=='finish-gate.log': continue
        files.append(path)
write(ROOT/'evidence-sha256-final.json',{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)})
archive=ROOT/'evidence-final.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for path in sorted(files): tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
    tar.add(ROOT/'evidence-sha256-final.json',arcname='evidence-sha256-final.json')
print('EVIDENCE',sha(archive),len(files),flush=True)
