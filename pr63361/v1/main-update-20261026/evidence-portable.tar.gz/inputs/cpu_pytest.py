import importlib.metadata
import json
import sys
from pathlib import Path

import pytest
import torch

root = Path(sys.argv[1])
label = sys.argv[2]
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
assert not torch.cuda.is_initialized()
code = pytest.main(sys.argv[3:])
environment = {
    "versions": {
        name: importlib.metadata.version(name)
        for name in ("torch", "transformers", "tokenizers", "huggingface-hub", "Pillow")
    },
    "cuda_initialized": torch.cuda.is_initialized(),
    "exit_code": code,
    "argv": sys.argv,
}
(root / (label + "-environment.json")).write_text(
    json.dumps(environment, indent=2) + "\n"
)
assert not torch.cuda.is_initialized(), (
    "CPU-only correctness acceptance initialized CUDA"
)
sys.exit(code)
