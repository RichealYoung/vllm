"""No-resource controller: success-only CPU -> GPU -> stable portable evidence."""
import json
from pathlib import Path
import subprocess
import sys
import time
from common import ROOT,INPUTS,read,write,progress

def job_path(phase):
    return Path('/root/autodl-tmp/shared/jobs')/f'codex-pr63361-followups-{phase}-20261026-r1.json'

def snapshot(path):
    try: return read(path)
    except (FileNotFoundError,json.JSONDecodeError): return None

def wait_job(phase):
    path=job_path(phase)
    deadline=time.monotonic()+60
    while (value:=snapshot(path)) is None:
        assert time.monotonic()<deadline,('receipt not created',str(path))
        time.sleep(1)
    while not value.get('finished_utc') and value['status'] not in {'failed','finished','interrupted','blocked','busy','rejected','lock_conflict'}:
        time.sleep(5)
        value=snapshot(path)
        assert value is not None,('receipt vanished',str(path))
    write(ROOT/(phase+'-job.json'),value)
    assert value['status']=='finished' and value['exit_code']==0 and not value.get('remaining_pids'),value
    return value

try:
    progress('starting_cpu')
    subprocess.run(['bash',str(INPUTS/'launch.sh'),'cpu'],check=True)
    cpu=wait_job('cpu')
    assert read(ROOT/'CPU_COMPLETE.json')['status']=='passed'
    progress('starting_gpu')
    subprocess.run(['bash',str(INPUTS/'launch.sh'),'gpu'],check=True)
    gpu=wait_job('gpu')
    assert read(ROOT/'GPU_COMPLETE.json')['status']=='passed'
    write(ROOT/'FINAL_ACCEPTANCE.json',{'status':'passed','identities':read(INPUTS/'identities.json'),
        'cpu':read(ROOT/'CPU_COMPLETE.json'),'gpu':read(ROOT/'GPU_COMPLETE.json'),
        'jobs':{'cpu':cpu,'gpu':gpu},'performance_rerun':False,'publication':'pending local evidence verification'})
    progress('passed',message='CPU/hooks/GPU correctness complete; public links not yet updated')
except BaseException as exc:
    write(ROOT/'PIPELINE_FAILURE.json',{'error':f'{type(exc).__name__}: {exc}'})
    progress('failed',error=f'{type(exc).__name__}: {exc}')
    raise
finally:
    active=[]
    for phase in ['cpu','gpu']:
        value=snapshot(job_path(phase))
        if value and not value.get('finished_utc') and value['status'] not in {'failed','finished','interrupted','blocked','busy','rejected','lock_conflict'}:
            active.append(value)
    if active:
        write(ROOT/'COLLECTION_DEFERRED.json',{'reason':'job still running; do not make unstable final archive','active_jobs':active})
    else:
        subprocess.run([sys.executable,str(INPUTS/'collect.py')],check=True)
