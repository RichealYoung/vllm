#!/usr/bin/env bash
set -euo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root="$project/experiments/pr63361-followups-current-text-validation-20261026-001"
test ! -e "$root/controller.pid"
nohup "$project/.venv/bin/python" "$root/inputs/controller.py" > "$root/controller.log" 2>&1 < /dev/null &
printf '%s\n' "$!" | tee "$root/controller.pid"
date -u '+%Y-%m-%dT%H:%M:%SZ' | tee "$root/deployed-utc.txt"
