import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from common import PROJECT,ROOT,INPUTS,PREVIOUS,OLD,read,write,sha,run,verify,environment,junit,progress

def extract(archive,target,digest):
    assert sha(archive)==digest,str(archive)
    with tarfile.open(archive) as tar: tar.extractall(target,filter='data')

def hooks(stage):
    source=verify(stage)
    scratch=ROOT/(stage+'-hook-scratch')
    shutil.copytree(source,scratch,symlinks=True)
    subprocess.run(['git','init','-q'],cwd=scratch,check=True)
    subprocess.run(['git','add','-A'],cwd=scratch,check=True)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PRE_COMMIT_HOME=str(PROJECT/'bench-lab/.cache/pre-commit'))
    env.pop('PYTHONPATH',None)
    runner=PROJECT/'experiments/session-prefix-admission-integration-20261025-002/inputs/run_applicable_hooks.py'
    result=run(stage+'-hooks',[PROJECT/'bench-lab/.venv-lint/bin/python',runner,ROOT/(stage+'-hook-selection'),
        *read(INPUTS/(stage+'-files.json'))],cwd=scratch,env=env)
    changes=[n for n,d in read(INPUTS/(stage+'-manifest.json')).items() if sha(scratch/n)!=d]
    write(ROOT/(stage+'-hooks-result.json'),{'exit_code':result.returncode,'scratch_changes':changes})
    run(stage+'-hook-diff',['git','diff','--binary'],cwd=scratch)
    result.check_returncode()
    assert not changes,changes

def main():
    identities=read(INPUTS/'identities.json')
    assert read(PREVIOUS/'FINAL_ACCEPTANCE.json')['status']=='passed'
    # Reconstruct only from locally authored, immutable LF archives.
    for stage in ['hash','image']:
        progress('assembling',stage=stage)
        target=ROOT/'sources'/stage
        target.mkdir(parents=True)
        extract(PREVIOUS/'inputs/baseline.tar.gz',target,'29dbf52866cb3cd3ab6b7f2f91ea74178b77b17eb71491ff05055d822ff6df38')
        extract(PREVIOUS/'inputs/candidate-feature.tar.gz',target,'def1bd336dc13dcd766e82f73b00fa8888c064b7506201f5bbf3d38293e5bc2c')
        extract(INPUTS/'hash-feature.tar.gz',target,identities['hash']['archive_sha256'])
        if stage=='image':
            extract(INPUTS/'image-feature.tar.gz',target,identities['image']['archive_sha256'])
            for name in identities['image']['deleted_files']:
                path=target/name
                assert path.resolve().is_relative_to(target.resolve())
                path.unlink()
        verify(stage)
        previous=read(PREVIOUS/'inputs/candidate-manifest.json')
        manifest=read(INPUTS/(stage+'-manifest.json'))
        checked=[]
        for name,digest in previous.items():
            if name.startswith('csrc/'):
                assert manifest[name]==digest,(stage,name)
                checked.append(name)
        new_native={n for n in manifest if n.startswith('csrc/')} - {n for n in previous if n.startswith('csrc/')}
        assert new_native=={'csrc/session_prefix.cpp'},new_native
        write(ROOT/(stage+'-common-native-source-check.json'),{'status':'passed','files':checked,'added_helper_source':list(new_native)})
    progress('building_helper')
    target=ROOT/'sources/hash'
    build=ROOT/'helper-build'
    cmake=PROJECT/'.venv/bin/cmake'
    args=[cmake,'-S',target,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DVLLM_TARGET_DEVICE=cuda',
        '-DVLLM_PYTHON_EXECUTABLE='+sys.executable,'-DCMAKE_CUDA_COMPILER='+os.environ['CUDACXX'],
        '-DCMAKE_CXX_COMPILER='+os.environ['CXX'],'-DCMAKE_CUDA_HOST_COMPILER='+os.environ['CXX'],
        '-DCMAKE_CUDA_ARCHITECTURES=86','-DNVCC_THREADS=1']
    run('helper-configure',args,env=environment('hash')).check_returncode()
    run('helper-build',[cmake,'--build',build,'--target','_session_prefix','-j','2'],env=environment('hash')).check_returncode()
    helper=build/'_session_prefix.abi3.so'
    assert sha(ROOT/'sources/hash/csrc/session_prefix.cpp')==sha(ROOT/'sources/image/csrc/session_prefix.cpp')
    helper_receipt={'path':str(helper),'sha256':sha(helper),'source_sha256':sha(target/'csrc/session_prefix.cpp'),'exports':['token_lcp']}
    write(ROOT/'helper-identity.json',helper_receipt)
    common=read(PREVIOUS/'installation.json')['candidate']['native']
    generated=read(OLD/'runtime-installation.json')['N']['generated']['files']
    reports={}
    for stage in ['hash','image']:
        target=verify(stage)
        natives={}
        for name,entry in common.items():
            original=Path(entry['path'])
            assert sha(original)==entry['sha256']
            dst=target/'vllm'/name
            dst.parent.mkdir(parents=True,exist_ok=True)
            dst.symlink_to(original)
            natives[name]=entry
        (target/'vllm/_session_prefix.abi3.so').symlink_to(helper)
        for name,entry in generated.items():
            original=OLD/'N'/name
            assert sha(original)==entry['sha256']
            dst=target/name
            if dst.exists(): assert sha(dst)==entry['sha256']
            else:
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(original,dst)
        shutil.copy2(PREVIOUS/'candidate/vllm/_version.py',target/'vllm/_version.py')
        shutil.copytree(PREVIOUS/'candidate/vllm.egg-info',target/'vllm.egg-info')
        write(ROOT/(stage+'-installation.json'),{'native':natives,'helper':helper_receipt,
            'metadata':'existing distribution label is not source identity; identities.json supplies commits/trees'})
        audit="from vllm import _session_prefix as h; assert {n for n in dir(h) if not n.startswith('_')} == {'token_lcp'}"
        run(stage+'-helper-import',[sys.executable,'-c',audit],cwd=target,env=environment(stage)).check_returncode()
        progress('hooks',stage=stage)
        hooks(stage)
        progress('cpu_tests',stage=stage)
        files=['tests/utils_/test_session_prefix.py','tests/renderers/test_session_prefix.py','tests/v1/test_request.py',
            'tests/config/test_config_utils.py','tests/v1/core/test_kv_cache_utils.py','tests/v1/core/test_prefix_caching.py','tests/multimodal/test_hasher.py']
        if stage=='hash': files.append('tests/renderers/test_session_prefix_media_fallback.py')
        label=stage+'-cpu'
        argv=[sys.executable,INPUTS/'cpu_pytest.py',ROOT,label,'-v','-p','no:cacheprovider',*files,
            '--basetemp='+str(ROOT/(label+'-tmp')),'--junitxml='+str(ROOT/(label+'.xml'))]
        result=run(label,argv,cwd=target,env=environment(stage))
        report=junit(ROOT/(label+'.xml')) if (ROOT/(label+'.xml')).exists() else {}
        report['exit_code']=result.returncode
        write(ROOT/(label+'-result.json'),report)
        result.check_returncode()
        assert report['tests']>0 and report['failures']==report['errors']==report['skipped']==0,report
        assert not read(ROOT/(label+'-environment.json'))['cuda_initialized']
        verify(stage)
        reports[stage]=report
    write(ROOT/'CPU_COMPLETE.json',{'status':'passed','reports':reports,'helper':helper_receipt,'performance':False})
    progress('cpu_complete',reports=reports)

if __name__=='__main__':
    try: main()
    except BaseException as exc:
        write(ROOT/'CPU_FAILURE.json',{'error':f'{type(exc).__name__}: {exc}'})
        progress('failed',failed_step='cpu',error=f'{type(exc).__name__}: {exc}')
        raise
