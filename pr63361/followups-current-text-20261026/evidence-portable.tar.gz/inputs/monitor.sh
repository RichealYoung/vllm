#!/usr/bin/env bash
set -euo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root="$project/experiments/pr63361-followups-current-text-validation-20261026-001"
if [[ -f "$root/STATUS.json" ]]; then cat "$root/STATUS.json"; fi
for phase in cpu gpu; do
 receipt="/root/autodl-tmp/shared/jobs/codex-pr63361-followups-$phase-20261026-r1.json"
 if [[ -f "$receipt" ]]; then
  "$project/.venv/bin/python" -c 'import json,sys; v=json.load(open(sys.argv[1])); print({k:v.get(k) for k in ("id","status","elapsed_seconds","exit_code","remaining_pids","overdue")})' "$receipt"
 fi
done
for label in hash-cpu image-cpu hash-gpu-text hash-gpu-fallback image-gpu-text image-gpu-images; do
 if [[ -f "$root/$label.log" ]]; then printf '\n%s\n' "$label"; tail -n 2 "$root/$label.log"; fi
done
for name in PIPELINE_FAILURE CPU_FAILURE GPU_FAILURE FINAL_ACCEPTANCE EVIDENCE COLLECTION_DEFERRED; do
 if [[ -f "$root/$name.json" ]]; then printf '\n%s.json exists\n' "$name"; fi
done
