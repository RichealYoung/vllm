#!/usr/bin/env bash
set -euo pipefail
project=/root/autodl-tmp/codex-projects/vllm-main-cu13
root="$project/experiments/pr63361-followups-current-text-validation-20261026-001"
source "$project/activate.sh"
source "$project/vendor/source-env.sh"
phase="${1:?cpu or gpu}"
case "$phase" in
 cpu) resource=build; estimate=2400 ;;
 gpu) resource=functional; estimate=2400 ;;
 *) exit 2 ;;
esac
nohup "$project/.venv/bin/python" /root/autodl-tmp/shared/tools/run_job.py \
 --project codex-pr63361 --id "codex-pr63361-followups-$phase-20261026-r1" --resource "$resource" \
 --actor Codex --role primary --cwd "$root" --purpose 'Approved hash and image follow-ups derived from current text PR; correctness only, no performance' \
 --expected-seconds "$estimate" --wait-seconds 3600 -- "$project/.venv/bin/python" "$root/inputs/$phase.py" \
 > "$root/launcher-$phase.log" 2>&1 < /dev/null &
printf '%s\n' "$!" | tee "$root/launcher-$phase.pid"
