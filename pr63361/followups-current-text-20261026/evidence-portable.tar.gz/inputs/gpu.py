import json
from pathlib import Path
import shutil
import sys
from common import PROJECT,ROOT,INPUTS,read,write,sha,run,verify,environment,junit,progress

def models():
    qwen=Path('/root/autodl-tmp/shared/models/qwen3-0.6b')
    q=read(qwen/'manifest.json')
    assert q['revision']=='c1899de289a04d12100db370d81485cdf75e47ca'
    for entry in q['files']: assert sha(qwen/entry['file'])==entry['sha256']
    llama=PROJECT/'experiments/session-prefix-admission-integration-20261025-002/llama-model'
    l=read(PROJECT/'experiments/session-prefix-admission-integration-20261025-002/weights.json')
    assert l['revision']=='5a8abab4a5d6f164389b1079fb721cfab8d7126c'
    assert sha(llama/'model.safetensors')==l['sha256']
    vision=PROJECT/'experiments/session-prefix-multimodal-serving-20261025-001/model'
    v=read(PROJECT/'experiments/session-prefix-multimodal-serving-20261025-001/weights.json')
    for entry in v['files']: assert sha(vision/entry['file'])==entry['sha256']
    write(ROOT/'MODELS_VERIFIED.json',{'qwen':q,'llama':l,'vision':v})
    return llama,vision

def main():
    assert read(ROOT/'CPU_COMPLETE.json')['status']=='passed'
    llama,vision=models()
    binary=ROOT/'gpu-bin'
    binary.mkdir()
    cli=binary/'vllm'
    cli.write_text(f'#!/bin/sh\nexec "{sys.executable}" -m vllm.entrypoints.cli.main "$@"\n')
    cli.chmod(0o755)
    reports={}
    for stage in ['hash','image']:
        source=verify(stage)
        output=ROOT/'gpu'/stage
        output.mkdir(parents=True)
        env=environment(stage,gpu=True)
        env.update(PATH=str(binary)+':'+env['PATH'],VLLM_TEST_LLAMA32_MODEL=str(llama),VLLM_TEST_QWEN25_VL_MODEL=str(vision))
        def test(label,selection,count,requests,trace=False):
            progress('gpu_tests',stage=stage,group=label)
            if trace:
                directory=output/(label+'-traces')
                directory.mkdir()
                env['MM_ACCEPTANCE_TRACE']=str(directory)
            else: env.pop('MM_ACCEPTANCE_TRACE',None)
            argv=[sys.executable,INPUTS/'gpu_pytest.py',output,label,'-v','-p','no:cacheprovider',
                'tests/entrypoints/openai/chat_completion/test_serving_chat.py','-k',selection,
                '--basetemp='+str(output/(label+'-tmp')),'--junitxml='+str(output/(label+'.xml'))]
            result=run(stage+'-gpu-'+label,argv,cwd=source,env=env)
            report=junit(output/(label+'.xml')) if (output/(label+'.xml')).exists() else {}
            responses=list((output/(label+'-tmp')).rglob('responses.jsonl'))
            report.update(exit_code=result.returncode,requests=sum(len(p.read_text().splitlines()) for p in responses),execution='fresh',performance=False)
            write(output/(label+'-result.json'),report)
            result.check_returncode()
            assert report['tests']==count and report['requests']==requests,report
            assert report['failures']==report['errors']==report['skipped']==0,report
            runtime=read(output/(label+'-environment.json'))
            assert runtime['vllm_source']==str(source/'vllm/__init__.py')
            assert len(runtime['fixture_servers'])==count and not runtime['remaining_pids'] and not runtime['cleanup_required']
            for response in responses: assert 'terminated gracefully' in (response.parent/'server.log').read_text()
            return report
        stage_reports={'text':test('text','test_session_prefix_text_requests_preserve_native_ids_and_outputs',8,72)}
        if stage=='hash':
            stage_reports['fallback']=test('fallback','test_session_prefix_image_requests_use_native_fallback',1,9,trace=True)
            records=[json.loads(line) for p in (output/'fallback-traces').glob('*.jsonl') for line in p.read_text().splitlines()]
            assert not any(r['kind']=='observer_error' for r in records)
            requests=[r for r in records if r['kind']=='request']
            assert len(requests)==9 and all(r['hashes']==r['native_hashes'] and r['features'] and r['reused_blocks']==0 for r in requests)
            assert any(r['kind']=='receiver' and any(r['missing']) for r in records)
            write(output/'fallback-native-hash-audit.json',{'status':'passed','requests':9,'no_hash_reuse':True,'native_hashes_exact':True})
        else:
            stage_reports['images']=test('images','test_session_prefix_image_requests_preserve_native_ids_and_outputs',4,60,trace=True)
            shutil.copy2(ROOT/'image-cpu-result.json',output/'cpu-result.json')
            run('image-native-hash-audit',[sys.executable,INPUTS/'audit_stage.py',output],env=env).check_returncode()
            assert read(output/'audit.json')['status']=='passed'
        verify(stage)
        reports[stage]=stage_reports
        write(output/'COMPLETE.json',{'status':'passed','reports':stage_reports,'performance':False})
    write(ROOT/'GPU_COMPLETE.json',{'status':'passed','reports':reports,'performance':False})
    progress('gpu_complete',reports=reports)

if __name__=='__main__':
    try: main()
    except BaseException as exc:
        write(ROOT/'GPU_FAILURE.json',{'error':f'{type(exc).__name__}: {exc}'})
        progress('failed',failed_step='gpu',error=f'{type(exc).__name__}: {exc}')
        raise
