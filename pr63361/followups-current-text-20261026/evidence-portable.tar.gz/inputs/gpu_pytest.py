"""Existing real pytest entry; launcher-owned SID and audited fixture PGIDs."""
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time

import psutil
import pytest
import torch
import vllm
import tests.utils as test_utils

root = Path(sys.argv[1])
label = sys.argv[2]
servers = []
original_start = test_utils.RemoteOpenAIServer._start_server


def managed_start(self, *args, **kwargs):
    # Preserve real fixture commands/env/HTTP assertions. Allocate its owned
    # process group without setsid so no test service detaches from the launcher.
    original_popen = test_utils.subprocess.Popen

    def foreground_popen(*popen_args, **popen_kwargs):
        assert popen_kwargs.pop("start_new_session") is True
        popen_kwargs.update(start_new_session=False, process_group=0)
        return original_popen(*popen_args, **popen_kwargs)

    test_utils.subprocess.Popen = foreground_popen
    try:
        original_start(self, *args, **kwargs)
    finally:
        test_utils.subprocess.Popen = original_popen
    proc = psutil.Process(self.proc.pid)
    record = dict(pid=proc.pid, pgid=os.getpgid(proc.pid), sid=os.getsid(proc.pid),
                  created=proc.create_time(), launcher_sid=os.getsid(0), launcher_pgid=os.getpgrp())
    assert record["pgid"] == record["pid"] and record["sid"] == record["launcher_sid"]
    servers.append(record)
    (root/(label+"-server-processes.json")).write_text(json.dumps(servers, indent=2))


test_utils.RemoteOpenAIServer._start_server = managed_start
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
environment = {"argv": sys.argv, "python": sys.executable, "vllm_source": vllm.__file__,
    "versions": {name: importlib.metadata.version(name) for name in ("torch", "transformers", "tokenizers", "huggingface-hub")},
    "native_paths": {name: (spec.origin if (spec := importlib.util.find_spec("vllm."+name)) else None)
                     for name in ("_C_stable_libtorch", "_session_prefix")},
    "torch_cuda": torch.version.cuda, "common_C": False,
    "lifecycle_adapter": "real fixture starts new PGID in launcher SID; original SIGTERM/owned-PGID cleanup unchanged"}
(root/(label+"-environment.json")).write_text(json.dumps(environment, indent=2))
assert environment["native_paths"]["_session_prefix"] is not None
code = None
cleanup_required = []
try:
    code = pytest.main(sys.argv[3:])
finally:
    def members(record):
        result = []
        for proc in psutil.process_iter(["create_time", "status"]):
            try:
                if (proc.info["status"] != psutil.STATUS_ZOMBIE and proc.info["create_time"] >= record["created"]-.01
                        and os.getsid(proc.pid) == record["sid"] and os.getpgid(proc.pid) == record["pgid"]):
                    result.append(proc.pid)
            except (psutil.NoSuchProcess, ProcessLookupError):
                pass
        return result

    for record in servers:
        alive = members(record)
        if alive:
            cleanup_required.append({"server": record, "pids": alive})
            os.killpg(record["pgid"], signal.SIGTERM)
            deadline = time.monotonic()+10
            while members(record) and time.monotonic() < deadline:
                time.sleep(.1)
            if members(record):
                os.killpg(record["pgid"], signal.SIGKILL)
    remaining = [pid for record in servers for pid in members(record)]
    environment.update(exit_code=code, fixture_servers=servers, cleanup_required=cleanup_required, remaining_pids=remaining)
    (root/(label+"-environment.json")).write_text(json.dumps(environment, indent=2))
assert not cleanup_required and not remaining, environment
sys.exit(code)
