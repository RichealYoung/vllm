import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


root = Path(sys.argv[1]).resolve()
summary = {"trace_groups": [], "status": "running"}
reusing = 0
for source in sorted((root / "images-traces").glob("*.jsonl")):
    events = [json.loads(line) for line in source.read_text().splitlines()]
    assert not any(event["kind"] == "observer_error" for event in events)
    requests = [event for event in events if event["kind"] == "request"]
    if not requests:
        continue
    assert len(requests) == 18, (source, len(requests))
    receivers = [event for event in events if event["kind"] == "receiver"]
    assert any(any(event["missing"]) for event in receivers), source
    for request in requests:
        assert request["hashes"] == request["native_hashes"], request["request_id"]
        assert request["hashes"] and request["features"]
        assert all(not feature["data_missing"] for feature in request["features"])
    previous = None
    hash_enabled = any(request["reused_blocks"] for request in requests)
    reusing += hash_enabled
    changed_image = None
    for index in range(5):
        reference, first, repeat = requests[index * 3:index * 3 + 3]
        assert reference["session_id"] is None
        assert first["session_id"] == repeat["session_id"] == "images"
        for candidate in (first, repeat):
            assert candidate["ids"] == reference["ids"]
            assert candidate["features"] == reference["features"]
            assert candidate["hashes"] == reference["hashes"]
        block_size = first["block_size"]
        if hash_enabled:
            assert repeat["reused_blocks"] == len(repeat["ids"]) // block_size
            if previous is None:
                expected = 0
            else:
                limit = min(len(previous["hashes"]), len(first["ids"]) // block_size) * block_size
                old_media = previous["features"]
                new_media = first["features"]
                for offset in range(max(len(old_media), len(new_media))):
                    old = old_media[offset] if offset < len(old_media) else None
                    new = new_media[offset] if offset < len(new_media) else None
                    if old != new:
                        limit = min(limit, *(entry["offset"] for entry in (old, new) if entry))
                        break
                common = 0
                for left, right in zip(previous["ids"][:limit], first["ids"][:limit]):
                    if left != right:
                        break
                    common += 1
                expected = common // block_size
            assert first["reused_blocks"] == expected, (index, expected, first["reused_blocks"])
        if index == 2:
            assert previous["ids"] == first["ids"]
            assert previous["features"][0]["identifier"] != first["features"][0]["identifier"]
            assert previous["hashes"] != first["hashes"]
            changed_block = first["features"][0]["offset"] // block_size
            assert previous["hashes"][:changed_block] == first["hashes"][:changed_block]
            assert previous["hashes"][changed_block] != first["hashes"][changed_block]
            assert first["reused_blocks"] * block_size <= min(previous["features"][0]["offset"], first["features"][0]["offset"])
            changed_image = {"same_ids": True, "different_media_hashes": True, "reused_blocks": first["reused_blocks"], "media_offset": first["features"][0]["offset"], "block_size": block_size}
        previous = repeat
    summary["trace_groups"].append({"source": source.name, "requests": len(requests), "hash_enabled": hash_enabled, "receiver_cache_data_none": True, "changed_image": changed_image})
assert len(summary["trace_groups"]) == 4 and reusing == 2
for label, expected in (("cpu", None), ("images", 4), ("text", 8)):
    result = json.loads((root / (label + "-result.json")).read_text())
    assert result["exit_code"] == 0
    assert result["tests"] > 0 if expected is None else result["tests"] == expected
    assert result["failures"] == result["errors"] == result["skipped"] == 0
for label, count, groups in (("images", 60, 4), ("text", 72, 8)):
    sources = list((root / (label + "-tmp")).rglob("responses.jsonl"))
    assert len(sources) == groups
    assert sum(len(source.read_text().splitlines()) for source in sources) == count
    for source in sources:
        assert "terminated gracefully" in (source.parent / "server.log").read_text()
for source in (root / "images-tmp").rglob("lifecycle.json"):
    value = json.loads(source.read_text())
    assert value["stream_closed_after_content"] and value["prefix_reset"]["success"]
    assert value["media_reset_status"] == 200
errors = list((root / "images-tmp").rglob("errors.jsonl"))
assert len(errors) == 4 and sum(len(source.read_text().splitlines()) for source in errors) == 8
summary.update(status="passed", image_valid_matrix_requests=60, image_lifecycle_requests=12, image_invalid_requests=8, pure_text_requests=72, native_hashes_exact=True, expected_reuse_blocks_exact=True)
(root / "audit.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
