import tarfile
from common import ROOT,sha,write

excluded={'sources','caches','helper-build','hash-hook-scratch','image-hook-scratch','gpu-bin'}
files=[]
for path in ROOT.rglob('*'):
    rel=path.relative_to(ROOT)
    if not path.is_file() or rel.parts[0] in excluded: continue
    if path.name in {'controller.log','EVIDENCE.json','FILE_SHA256.json'}: continue
    if path.suffix in {'.json','.jsonl','.xml','.log','.py','.sh','.txt','.patch','.yaml'}:
        files.append(path)
cache=ROOT/'helper-build/CMakeCache.txt'
if cache.is_file(): files.append(cache)
write(ROOT/'FILE_SHA256.json',{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)})
archive=ROOT/'evidence-portable.tar.gz'
with tarfile.open(archive,'x:gz',dereference=True) as tar:
    for path in sorted(files): tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
    tar.add(ROOT/'FILE_SHA256.json',arcname='FILE_SHA256.json',recursive=False)
write(ROOT/'EVIDENCE.json',{'archive':str(archive),'sha256':sha(archive),'files':len(files),
    'representation':'regular bytes including symlink file targets; source directories and caches excluded'})
print('EVIDENCE',sha(archive),len(files),flush=True)
