import json
import os
import sys
import threading
import traceback
from pathlib import Path


directory = os.environ.get("MM_ACCEPTANCE_TRACE")


def record(value):
    with (Path(directory) / f"trace-{os.getpid()}.jsonl").open("a") as output:
        output.write(json.dumps(value) + "\n")


def observe(frame, event, result):
    filename = frame.f_code.co_filename
    name = frame.f_code.co_name
    if event == "call" and name == "get_and_update_features" and filename.endswith("/multimodal/cache/base.py"):
        features = frame.f_locals["mm_features"]
        record({"kind": "receiver", "missing": [feature.data is None for feature in features]})
    if event != "return" or not filename.endswith("/v1/request.py") or name != "from_engine_core_request" or result is None:
        return
    try:
        from vllm.v1.request import Request

        request = frame.f_locals["request"]
        native = Request.from_engine_core_request(request, frame.f_locals["block_hasher"])
        initial = frame.f_locals.get("initial_block_hashes")
        hasher = frame.f_locals["block_hasher"]
        block_size = dict(zip(hasher.__code__.co_freevars, (cell.cell_contents for cell in hasher.__closure__)))["hash_block_size"]
        record({
            "kind": "request",
            "request_id": request.request_id,
            "session_id": request.session_id,
            "ids": request.prompt_token_ids,
            "hashes": [bytes(value).hex() for value in result.block_hashes],
            "native_hashes": [bytes(value).hex() for value in native.block_hashes],
            "reused_blocks": len(initial[1]) if initial else 0,
            "block_size": block_size,
            "features": [
                {"modality": feature.modality, "identifier": feature.identifier,
                 "offset": feature.mm_position.offset, "length": feature.mm_position.length,
                 "is_embed_none": feature.mm_position.is_embed is None,
                 "data_missing": feature.data is None}
                for feature in request.mm_features or []
            ],
        })
    except BaseException:
        record({"kind": "observer_error", "traceback": traceback.format_exc()})
        raise


if directory:
    sys.setprofile(observe)
    threading.setprofile(observe)
