import ast
import json
from pathlib import Path

inputs=Path(__file__).resolve().parent
files=sorted(inputs.glob('*.py'))
for path in files: ast.parse(path.read_text(),filename=str(path))
with (inputs.parent/'SCRIPT_SYNTAX.json').open('x') as stream:
    json.dump({'status':'passed','scripts':[p.name for p in files]},stream,indent=2)
print('syntax checked',len(files))
